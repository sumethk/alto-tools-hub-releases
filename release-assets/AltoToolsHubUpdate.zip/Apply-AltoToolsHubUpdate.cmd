@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Apply-AltoToolsHubUpdate.ps1" %*
set "helper_exit=%errorlevel%"
if not "%helper_exit%"=="0" (
  echo.
  echo Alto Tools Hub update failed with exit code %helper_exit%.
  pause
)
exit /b %helper_exit%
