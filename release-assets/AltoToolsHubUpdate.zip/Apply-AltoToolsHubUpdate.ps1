[CmdletBinding()]
param(
  [string]$PayloadPath = "",
  [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA "Programs\AltoTech\Alto Tools Hub"),
  [string]$ExpectedVersion = "",
  [switch]$UseMsi,
  [switch]$NoLaunch
)

$ErrorActionPreference = "Stop"
$ProductName = "Alto Tools Hub"
$ExecutableName = "Alto Tools Hub.exe"
$LogRoot = Join-Path $env:LOCALAPPDATA "AltoTech\Alto Tools Hub\Logs"

# Update artifacts must be signed by one of these AltoTech code-signing
# certificates. Append a renewed certificate thumbprint before the current
# one expires so installed builds keep auto-updating across the rotation.
$ExpectedSignerThumbprints = @(
  "0EE723BDF0BFC53F19146EF6E893B01C5470111D"
)

if ([string]::IsNullOrWhiteSpace($PayloadPath)) {
  $PayloadPath = Join-Path $PSScriptRoot "payload"
}

function Get-NormalizedPath {
  param([string]$Path)
  return [IO.Path]::GetFullPath($Path).TrimEnd('\')
}

function Assert-AltoSignature {
  param([string]$Path, [string]$Label)

  $signature = Get-AuthenticodeSignature -LiteralPath $Path
  if ($signature.Status -ne "Valid") {
    throw "$Label signature is not valid ($($signature.Status)). Download the release files again."
  }
  $thumbprint = if ($null -ne $signature.SignerCertificate) {
    $signature.SignerCertificate.Thumbprint
  }
  if (!$thumbprint -or $thumbprint -notin $ExpectedSignerThumbprints) {
    throw "$Label is signed by an unexpected publisher ($thumbprint)."
  }
}

function Test-RequiresBrowserRefresh {
  param([string]$Version)
  try {
    return [Version]$Version -lt [Version]"1.0.16"
  } catch {
    return $true
  }
}

function Stop-AltoProcessTree {
  param([string]$Root)

  try {
    $shutdownEvent = [System.Threading.EventWaitHandle]::OpenExisting("Local\AltoToolsHub.Shutdown")
    $shutdownEvent.Set() | Out-Null
    $shutdownEvent.Dispose()
  } catch {}

  $deadline = [DateTime]::UtcNow.AddSeconds(20)
  do {
    $processes = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
      try {
        $_.Path -and (Get-NormalizedPath $_.Path).StartsWith($Root + '\', [StringComparison]::OrdinalIgnoreCase)
      } catch {
        $false
      }
    })
    if ($processes.Count -eq 0) {
      return
    }
    Start-Sleep -Milliseconds 250
  } while ([DateTime]::UtcNow -lt $deadline)

  $processes | Stop-Process -Force -ErrorAction SilentlyContinue
  Start-Sleep -Milliseconds 500
}

function Wait-AltoServicesHealthy {
  param([int]$TimeoutSeconds = 45)

  $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
  $lastStatus = "Hub API unavailable"
  do {
    try {
      $apps = Invoke-RestMethod `
        -Uri "http://127.0.0.1:5300/api/apps" `
        -Method Get `
        -TimeoutSec 3 `
        -UseBasicParsing
      $appCount = @($apps).Count
      if ($appCount -ge 3 -and @($apps | Where-Object { !$_.running }).Count -eq 0) {
        return
      }
      $failed = @($apps | Where-Object { !$_.running } | ForEach-Object { $_.key })
      $lastStatus = if ($appCount -lt 3) {
        "Hub reported only $appCount bundled service(s)"
      } elseif ($failed.Count -gt 0) {
        "Not ready: $($failed -join ', ')"
      } else {
        "Hub API returned an unexpected response"
      }
    } catch {
      $lastStatus = $_.Exception.Message
    }
    Start-Sleep -Milliseconds 500
  } while ([DateTime]::UtcNow -lt $deadline)

  throw "The updated Hub did not start all bundled services within $TimeoutSeconds seconds. Last status: $lastStatus"
}

function Assert-AltoExecutableVersion {
  param(
    [string]$ExecutablePath,
    [string]$VersionPath,
    [string]$Label
  )

  if (!(Test-Path -LiteralPath $ExecutablePath -PathType Leaf)) {
    throw "$Label executable is missing."
  }
  if (!(Test-Path -LiteralPath $VersionPath -PathType Leaf)) {
    throw "$Label version file is missing."
  }
  $declaredVersion = (Get-Content -LiteralPath $VersionPath -Raw).Trim()
  $executableVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo($ExecutablePath).ProductVersion
  if ([string]::IsNullOrWhiteSpace($executableVersion)) {
    throw "$Label executable has no product version."
  }
  if ($executableVersion.Trim() -ne $declaredVersion) {
    throw "$Label executable version $executableVersion does not match version.txt $declaredVersion."
  }
}

function Assert-AltoInstallationVersions {
  param(
    [string]$Root,
    [string]$HubVersion
  )

  $installedHubVersion = (Get-Content -LiteralPath (Join-Path $Root "version.txt") -Raw).Trim()
  if ($installedHubVersion -ne $HubVersion) {
    throw "Windows Installer installed Hub version $installedHubVersion instead of $HubVersion."
  }
  $requiredRuntimeFiles = @(
    "_internal\python312.dll",
    "Tools\Network\_internal\python312.dll",
    "Tools\Modbus\_internal\python312.dll",
    "Tools\BACnet\_internal\python312.dll"
  )
  $missingRuntimeFiles = @($requiredRuntimeFiles | Where-Object {
    !(Test-Path -LiteralPath (Join-Path $Root $_) -PathType Leaf)
  })
  if ($missingRuntimeFiles.Count -gt 0) {
    throw "Installed runtime is incomplete: $($missingRuntimeFiles -join ', ')"
  }
  Assert-AltoExecutableVersion `
    -ExecutablePath (Join-Path $Root "Alto Tools Hub.exe") `
    -VersionPath (Join-Path $Root "runtime-version.txt") `
    -Label "Hub"
  foreach ($tool in @(
    @{ Name = "Network"; Executable = "Alto Network Service.exe" },
    @{ Name = "Modbus"; Executable = "Alto Modbus Service.exe" },
    @{ Name = "BACnet"; Executable = "Alto BACnet Service.exe" }
  )) {
    $toolRoot = Join-Path $Root ("Tools\" + $tool.Name)
    Assert-AltoExecutableVersion `
      -ExecutablePath (Join-Path $toolRoot $tool.Executable) `
      -VersionPath (Join-Path $toolRoot "version.txt") `
      -Label $tool.Name
  }
}

function Install-AltoMsiUpdate {
  param(
    [string]$MsiPath,
    [string]$Root,
    [string]$Version,
    [bool]$SkipLaunch
  )

  $checksumPath = "$MsiPath.sha256"
  if (!(Test-Path -LiteralPath $checksumPath -PathType Leaf)) {
    throw "Bundled MSI checksum is missing."
  }
  $checksumText = (Get-Content -LiteralPath $checksumPath -Raw).Trim()
  $match = [regex]::Match($checksumText, "\A([0-9a-fA-F]{64})\s+AltoToolsHubSetup\.msi\z")
  if (!$match.Success) {
    throw "Bundled MSI checksum has an invalid format."
  }
  $expectedHash = $match.Groups[1].Value.ToLowerInvariant()
  $actualHash = (Get-FileHash -LiteralPath $MsiPath -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actualHash -ne $expectedHash) {
    throw "Bundled MSI checksum verification failed."
  }
  Assert-AltoSignature -Path $MsiPath -Label "Update MSI"

  Stop-AltoProcessTree -Root $Root
  $msiLog = ""
  try {
    for ($attempt = 1; $attempt -le 2; $attempt++) {
      $msiLog = Join-Path $LogRoot "web-update-msi-$Version-attempt-$attempt-$([Guid]::NewGuid().ToString('N')).log"
      $mode = if ($attempt -eq 1) { "/i" } else { "/fa" }
      $arguments = @(
        $mode,
        ('"' + $MsiPath + '"'),
        "/qn",
        "/norestart",
        "/L*v",
        ('"' + $msiLog + '"')
      )
      $installer = Start-Process -FilePath "msiexec.exe" -ArgumentList $arguments -WindowStyle Hidden -Wait -PassThru
      if ($installer.ExitCode -notin @(0, 1641, 3010)) {
        throw "Windows Installer failed with exit code $($installer.ExitCode)."
      }

      try {
        Assert-AltoInstallationVersions -Root $Root -HubVersion $Version
        break
      } catch {
        if ($attempt -ge 2) {
          throw
        }
        Write-Warning "Installed files need repair: $($_.Exception.Message)"
      }
    }

    if (!$SkipLaunch) {
      Start-Process -FilePath (Join-Path $Root $ExecutableName) -ArgumentList "--no-open" -WorkingDirectory $Root
      Wait-AltoServicesHealthy
    }
  } catch {
    if (!$SkipLaunch -and (Test-Path -LiteralPath (Join-Path $Root $ExecutableName))) {
      try {
        Start-Process -FilePath (Join-Path $Root $ExecutableName) -ArgumentList "--no-open" -WorkingDirectory $Root
      } catch {}
    }
    throw "Update installation failed: $($_.Exception.Message) Log: $msiLog"
  }
  return $msiLog
}

function Update-AltoShortcutIcons {
  param([string]$Root)

  $iconPath = @(
    (Join-Path $Root "_internal\static\assets\logo-hub.ico"),
    (Join-Path $Root "static\assets\logo-hub.ico")
  ) | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
  if (!$iconPath) {
    return
  }

  $shortcutPaths = @(
    (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Alto Tools Hub\Alto Tools Hub.lnk"),
    (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Alto Tools Hub\Alto Tools Hub Background.lnk"),
    (Join-Path ([Environment]::GetFolderPath("Desktop")) "Alto Tools Hub.lnk")
  )
  $shell = New-Object -ComObject WScript.Shell
  foreach ($shortcutPath in $shortcutPaths) {
    if (!(Test-Path -LiteralPath $shortcutPath -PathType Leaf)) {
      continue
    }
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.IconLocation = "$iconPath,0"
    $shortcut.Save()
  }

  $iconRefresh = Join-Path $env:SystemRoot "System32\ie4uinit.exe"
  if (Test-Path -LiteralPath $iconRefresh -PathType Leaf) {
    Start-Process -FilePath $iconRefresh -ArgumentList "-show" -WindowStyle Hidden -Wait
  }
}

if (!(Test-Path -LiteralPath $PayloadPath -PathType Container)) {
  throw "Update payload was not found: $PayloadPath"
}

$payload = Get-NormalizedPath (Resolve-Path -LiteralPath $PayloadPath).Path
$install = Get-NormalizedPath $InstallRoot
$installParent = Split-Path -Parent $install
if (!$installParent -or $install -eq (Get-NormalizedPath ([IO.Path]::GetPathRoot($install)))) {
  throw "Install path is not safe: $install"
}
if ($payload -eq $install -or $payload.StartsWith($install + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw "Update payload must be outside the installation folder."
}
if (!(Test-Path -LiteralPath $install -PathType Container)) {
  throw "Alto Tools Hub is not installed at $install. Use the MSI for a new installation."
}

$installedVersionFile = Join-Path $install "version.txt"
$installedVersion = if (Test-Path -LiteralPath $installedVersionFile -PathType Leaf) {
  (Get-Content -LiteralPath $installedVersionFile -Raw).Trim()
} else {
  ""
}
$openUpdatedHub = Test-RequiresBrowserRefresh -Version $installedVersion

$payloadExecutable = Join-Path $payload $ExecutableName
$payloadVersionFile = Join-Path $payload "version.txt"
if (!(Test-Path -LiteralPath $payloadExecutable -PathType Leaf)) {
  throw "Update payload is missing $ExecutableName."
}
if (!(Test-Path -LiteralPath $payloadVersionFile -PathType Leaf)) {
  throw "Update payload is missing version.txt."
}
$payloadVersion = (Get-Content -LiteralPath $payloadVersionFile -Raw).Trim()
if ($ExpectedVersion -and $payloadVersion -ne $ExpectedVersion.TrimStart('v')) {
  throw "Update payload version $payloadVersion does not match expected version $ExpectedVersion."
}

$bundledMsi = Join-Path $PSScriptRoot "AltoToolsHubSetup.msi"
$useBundledMsi = $UseMsi.IsPresent -or (Test-Path -LiteralPath $bundledMsi -PathType Leaf)
if ($useBundledMsi) {
  if (!(Test-Path -LiteralPath $bundledMsi -PathType Leaf)) {
    throw "Bundled MSI was requested but was not found."
  }
  New-Item -ItemType Directory -Path $LogRoot -Force | Out-Null
  $msiLog = Install-AltoMsiUpdate `
    -MsiPath $bundledMsi `
    -Root $install `
    -Version $payloadVersion `
    -SkipLaunch:$NoLaunch.IsPresent
  Write-Host "$ProductName $payloadVersion MSI web update completed. Log: $msiLog"
  return
}

New-Item -ItemType Directory -Path $installParent -Force | Out-Null
New-Item -ItemType Directory -Path $LogRoot -Force | Out-Null
$operationId = [Guid]::NewGuid().ToString("N")
$stage = Join-Path $installParent ".Alto Tools Hub.update.$operationId"
$backup = Join-Path $installParent ".Alto Tools Hub.backup.$operationId"
$logPath = Join-Path $LogRoot "portable-update-$payloadVersion-$operationId.log"
$backupCreated = $false
$newInstallActivated = $false

try {
  "Staging $ProductName $payloadVersion" | Set-Content -LiteralPath $logPath -Encoding UTF8
  New-Item -ItemType Directory -Path $stage | Out-Null
  Get-ChildItem -LiteralPath $payload -Force | Copy-Item -Destination $stage -Recurse -Force
  $requiredStageFiles = @(
    $ExecutableName,
    "_internal\python312.dll",
    "Tools\Network\Alto Network Service.exe",
    "Tools\Network\_internal\python312.dll",
    "Tools\Modbus\Alto Modbus Service.exe",
    "Tools\Modbus\_internal\python312.dll",
    "Tools\BACnet\Alto BACnet Service.exe",
    "Tools\BACnet\_internal\python312.dll"
  )
  $missingStageFiles = @($requiredStageFiles | Where-Object {
    !(Test-Path -LiteralPath (Join-Path $stage $_) -PathType Leaf)
  })
  if ($missingStageFiles.Count -gt 0) {
    throw "Staged update is incomplete: $($missingStageFiles -join ', ')"
  }

  foreach ($stagedExecutable in @(
    $ExecutableName,
    "Tools\Network\Alto Network Service.exe",
    "Tools\Modbus\Alto Modbus Service.exe",
    "Tools\BACnet\Alto BACnet Service.exe"
  )) {
    Assert-AltoSignature -Path (Join-Path $stage $stagedExecutable) -Label "Update payload $stagedExecutable"
  }

  Stop-AltoProcessTree -Root $install
  if (Test-Path -LiteralPath $install) {
    Move-Item -LiteralPath $install -Destination $backup
    $backupCreated = $true
  }
  Move-Item -LiteralPath $stage -Destination $install
  $newInstallActivated = $true
  Assert-AltoInstallationVersions -Root $install -HubVersion $payloadVersion
  Update-AltoShortcutIcons -Root $install

  $installedExecutable = Join-Path $install $ExecutableName
  if (!$NoLaunch) {
    $process = Start-Process -FilePath $installedExecutable -ArgumentList "--no-open" -WorkingDirectory $install -PassThru
    Start-Sleep -Seconds 3
    if ($process.HasExited) {
      throw "The updated Hub exited during startup."
    }
    Wait-AltoServicesHealthy
    if ($openUpdatedHub) {
      $updatedUrl = "http://127.0.0.1:5300/?updated=$([Uri]::EscapeDataString($payloadVersion))"
      Start-Process -FilePath $updatedUrl
    }
  }

  "Update completed successfully." | Add-Content -LiteralPath $logPath -Encoding UTF8
  if (Test-Path -LiteralPath $backup) {
    Remove-Item -LiteralPath $backup -Recurse -Force
  }
} catch {
  $message = $_.Exception.Message
  "Update failed: $message" | Add-Content -LiteralPath $logPath -Encoding UTF8
  if ($newInstallActivated -or $backupCreated) {
    Stop-AltoProcessTree -Root $install
  }
  if (($newInstallActivated -or $backupCreated) -and (Test-Path -LiteralPath $install)) {
    Remove-Item -LiteralPath $install -Recurse -Force
  }
  if ($backupCreated -and (Test-Path -LiteralPath $backup)) {
    Move-Item -LiteralPath $backup -Destination $install
    if (!$NoLaunch -and (Test-Path -LiteralPath (Join-Path $install $ExecutableName))) {
      try {
        Start-Process -FilePath (Join-Path $install $ExecutableName) -ArgumentList "--no-open" -WorkingDirectory $install
      } catch {
        "Previous version was restored but could not be restarted: $($_.Exception.Message)" |
          Add-Content -LiteralPath $logPath -Encoding UTF8
      }
    }
    throw "Update failed and the previous version was restored: $message Log: $logPath"
  }
  throw "Update failed before the installed version was changed: $message Log: $logPath"
} finally {
  if (Test-Path -LiteralPath $stage) {
    Remove-Item -LiteralPath $stage -Recurse -Force
  }
}

Write-Host "$ProductName $payloadVersion update completed. Log: $logPath"
