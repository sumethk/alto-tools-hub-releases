const toolNav = document.querySelector("#toolNav");
const layout = document.querySelector(".layout");
const sidebarToggleBtn = document.querySelector("#sidebarToggleBtn");
const hubStatus = document.querySelector("#hubStatus");
const activeKicker = document.querySelector("#activeKicker");
const activeTitle = document.querySelector("#activeTitle");
const activeVersion = document.querySelector("#activeVersion");
const activeStatus = document.querySelector("#activeStatus");
const frameShell = document.querySelector("#frameShell");
const frameStage = document.querySelector("#frameStage");
const emptyState = document.querySelector("#emptyState");
const emptyStateTitle = document.querySelector("#emptyStateTitle");
const emptyStateDetail = document.querySelector("#emptyStateDetail");
const refreshBtn = document.querySelector("#refreshBtn");
const restartBtn = document.querySelector("#restartBtn");
const openWindowBtn = document.querySelector("#openWindowBtn");
const hubVersion = document.querySelector("#hubVersion");
const hubClock = document.querySelector("#hubClock");
const updateStatus = document.querySelector("#updateStatus");
const updateBtn = document.querySelector("#updateBtn");
const updatesPanel = document.querySelector("#updatesPanel");
const updatePageCheckBtn = document.querySelector("#updatePageCheckBtn");
const updateModalCloseBtn = document.querySelector("#updateModalCloseBtn");
const updatePageActionBtn = document.querySelector("#updatePageActionBtn");
const updatePageCurrent = document.querySelector("#updatePageCurrent");
const updatePageLatest = document.querySelector("#updatePageLatest");
const updatePagePublished = document.querySelector("#updatePagePublished");
const updatePageIndicator = document.querySelector("#updatePageIndicator");
const updatePageEyebrow = document.querySelector("#updatePageEyebrow");
const updatePageTitle = document.querySelector("#updatePageTitle");
const updatePageDetail = document.querySelector("#updatePageDetail");
const updatePageNotes = document.querySelector("#updatePageNotes");
const updatePageReleaseLink = document.querySelector("#updatePageReleaseLink");
const stableUpdateModeBtn = document.querySelector("#stableUpdateModeBtn");
const manualUpdateModeBtn = document.querySelector("#manualUpdateModeBtn");
const manualUpdatePanel = document.querySelector("#manualUpdatePanel");
const manualReleaseSelect = document.querySelector("#manualReleaseSelect");
const manualReleaseRefreshBtn = document.querySelector("#manualReleaseRefreshBtn");
const manualReleaseState = document.querySelector("#manualReleaseState");
const manualReleaseMeta = document.querySelector("#manualReleaseMeta");
const manualReleaseWarning = document.querySelector("#manualReleaseWarning");
const updateSteps = document.querySelector("#updateSteps");
const updateTransfer = document.querySelector("#updateTransfer");
const downloadProgressItem = document.querySelector("#downloadProgressItem");
const downloadProgressBar = document.querySelector("#downloadProgressBar");
const downloadProgressPercent = document.querySelector("#downloadProgressPercent");
const downloadProgressDetail = document.querySelector("#downloadProgressDetail");
const verifyProgressItem = document.querySelector("#verifyProgressItem");
const verifyProgressBar = document.querySelector("#verifyProgressBar");
const verifyProgressPercent = document.querySelector("#verifyProgressPercent");
const verifyProgressDetail = document.querySelector("#verifyProgressDetail");
const installProgressItem = document.querySelector("#installProgressItem");
const installProgressBar = document.querySelector("#installProgressBar");
const installProgressPercent = document.querySelector("#installProgressPercent");
const installProgressDetail = document.querySelector("#installProgressDetail");
const viewportGuard = document.querySelector("#viewportGuard");
const viewportGuardSize = document.querySelector("#viewportGuardSize");

const MIN_HUB_WIDTH = 1100;
const MIN_HUB_HEIGHT = 660;

let apps = [];
const storedActiveKey = localStorage.getItem("altoTools.activeKey") || "network";
let activeKey = storedActiveKey === "updates" ? "network" : storedActiveKey;
let updatesModalOpen = false;
let sidebarCollapsed = localStorage.getItem("altoTools.sidebarCollapsed") !== "false";
const frames = new Map();
const FRAME_THEME_VERSION = "alto-cloud-cockpit-1.2.49";
const DESIGN_HEIGHT = 0;
const SHORT_LABELS = new Map([
  ["network", "Network"],
  ["modbus", "Modbus"],
  ["bacnet", "BACnet"],
  ["updates", "Updates"],
]);
const TOOL_VERSIONS = {
    network: "1.1.78",
  modbus: "1.1.64",
  bacnet: "1.1.49",
};
let updateInfo = { status: "idle" };
let updateMode = localStorage.getItem("altoTools.updateMode") === "manual" ? "manual" : "stable";
let updateReleases = [];
let manualReleaseTag = localStorage.getItem("altoTools.manualReleaseTag") || "";
let releaseCatalogLoading = false;
let releaseCatalogError = "";
let currentHubVersion = "-";
let appStateSignature = "";
let updateRefreshVersion = "";
let pagePresence = null;
let appsLoading = false;
let appsRefreshTimer = null;

function connectPagePresence() {
  if (!window.EventSource) return;
  if (document.visibilityState !== "visible") return;
  if (pagePresence && pagePresence.readyState !== EventSource.CLOSED) return;
  pagePresence = new EventSource("/api/page-presence?visible=1");
}

function disconnectPagePresence() {
  pagePresence?.close();
  pagePresence = null;
}

function syncPagePresence() {
  if (document.visibilityState === "visible") {
    connectPagePresence();
    return;
  }
  disconnectPagePresence();
}

function frameDesignHeight(frame) {
  const reportedHeight = Number(frame?.dataset.contentHeight || 0);
  return Math.max(DESIGN_HEIGHT, Number.isFinite(reportedHeight) ? Math.ceil(reportedHeight) : 0);
}

function updateFrameScale() {
  if (!frameShell || !frameStage) return;
  // Fit the tool frame to the visible workspace so each tool scrolls
  // internally in one place instead of growing the Hub page.
  frameStage.style.width = "100%";
  frameStage.style.height = "100%";
  for (const frame of frames.values()) {
    frame.style.width = "100%";
    frame.style.height = "100%";
    frame.style.transform = "none";
  }
}

function requestActiveFrameSize() {
  const frame = frames.get(activeKey);
  frame?.contentWindow?.postMessage({ type: "alto-hub-request-size" }, "*");
}

function applySidebarState() {
  layout?.classList.toggle("sidebar-collapsed", sidebarCollapsed);
  if (sidebarToggleBtn) {
    sidebarToggleBtn.setAttribute("aria-expanded", String(!sidebarCollapsed));
    sidebarToggleBtn.setAttribute("aria-label", sidebarCollapsed ? "Open sidebar" : "Collapse sidebar");
    sidebarToggleBtn.title = sidebarCollapsed ? "Open sidebar" : "Collapse sidebar";
  }
  localStorage.setItem("altoTools.sidebarCollapsed", String(sidebarCollapsed));
  requestAnimationFrame(updateFrameScale);
}

function statusClass(app) {
  if (app.running) return "ready";
  return app.blocked ? "blocked" : "waiting";
}

function statusText(app) {
  if (app.running) return app.external ? "Already running" : "Ready";
  if (app.blocked) return "Blocked by Windows Application Control";
  return app.error || "Starting";
}

function compareVersions(left, right) {
  const normalize = (value) => String(value || "")
    .trim()
    .replace(/^v/i, "")
    .split(/[+-]/, 1)[0]
    .split(".")
    .map((part) => Number.parseInt(part, 10) || 0);
  const leftParts = normalize(left);
  const rightParts = normalize(right);
  const partCount = Math.max(leftParts.length, rightParts.length);

  for (let index = 0; index < partCount; index += 1) {
    const leftPart = leftParts[index] || 0;
    const rightPart = rightParts[index] || 0;
    if (leftPart !== rightPart) return leftPart > rightPart ? 1 : -1;
  }
  return 0;
}

function installedVersionIsNewer(currentVersion, latestVersion) {
  return Boolean(
    currentVersion
    && currentVersion !== "-"
    && latestVersion
    && latestVersion !== "-"
    && compareVersions(currentVersion, latestVersion) > 0
  );
}

function selectedManualRelease() {
  return updateReleases.find((release) => release.tag === manualReleaseTag) || null;
}

function formatReleaseDate(value) {
  if (!value) return "Release date unavailable";
  return new Date(value).toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function renderUpdateMode() {
  if (!stableUpdateModeBtn || !manualUpdateModeBtn || !manualUpdatePanel) return;
  const manual = updateMode === "manual";
  const busy = ["checking", "downloading", "verifying", "installing", "restarting"].includes(
    updateInfo.status
  );
  stableUpdateModeBtn.classList.toggle("is-active", !manual);
  manualUpdateModeBtn.classList.toggle("is-active", manual);
  stableUpdateModeBtn.setAttribute("aria-pressed", String(!manual));
  manualUpdateModeBtn.setAttribute("aria-pressed", String(manual));
  stableUpdateModeBtn.disabled = busy;
  manualUpdateModeBtn.disabled = busy;
  manualUpdatePanel.hidden = !manual;
  if (!manual) {
    manualReleaseState.textContent = "Latest stable";
    return;
  }

  const releaseSignature = JSON.stringify(
    updateReleases.map((release) => [release.tag, release.version, release.prerelease, release.is_current])
  );
  if (manualReleaseSelect.dataset.signature !== releaseSignature) {
    manualReleaseSelect.replaceChildren();
    if (!updateReleases.length) {
      const option = document.createElement("option");
      option.textContent = releaseCatalogLoading ? "Loading releases..." : "No installable releases";
      option.value = "";
      manualReleaseSelect.append(option);
    } else {
      for (const release of updateReleases) {
        const option = document.createElement("option");
        const labels = [release.prerelease ? "Prerelease" : "Stable"];
        if (release.is_current) labels.push("Installed");
        if (!release.can_download) labels.push("No update package");
        option.value = release.tag;
        option.textContent = `v${release.version} - ${labels.join(", ")}`;
        manualReleaseSelect.append(option);
      }
    }
    manualReleaseSelect.dataset.signature = releaseSignature;
  }

  if (!manualReleaseTag || !updateReleases.some((release) => release.tag === manualReleaseTag)) {
    const preferred = updateReleases.find((release) => !release.is_current) || updateReleases[0];
    manualReleaseTag = preferred?.tag || "";
    if (manualReleaseTag) localStorage.setItem("altoTools.manualReleaseTag", manualReleaseTag);
  }
  manualReleaseSelect.value = manualReleaseTag;
  manualReleaseSelect.disabled = busy || releaseCatalogLoading || !updateReleases.length;
  manualReleaseRefreshBtn.disabled = busy || releaseCatalogLoading;

  const release = selectedManualRelease();
  manualReleaseState.textContent = release ? `Manual: v${release.version}` : "Manual version";
  if (!release) {
    manualReleaseMeta.textContent = releaseCatalogError || "Select a published release.";
    manualReleaseWarning.hidden = true;
    return;
  }

  const packageBytes = Number(release.asset_size || 0) + Number(release.checksum_size || 0);
  const packageSize = packageBytes ? ` - ${(packageBytes / 1024 / 1024).toFixed(1)} MB` : "";
  manualReleaseMeta.textContent = `${formatReleaseDate(release.published_at)}${packageSize}`;
  const warnings = [];
  if (release.prerelease) warnings.push("Prerelease: this build may be less stable.");
  if (release.is_downgrade) warnings.push("Older version: existing settings may not be compatible.");
  if (release.is_current) warnings.push("This version is already installed.");
  if (!release.can_download) warnings.push("The portable update package or checksum is missing.");
  manualReleaseWarning.textContent = warnings.join(" ");
  manualReleaseWarning.hidden = warnings.length === 0;
}

async function loadUpdateReleases(force = false) {
  if (releaseCatalogLoading && !force) return;
  releaseCatalogLoading = true;
  releaseCatalogError = "";
  renderUpdateMode();
  try {
    const response = await fetch(`/api/update/releases${force ? `?time=${Date.now()}` : ""}`, {
      cache: "no-store",
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Could not load release versions");
    updateReleases = Array.isArray(payload.releases) ? payload.releases : [];
    if (!updateReleases.some((release) => release.tag === manualReleaseTag)) {
      const preferred = updateReleases.find((release) => !release.is_current) || updateReleases[0];
      manualReleaseTag = preferred?.tag || "";
      if (manualReleaseTag) localStorage.setItem("altoTools.manualReleaseTag", manualReleaseTag);
    }
    if (payload.latest_stable_version) {
      updateInfo = { ...updateInfo, latest_stable_version: payload.latest_stable_version };
    }
  } catch (error) {
    updateReleases = [];
    releaseCatalogError = error.message || "Could not load release versions";
  } finally {
    releaseCatalogLoading = false;
  }
  renderUpdateStatus();
}

function selectUpdateMode(mode) {
  updateMode = mode === "manual" ? "manual" : "stable";
  localStorage.setItem("altoTools.updateMode", updateMode);
  renderUpdateStatus();
  if (updateMode === "manual" && !updateReleases.length) loadUpdateReleases();
}

function normalizeApp(app) {
  const normalized = {
    ...app,
    version: app.version || TOOL_VERSIONS[app.key] || "unknown"
  };
  if (app.key !== "bacnet") return normalized;
  return {
    ...normalized,
    name: "BACnet Discover",
    description: "BACnet/IP and BACnet MS/TP discovery",
  };
}

function frameUrl(app) {
  return `${app.url}/?hubTheme=${FRAME_THEME_VERSION}`;
}

function ensureFrame(app) {
  let frame = frames.get(app.key);
  if (frame) return frame;

  frame = document.createElement("iframe");
  frame.className = "tool-frame";
  frame.title = app.name;
  frame.dataset.toolKey = app.key;
  frame.loading = "eager";
  if (app.key === "modbus" || app.key === "bacnet") {
    frame.allow = "serial";
  }
  frame.addEventListener("load", () => {
    if (frame.dataset.toolKey === activeKey) {
      frameShell?.scrollTo({ left: 0, top: 0, behavior: "auto" });
    }
    frame.contentWindow?.postMessage({ type: "alto-hub-request-size" }, "*");
  });
  frameStage.append(frame);
  frames.set(app.key, frame);
  updateFrameScale();
  return frame;
}

function hideFrames() {
  for (const frame of frames.values()) {
    frame.classList.remove("visible");
  }
}

function closeUpdatesModal() {
  if (!updatesModalOpen) return;
  updatesModalOpen = false;
  updatesPanel.hidden = true;
  layout?.classList.remove("updates-active");
  renderNav();
}

function selectApp(key, { preserveScroll = false } = {}) {
  if (key === "updates") {
    selectUpdates();
    return;
  }
  const app = apps.find((item) => item.key === key) || apps[0];
  if (!app) return;
  activeKey = app.key;
  localStorage.setItem("altoTools.activeKey", activeKey);
  activeKicker.textContent = app.key.toUpperCase();
  activeTitle.textContent = app.name;
  if (activeVersion) activeVersion.textContent = `Version ${app.version || "-"}`;
  activeStatus.textContent = statusText(app);
  activeStatus.className = `status ${statusClass(app)}`;
  restartBtn.disabled = !app;
  restartBtn.textContent = app.blocked ? "Retry" : "Restart";
  restartBtn.title = app.blocked
    ? "Retry after Windows or IT allows this tool"
    : "Restart this tool";
  openWindowBtn.disabled = !app.running;
  emptyState.classList.toggle("hidden", app.running);
  emptyState.classList.toggle("blocked", Boolean(app.blocked));
  if (app.blocked) {
    emptyStateTitle.textContent = `Windows blocked ${app.name}`;
    emptyStateDetail.textContent = app.error;
  } else {
    emptyStateTitle.textContent = `Starting ${app.name}`;
    emptyStateDetail.textContent = app.error || "Please wait while the local service comes online.";
  }
  if (!preserveScroll) {
    closeUpdatesModal();
  }
  frameShell.classList.toggle("visible", app.running);
  if (!preserveScroll) {
    frameShell.scrollTo({ left: 0, top: 0, behavior: "auto" });
  }
  hideFrames();

  if (app.running) {
    const frame = ensureFrame(app);
    const url = frameUrl(app);
    if (frame.dataset.loadedUrl !== url) {
      frame.src = url;
      frame.dataset.loadedUrl = url;
    }
    frame.classList.add("visible");
  }

  updateFrameScale();
  requestAnimationFrame(requestActiveFrameSize);
  renderNav();
}

function selectUpdates() {
  if (updatesModalOpen) {
    closeUpdatesModal();
    return;
  }
  updatesModalOpen = true;
  layout?.classList.add("updates-active");
  updatesPanel.hidden = false;
  renderUpdateStatus();
  if (updateMode === "manual" && !updateReleases.length) loadUpdateReleases();
  renderNav();
}

const HUB_SVG_ICONS = {
  refresh:
    '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a9 9 0 0 0-15.5-6.36L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 15.5 6.36L21 16"/><path d="M16 16h5v5"/></svg>',
  download:
    '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg>',
  check:
    '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>',
  prerelease:
    '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2v4"/><path d="M12 18v4"/><path d="m4.93 4.93 2.83 2.83"/><path d="m16.24 16.24 2.83 2.83"/><path d="M2 12h4"/><path d="M18 12h4"/></svg>',
  alert:
    '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg>',
};

function toolButtonContent({ iconClass, iconText, iconSvg, shortLabel, name, description, version, dotClass, dotTitle }) {
  const icon = document.createElement("span");
  icon.className = iconClass;
  icon.setAttribute("aria-hidden", "true");
  if (iconSvg) {
    icon.innerHTML = iconSvg;
  } else {
    icon.textContent = iconText;
  }

  const railLabel = document.createElement("span");
  railLabel.className = "tool-rail-label";
  railLabel.textContent = shortLabel || name;

  const copy = document.createElement("span");
  copy.className = "tool-copy";
  const nameElement = document.createElement("strong");
  nameElement.textContent = name;
  const descriptionElement = document.createElement("em");
  descriptionElement.textContent = description;
  const versionElement = document.createElement("span");
  versionElement.className = "tool-version";
  versionElement.textContent = version;
  copy.append(nameElement, descriptionElement, versionElement);

  const dot = document.createElement("span");
  dot.className = dotClass;
  dot.title = dotTitle;

  return [icon, railLabel, copy, dot];
}

function renderNav() {
  toolNav.replaceChildren();
  for (const app of apps) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "tool-button";
    if (app.key === activeKey) button.classList.add("active");
    const appStatus = statusText(app);
    button.setAttribute("aria-label", `${app.name}. ${app.description}. Version ${app.version || "-"}. ${appStatus}`);
    button.title = `${app.name} - ${appStatus}`;
    button.append(
      ...toolButtonContent({
        iconClass: `tool-icon tool-icon-${app.key}`,
        iconText: app.name.charAt(0),
        shortLabel: SHORT_LABELS.get(app.key) || app.name,
        name: app.name,
        description: app.description,
        version: `Version ${app.version || "-"}`,
        dotClass: `dot ${statusClass(app)}`,
        dotTitle: appStatus,
      })
    );
    button.addEventListener("click", () => selectApp(app.key));
    toolNav.append(button);
  }

  const updateButton = document.createElement("button");
  updateButton.type = "button";
  updateButton.className = "tool-button update-nav-button";
  if (updatesModalOpen) updateButton.classList.add("active");
  const versionMismatch = Boolean(
    updateInfo.current_version
    && currentHubVersion !== "-"
    && updateInfo.current_version !== currentHubVersion
  );
  const installedVersion = updateInfo.current_version || currentHubVersion;
  const latestStableVersion = updateInfo.latest_stable_version || updateInfo.latest_version;
  const aheadOfStable = installedVersionIsNewer(installedVersion, latestStableVersion);
  const updateState = !versionMismatch && updateInfo.status === "current" && !updateInfo.update_available
    ? "current"
    : updateInfo.update_available || ["downloading", "verifying", "downloaded", "installing"].includes(updateInfo.status)
      ? "available"
      : "checking";
  updateButton.classList.add(`update-${updateState}`);
  const updateVersion = versionMismatch
    ? `Checking Hub ${currentHubVersion}`
    : updateInfo.update_available
    ? `Version ${updateInfo.latest_version || "-"} available`
    : updateState === "current"
      ? aheadOfStable
        ? `Version ${installedVersion} prerelease`
        : `Version ${installedVersion} current`
      : `Hub Version ${currentHubVersion}`;
  const updateStatusTitle = updateState === "current"
    ? aheadOfStable
      ? `Prerelease build; latest stable is ${latestStableVersion}`
      : "Software is up to date"
    : updateState === "available"
      ? "Software update available"
      : "Checking software update status";
  updateButton.setAttribute(
    "aria-label",
    `Updates. Hub and bundled tools. ${updateVersion}. ${updateStatusTitle}`
  );
  updateButton.title = updateStatusTitle;
  updateButton.append(
    ...toolButtonContent({
      iconClass: "tool-icon tool-icon-updates",
      iconText: "",
      iconSvg: HUB_SVG_ICONS.download,
      shortLabel: SHORT_LABELS.get("updates"),
      name: "Updates",
      description: "Hub and bundled tools",
      version: updateVersion,
      dotClass: `dot ${updateState === "current" ? "ready" : "waiting"}`,
      dotTitle: updateStatusTitle,
    })
  );
  updateButton.addEventListener("click", selectUpdates);
  toolNav.append(updateButton);
}

async function loadApps() {
  if (appsLoading) return;
  appsLoading = true;
  try {
    const response = await fetch("/api/state", { cache: "no-store" });
    const payload = await response.json();
    const hub = payload.hub;
    const nextApps = payload.apps.map(normalizeApp);
    const nextSignature = JSON.stringify({
      hubVersion: hub.version,
      apps: nextApps.map((app) => ({
        key: app.key,
        name: app.name,
        description: app.description,
        url: app.url,
        version: app.version,
        running: app.running,
        external: app.external,
        error: app.error,
        error_code: app.error_code,
        blocked: app.blocked,
        retryable: app.retryable,
      })),
    });
    const stateChanged = nextSignature !== appStateSignature;
    appStateSignature = nextSignature;
    apps = nextApps;
    const readyCount = apps.filter((app) => app.running).length;
    currentHubVersion = hub.version || "-";
    if (hubVersion) hubVersion.textContent = `Hub Version ${currentHubVersion}`;
    hubStatus.textContent = `${readyCount}/${apps.length} systems ready`;
    if (
      updateInfo.current_version
      && updateInfo.current_version !== currentHubVersion
      && updateRefreshVersion !== currentHubVersion
    ) {
      updateRefreshVersion = currentHubVersion;
      void readUpdateStatus(true);
    }
    if (!stateChanged) return;
    selectApp(activeKey, { preserveScroll: true });
  } catch {
    appStateSignature = "";
    hubStatus.textContent = "Hub offline";
    activeStatus.textContent = "Offline";
    activeStatus.className = "status waiting";
  } finally {
    appsLoading = false;
  }
}

function scheduleAppsRefresh(delayMs = 5000) {
  if (appsRefreshTimer !== null) {
    window.clearTimeout(appsRefreshTimer);
    appsRefreshTimer = null;
  }
  if (document.visibilityState !== "visible") return;
  appsRefreshTimer = window.setTimeout(async () => {
    appsRefreshTimer = null;
    await loadApps();
    scheduleAppsRefresh();
  }, delayMs);
}

function syncAppsRefreshSchedule() {
  if (document.visibilityState === "visible") {
    void loadApps();
    scheduleAppsRefresh();
    return;
  }
  if (appsRefreshTimer !== null) {
    window.clearTimeout(appsRefreshTimer);
    appsRefreshTimer = null;
  }
}

function renderUpdateSteps(status) {
  if (!updateSteps) return;
  const errorStep = {
    download: 1,
    verify: 2,
    install: 3,
  }[updateInfo.progress_phase] ?? 0;
  const progress = {
    idle: { active: 0, complete: 0 },
    checking: { active: 0, complete: 0 },
    current: { active: -1, complete: 1 },
    available: { active: 1, complete: 1 },
    downloading: { active: 1, complete: 1 },
    verifying: { active: 2, complete: 2 },
    downloaded: { active: 3, complete: 3 },
    installing: { active: 3, complete: 3 },
    restarting: { active: 4, complete: 4 },
    error: { active: errorStep, complete: errorStep },
  }[status] || { active: 0, complete: 0 };

  for (const [index, step] of [...updateSteps.children].entries()) {
    step.classList.toggle("complete", index < progress.complete);
    step.classList.toggle("active", index === progress.active);
    step.classList.toggle("error", status === "error" && index === errorStep);
  }
}

function clampPercent(value) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, Math.min(100, Math.round(number))) : 0;
}

function formatBytes(value) {
  const bytes = Math.max(0, Number(value) || 0);
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB"];
  let size = bytes / 1024;
  let unit = units[0];
  for (let index = 1; index < units.length && size >= 1024; index += 1) {
    size /= 1024;
    unit = units[index];
  }
  return `${size.toFixed(size >= 100 ? 0 : 1)} ${unit}`;
}

function setProgressDisplay(bar, percentLabel, item, percent, state) {
  bar.value = percent;
  bar.textContent = `${percent}%`;
  bar.setAttribute("aria-valuetext", `${percent}% ${state}`);
  percentLabel.textContent = `${percent}%`;
  item.classList.toggle("active", state === "active");
  item.classList.toggle("complete", state === "complete");
  item.classList.toggle("error", state === "error");
}

function renderUpdateTransfer(status) {
  if (!updateTransfer) return;
  const phase = updateInfo.progress_phase || "";
  const progressPercent = clampPercent(updateInfo.progress_percent);
  const verified = ["downloaded", "installing", "restarting"].includes(status);
  const show = Boolean(
    updateInfo.update_available
    || ["downloading", "verifying", "downloaded", "installing", "restarting"].includes(status)
    || (status === "error" && phase)
  );
  updateTransfer.hidden = !show;
  if (!show) return;

  const downloadPercent = phase === "verify" || phase === "install" || verified
    ? 100
    : phase === "download"
      ? progressPercent
      : 0;
  const verifyPercent = phase === "install" || verified
    ? 100
    : phase === "verify"
      ? progressPercent
      : 0;
  const installPercent = status === "restarting"
    ? 100
    : phase === "install"
      ? progressPercent
      : 0;
  const failedDownload = status === "error" && phase === "download";
  const failedVerify = status === "error" && phase === "verify";
  const failedInstall = status === "error" && phase === "install";
  setProgressDisplay(
    downloadProgressBar,
    downloadProgressPercent,
    downloadProgressItem,
    downloadPercent,
    failedDownload ? "error" : downloadPercent === 100 ? "complete" : phase === "download" ? "active" : "waiting",
  );
  setProgressDisplay(
    verifyProgressBar,
    verifyProgressPercent,
    verifyProgressItem,
    verifyPercent,
    failedVerify ? "error" : verifyPercent === 100 ? "complete" : phase === "verify" ? "active" : "waiting",
  );
  setProgressDisplay(
    installProgressBar,
    installProgressPercent,
    installProgressItem,
    installPercent,
    failedInstall
      ? "error"
      : installPercent === 100
        ? "complete"
        : phase === "install"
          ? "active"
          : "waiting",
  );

  const completedBytes = Number(updateInfo.progress_bytes) || 0;
  const totalBytes = Number(updateInfo.progress_total_bytes) || Number(updateInfo.asset?.size) || 0;
  downloadProgressDetail.textContent = failedDownload
    ? updateInfo.error || "Download failed."
    : downloadPercent === 100
      ? `Downloaded ${formatBytes(totalBytes || completedBytes)}.`
      : phase === "download" && totalBytes
        ? `${formatBytes(completedBytes)} of ${formatBytes(totalBytes)}`
        : "Ready to download.";
  verifyProgressDetail.textContent = failedVerify
    ? updateInfo.error || "Verification failed."
    : verifyPercent === 100
      ? "SHA-256 checksum and package manifest verified."
      : phase === "verify"
        ? updateInfo.progress_message || "Verifying package."
        : "Waiting for download.";
  installProgressDetail.textContent = failedInstall
    ? updateInfo.error || "Installation failed."
    : status === "restarting"
      ? "Installation complete. Reconnecting to the updated Hub."
      : phase === "install"
        ? updateInfo.progress_message || "Installing files and restarting the Hub."
        : "Waiting for verification.";
}

function cleanReleaseNotes(notes) {
  if (!notes) return "No release notes are available.";
  return notes
    .split("\n")
    .map((line) => line.replace(/^#{1,6}\s+/, "").replace(/^[-*]\s+/, "- "))
    .join("\n")
    .trim();
}

function renderUpdatePage(status) {
  if (!updatesPanel) return;
  const currentVersion = updateInfo.current_version || currentHubVersion || "-";
  const latestStableVersion = updateInfo.latest_stable_version
    || updateInfo.latest_version
    || currentVersion;
  const manualRelease = updateMode === "manual" ? selectedManualRelease() : null;
  const targetVersion = updateInfo.target_version
    || manualRelease?.version
    || updateInfo.latest_version
    || currentVersion;
  const aheadOfStable = installedVersionIsNewer(currentVersion, latestStableVersion);
  const busy = ["checking", "downloading", "verifying", "installing", "restarting"].includes(status);
  let title = "Check for software updates";
  let detail = "Check GitHub for a newer Alto Tools Hub release.";
  let indicator = HUB_SVG_ICONS.refresh;
  let eyebrow = "Update status";
  let indicatorStatus = status;
  let displayedNotes = updateInfo.notes;
  let displayedReleaseUrl = updateInfo.release_url || "";
  let displayedPublishedAt = updateInfo.published_at;

  if (status === "checking") {
    eyebrow = "Checking now";
    title = "Looking for updates";
    detail = "Comparing the installed version with the latest stable release.";
  } else if (status === "downloading") {
    eyebrow = "Downloading";
    title = `Getting version ${targetVersion}`;
    detail = `${updateInfo.progress_message || "Downloading the update package"} ${clampPercent(updateInfo.progress_percent)}%.`;
    indicator = HUB_SVG_ICONS.download;
  } else if (status === "verifying") {
    eyebrow = "Verifying";
    title = `Checking version ${targetVersion}`;
    detail = `${updateInfo.progress_message || "Verifying the update package"} ${clampPercent(updateInfo.progress_percent)}%.`;
    indicator = HUB_SVG_ICONS.check;
  } else if (status === "downloaded") {
    eyebrow = "Ready to install";
    title = `Version ${targetVersion} is verified`;
    detail = "The update is ready and does not require the Windows installer.";
    indicator = HUB_SVG_ICONS.check;
  } else if (status === "installing") {
    eyebrow = "Installing automatically";
    title = `Installing version ${targetVersion}`;
    detail = `${updateInfo.progress_message || "Applying the verified update"} ${clampPercent(updateInfo.progress_percent)}%.`;
    indicator = HUB_SVG_ICONS.refresh;
  } else if (status === "restarting") {
    eyebrow = "Restarting";
    title = `Version ${targetVersion} is installed`;
    detail = "Waiting for the updated Hub to come back online.";
    indicator = HUB_SVG_ICONS.refresh;
  } else if (updateMode === "manual") {
    if (manualRelease) {
      eyebrow = manualRelease.prerelease
        ? "Manual prerelease"
        : manualRelease.is_downgrade
          ? "Manual older version"
          : "Manual stable release";
      title = manualRelease.is_current
        ? `Version ${manualRelease.version} is installed`
        : `Install version ${manualRelease.version}`;
      detail = manualRelease.is_current
        ? "Choose another published release to install manually."
        : manualRelease.can_download
          ? "The package will be downloaded, verified, installed, and restarted automatically."
          : "This release does not include a complete portable update package.";
      indicator = manualRelease.is_current ? HUB_SVG_ICONS.check : HUB_SVG_ICONS.download;
      indicatorStatus = manualRelease.prerelease || manualRelease.is_downgrade
        ? "available"
        : manualRelease.is_current
          ? "current"
          : "downloaded";
      displayedNotes = manualRelease.notes;
      displayedReleaseUrl = manualRelease.release_url || "";
      displayedPublishedAt = manualRelease.published_at;
    } else {
      eyebrow = releaseCatalogLoading ? "Loading releases" : "Manual version";
      title = releaseCatalogLoading ? "Getting published versions" : "Choose a release version";
      detail = releaseCatalogError || "Select a published GitHub release to continue.";
    }
  } else if (updateInfo.update_available) {
    eyebrow = "Update available";
    title = `Version ${targetVersion} is ready to download`;
    detail = updateInfo.can_download
      ? `You are using ${currentVersion}. Update directly from this page.`
      : "The release is available, but the portable update package is missing.";
    indicator = HUB_SVG_ICONS.download;
  } else if (status === "current" && aheadOfStable) {
    eyebrow = "Prerelease build";
    title = `Version ${currentVersion} is newer than stable`;
    detail = `Latest stable is ${latestStableVersion}. This prerelease is not offered to other devices automatically.`;
    indicator = HUB_SVG_ICONS.prerelease;
  } else if (status === "current") {
    eyebrow = "You're current";
    title = "Alto Tools Hub is up to date";
    detail = `Version ${currentVersion} is the latest stable release.`;
    indicator = HUB_SVG_ICONS.check;
  } else if (status === "error") {
    eyebrow = "Attention needed";
    title = updateInfo.progress_phase === "install"
      ? "Installation could not start"
      : updateInfo.progress_phase === "verify"
        ? "Verification failed"
        : updateInfo.progress_phase === "download"
          ? "Download failed"
          : updateInfo.error?.includes("sign-in")
            ? "GitHub sign-in required"
            : "Update check failed";
    detail = updateInfo.error || "The release service could not be reached.";
    indicator = HUB_SVG_ICONS.alert;
  }

  updatePageCurrent.textContent = currentVersion;
  updatePageLatest.textContent = latestStableVersion;
  updatePagePublished.textContent = displayedPublishedAt
    ? formatReleaseDate(displayedPublishedAt)
    : "-";
  updatePageIndicator.innerHTML = indicator;
  updatePageIndicator.className = `update-indicator ${indicatorStatus}`;
  updatePageEyebrow.textContent = eyebrow;
  updatePageTitle.textContent = title;
  updatePageDetail.textContent = detail;
  updatePageNotes.textContent = cleanReleaseNotes(displayedNotes);
  if (updateMode === "manual" && !busy) {
    updatePageActionBtn.textContent = manualRelease?.is_current
      ? "Already installed"
      : manualRelease?.can_download
        ? `Install ${manualRelease.version}`
        : manualRelease
          ? "Open release"
          : "Choose version";
    updatePageActionBtn.dataset.icon = manualRelease?.can_download ? "download" : "external";
    updatePageActionBtn.disabled = !manualRelease || manualRelease.is_current;
  } else {
    updatePageActionBtn.textContent = updateBtn.textContent;
    updatePageActionBtn.dataset.icon = updateBtn.dataset.icon || "refresh";
    updatePageActionBtn.disabled = updateBtn.disabled;
  }
  updatePageCheckBtn.disabled = busy || (updateMode === "manual" && releaseCatalogLoading);
  renderUpdateSteps(status);
  renderUpdateTransfer(status);
  renderUpdateMode();

  updatePageReleaseLink.hidden = !displayedReleaseUrl;
  if (displayedReleaseUrl) updatePageReleaseLink.href = displayedReleaseUrl;

  if (activeKey === "updates") {
    activeStatus.textContent = status === "current"
      ? aheadOfStable
        ? "Prerelease"
        : "Up to date"
      : status === "installing"
        ? "Installing"
        : status === "restarting"
          ? "Restarting"
          : updateInfo.update_available
            ? "Update available"
            : status === "error"
              ? "Check failed"
              : "Checking";
    activeStatus.className = `status ${status === "current" ? "ready" : "waiting"}`;
  }
}

function renderUpdateStatus() {
  if (!updateStatus || !updateBtn) return;
  const status = updateInfo.status || "idle";
  const currentVersion = updateInfo.current_version || currentHubVersion || "-";
  const latestStableVersion = updateInfo.latest_stable_version
    || updateInfo.latest_version
    || currentVersion;
  const aheadOfStable = installedVersionIsNewer(currentVersion, latestStableVersion);
  updateStatus.className = `update-status ${status}`;
  updateStatus.title = updateInfo.error || updateInfo.release_url || "GitHub Releases";
  updateBtn.disabled = [
    "checking",
    "downloading",
    "verifying",
    "installing",
    "restarting",
  ].includes(status);

  if (status === "checking") {
    updateStatus.textContent = "Checking GitHub";
    updateBtn.textContent = "Checking...";
  } else if (status === "downloading") {
    updateStatus.textContent = `Downloading ${clampPercent(updateInfo.progress_percent)}%`;
    updateBtn.textContent = `Downloading ${clampPercent(updateInfo.progress_percent)}%`;
  } else if (status === "verifying") {
    updateStatus.textContent = `Verifying ${clampPercent(updateInfo.progress_percent)}%`;
    updateBtn.textContent = `Verifying ${clampPercent(updateInfo.progress_percent)}%`;
  } else if (status === "downloaded") {
    updateStatus.textContent = `v${updateInfo.latest_version} ready`;
    updateBtn.textContent = `Install ${updateInfo.latest_version}`;
  } else if (status === "installing") {
    updateStatus.textContent = `Installing ${clampPercent(updateInfo.progress_percent)}%`;
    updateBtn.textContent = `Installing ${clampPercent(updateInfo.progress_percent)}%`;
  } else if (status === "restarting") {
    updateStatus.textContent = "Restarting";
    updateBtn.textContent = "Restarting...";
  } else if (updateInfo.update_available) {
    updateStatus.textContent = `v${updateInfo.latest_version} available`;
    updateBtn.textContent = updateInfo.can_download
      ? `Update to ${updateInfo.latest_version}`
      : "Open Release";
  } else if (status === "current") {
    updateStatus.textContent = aheadOfStable ? "Prerelease build" : "Up to date";
    updateBtn.textContent = "Check again";
  } else if (status === "error") {
    updateStatus.textContent = updateInfo.error?.includes("sign-in")
      ? "GitHub sign-in required"
      : "GitHub unavailable";
    updateBtn.textContent = "Retry";
  } else {
    updateStatus.textContent = "Updates -";
    updateBtn.textContent = "Check Updates";
  }
  updateBtn.dataset.icon = ["downloading", "verifying", "downloaded"].includes(status) || updateInfo.update_available
    ? "download"
    : ["installing", "restarting"].includes(status)
      ? "check"
      : "refresh";
  renderUpdatePage(status);
}

async function readUpdateStatus(force = false) {
  updateInfo = { ...updateInfo, status: "checking" };
  renderUpdateStatus();
  try {
    const response = await fetch(`/api/update${force ? "?force=1" : ""}`, { cache: "no-store" });
    updateInfo = await response.json();
    if (updateInfo.current_version) updateRefreshVersion = updateInfo.current_version;
  } catch {
    updateInfo = { status: "error", error: "Cannot connect to the local update service" };
  }
  renderUpdateStatus();
  renderNav();
}

async function postUpdateAction(path) {
  const response = await fetch(path, { method: "POST" });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "Update action failed");
  return payload;
}

async function monitorUpdateProgress(isFinished) {
  while (!isFinished()) {
    try {
      const response = await fetch(`/api/update/progress?time=${Date.now()}`, { cache: "no-store" });
      if (response.ok) {
        updateInfo = { ...updateInfo, ...(await response.json()) };
        renderUpdateStatus();
        renderNav();
      }
    } catch {
      // The final install phase can briefly stop the local server.
    }
    await wait(200);
  }
}

function wait(milliseconds) {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

async function waitForUpdatedHub(expectedVersion) {
  const deadline = Date.now() + 180000;
  const startedAt = Date.now();
  while (Date.now() < deadline) {
    const elapsedSeconds = Math.floor((Date.now() - startedAt) / 1000);
    updateInfo = {
      ...updateInfo,
      status: "installing",
      progress_phase: "install",
      progress_percent: Math.min(90, 10 + elapsedSeconds * 5),
      progress_message: elapsedSeconds < 3
        ? "Closing bundled tools and preparing files"
        : "Installing files and restarting the Hub",
    };
    renderUpdateStatus();
    renderNav();
    try {
      const response = await fetch(`/api/hub?updated=${Date.now()}`, { cache: "no-store" });
      if (response.ok) {
        const hub = await response.json();
        if (!expectedVersion || hub.version === expectedVersion) {
          const updateResponse = await fetch(`/api/update?force=1&updated=${Date.now()}`, {
            cache: "no-store",
          });
          if (updateResponse.ok) {
            const refreshedUpdate = await updateResponse.json();
            if (!expectedVersion || refreshedUpdate.current_version === expectedVersion) {
              updateInfo = {
                ...refreshedUpdate,
                status: "restarting",
                progress_phase: "install",
                progress_percent: 100,
                progress_message: "Installation complete",
              };
              renderUpdateStatus();
              renderNav();
              await wait(350);
              window.location.reload();
              return;
            }
          }
        }
      }
    } catch {
      // The local server is expected to be briefly unavailable during replacement.
    }
    await wait(1000);
  }

  updateInfo = {
    ...updateInfo,
    status: "error",
    error: "Update was started, but the Hub did not restart. Refresh this page to try again.",
  };
  renderUpdateStatus();
  renderNav();
}

async function applyUpdateTarget({ version, path, totalBytes, confirmation }) {
  if (!window.confirm(confirmation)) return;
  updateInfo = {
    ...updateInfo,
    target_version: version,
    status: updateInfo.status === "downloaded" ? "installing" : "downloading",
    progress_phase: updateInfo.status === "downloaded" ? "verify" : "download",
    progress_percent: updateInfo.status === "downloaded" ? 100 : 0,
    progress_bytes: 0,
    progress_total_bytes: totalBytes,
    progress_message: updateInfo.status === "downloaded" ? "Package verified" : "Starting download",
  };
  renderUpdateStatus();
  let actionFinished = false;
  const progressMonitor = monitorUpdateProgress(() => actionFinished);
  try {
    updateInfo = await postUpdateAction(path);
    actionFinished = true;
    await progressMonitor;
    renderUpdateStatus();
    renderNav();
    if (updateInfo.status === "installing") await waitForUpdatedHub(version);
  } catch (error) {
    actionFinished = true;
    await progressMonitor;
    updateInfo = { ...updateInfo, status: "error", error: error.message };
  }
  renderUpdateStatus();
}

async function handleUpdateAction() {
  if (updatesModalOpen && updateMode === "manual") {
    const release = selectedManualRelease();
    if (!release) {
      await loadUpdateReleases(true);
      return;
    }
    if (release.is_current) return;
    if (!release.can_download) {
      if (release.release_url) window.open(release.release_url, "_blank", "noopener,noreferrer");
      return;
    }
    const cautions = [];
    if (release.prerelease) cautions.push("This is a prerelease and may be less stable.");
    if (release.is_downgrade) cautions.push("This installs an older version and may affect newer settings.");
    cautions.push("The Hub will close briefly and restart automatically.");
    await applyUpdateTarget({
      version: release.version,
      path: `/api/update/apply?version=${encodeURIComponent(release.tag)}`,
      totalBytes: Number(release.asset_size || 0) + Number(release.checksum_size || 0),
      confirmation: `${cautions.join(" ")} Install Alto Tools Hub v${release.version}?`,
    });
    return;
  }

  if (updateInfo.update_available && updateInfo.can_download) {
    const version = updateInfo.latest_version || "new";
    await applyUpdateTarget({
      version,
      path: "/api/update/apply",
      totalBytes: Number(updateInfo.asset?.size || 0)
        + Number(updateInfo.checksum_asset?.size || 0),
      confirmation: `Update Alto Tools Hub to v${version}? The Hub will close briefly and restart automatically.`,
    });
    return;
  }

  if (updateInfo.update_available) {
    if (updateInfo.release_url) window.open(updateInfo.release_url, "_blank", "noopener,noreferrer");
    return;
  }

  await readUpdateStatus(true);
}

async function restartActiveApp() {
  const app = apps.find((item) => item.key === activeKey);
  if (!app) return;
  restartBtn.disabled = true;
  activeStatus.textContent = app.blocked ? "Retrying" : "Restarting";
  activeStatus.className = "status waiting";
  await fetch(`/api/apps/${app.key}/restart`, { method: "POST" }).catch(() => null);
  const frame = frames.get(app.key);
  if (frame) {
    frame.remove();
    frames.delete(app.key);
  }
  setTimeout(loadApps, 900);
}

function openActiveApp() {
  const app = apps.find((item) => item.key === activeKey);
  if (app?.running) {
    window.open(app.url, "_blank", "noopener,noreferrer");
  }
}

window.addEventListener("message", (event) => {
  if (event.data?.type === "alto-tool-wheel") {
    for (const frame of frames.values()) {
      if (frame.contentWindow !== event.source) continue;
      frameShell?.scrollBy({
        left: Number(event.data.deltaX) || 0,
        top: Number(event.data.deltaY) || 0,
        behavior: "auto",
      });
      return;
    }
  }

  if (event.data?.type !== "alto-tool-size") return;
  for (const frame of frames.values()) {
    if (frame.contentWindow !== event.source) continue;
    const height = Number(event.data.height);
    if (!Number.isFinite(height) || height <= 0) return;
    const contentHeight = String(Math.max(DESIGN_HEIGHT, Math.min(20000, Math.ceil(height))));
    if (frame.dataset.contentHeight === contentHeight) return;
    frame.dataset.contentHeight = contentHeight;
    updateFrameScale();
    return;
  }
});

window.addEventListener("wheel", (event) => {
  if (!frameShell?.classList.contains("visible")) return;
  const rect = frameShell.getBoundingClientRect();
  const insideFrameShell =
    event.clientX >= rect.left &&
    event.clientX <= rect.right &&
    event.clientY >= rect.top &&
    event.clientY <= rect.bottom;
  if (!insideFrameShell) return;
  frameShell.scrollBy({
    left: event.deltaX,
    top: event.deltaY,
    behavior: "auto",
  });
}, { passive: true });

refreshBtn.addEventListener("click", loadApps);
restartBtn.addEventListener("click", restartActiveApp);
openWindowBtn.addEventListener("click", openActiveApp);
updateBtn?.addEventListener("click", handleUpdateAction);
updateStatus?.addEventListener("click", () => {
  if (!updatesModalOpen) selectUpdates();
});
updateModalCloseBtn?.addEventListener("click", closeUpdatesModal);
updatesPanel?.addEventListener("click", (event) => {
  if (event.target === updatesPanel) closeUpdatesModal();
});
window.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && updatesModalOpen) closeUpdatesModal();
});
updatePageActionBtn?.addEventListener("click", handleUpdateAction);
updatePageCheckBtn?.addEventListener("click", () => (
  updateMode === "manual" ? loadUpdateReleases(true) : readUpdateStatus(true)
));
stableUpdateModeBtn?.addEventListener("click", () => selectUpdateMode("stable"));
manualUpdateModeBtn?.addEventListener("click", () => selectUpdateMode("manual"));
manualReleaseRefreshBtn?.addEventListener("click", () => loadUpdateReleases(true));
manualReleaseSelect?.addEventListener("change", () => {
  manualReleaseTag = manualReleaseSelect.value;
  localStorage.setItem("altoTools.manualReleaseTag", manualReleaseTag);
  renderUpdateStatus();
});
sidebarToggleBtn?.addEventListener("click", () => {
  sidebarCollapsed = !sidebarCollapsed;
  applySidebarState();
});
function updateViewportGuard() {
  if (!viewportGuard) return;
  const width = Math.round(window.innerWidth || 0);
  const height = Math.round(window.innerHeight || 0);
  const tooSmall = width < MIN_HUB_WIDTH || height < MIN_HUB_HEIGHT;
  if (viewportGuardSize) {
    viewportGuardSize.textContent = `ขนาดปัจจุบัน: ${width} × ${height} px  |  ขั้นต่ำ: ${MIN_HUB_WIDTH} × ${MIN_HUB_HEIGHT} px`;
  }
  viewportGuard.hidden = !tooSmall;
  viewportGuard.classList.toggle("active", tooSmall);
}

window.addEventListener("resize", updateFrameScale);
window.addEventListener("resize", updateViewportGuard);
window.addEventListener("load", updateViewportGuard);
window.addEventListener("pageshow", syncPagePresence);
window.addEventListener("pagehide", disconnectPagePresence);
document.addEventListener("visibilitychange", syncPagePresence);
document.addEventListener("visibilitychange", syncAppsRefreshSchedule);
if (window.ResizeObserver && frameShell) {
  new ResizeObserver(() => updateFrameScale()).observe(frameShell);
}

function updateHubClock() {
  if (!hubClock) return;
  const now = new Date();
  const datePart = now.toLocaleDateString("en-GB", {
    weekday: "short",
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
  const timePart = now.toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
  hubClock.textContent = `${datePart}  ${timePart}`;
}

updateViewportGuard();
applySidebarState();
updateHubClock();
setInterval(updateHubClock, 1000);
syncPagePresence();
loadApps();
scheduleAppsRefresh();
readUpdateStatus(true);
setInterval(readUpdateStatus, 6 * 60 * 60 * 1000);
