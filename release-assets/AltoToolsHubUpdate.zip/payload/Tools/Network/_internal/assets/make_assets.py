import base64
import io as _io
import os
import struct

from PIL import Image, ImageDraw

SRC = os.path.join(os.path.dirname(__file__), "..", "logo.png")
ASSETS = os.path.dirname(__file__)

img = Image.open(SRC).convert("RGBA")

# ── 1. ICO — written manually because Pillow 12.x ICO export is broken ───────
_SIZES = [16, 24, 32, 48, 64, 128, 256]
_frames = []
for _s in _SIZES:
    _frame = img.resize((_s, _s), Image.LANCZOS)
    _buf = _io.BytesIO()
    _frame.save(_buf, format="PNG", optimize=False)
    _frames.append((_s, _buf.getvalue()))
_ico_path = os.path.join(ASSETS, "logo.ico")
_count = len(_frames)
_header = struct.pack("<HHH", 0, 1, _count)
_dir_bytes = b""
_payload = b""
_off = 6 + _count * 16
for _s, _png in _frames:
    _w = 0 if _s == 256 else _s
    _h = _w
    _dir_bytes += struct.pack("<BBBBHHII", _w, _h, 0, 0, 1, 32, len(_png), _off)
    _payload += _png
    _off += len(_png)
with open(_ico_path, "wb") as _f:
    _f.write(_header + _dir_bytes + _payload)
print(f"logo.ico OK  ({os.path.getsize(_ico_path) // 1024} KB)")

# ── 2. banner.bmp  493×58  (MSI installer dialog header) ─────────────────────
BW, BH = 493, 58
banner = Image.new("RGB", (BW, BH), (15, 23, 42))
draw = ImageDraw.Draw(banner)

# gradient left panel
for x in range(260):
    t = x / 260
    r = int(15 + t * (10 - 15))
    g = int(23 + t * (35 - 23))
    b = int(42 + t * (90 - 42))
    for y in range(BH):
        banner.putpixel((x, y), (r, g, b))

# blue accent line at bottom
draw.rectangle([0, BH - 3, BW, BH], fill=(59, 130, 246))

# logo on right — keep rounded corners from source
logo_b = img.copy()
logo_b.thumbnail((50, 50), Image.LANCZOS)
lw, lh = logo_b.size
px = BW - lw - 6
py = (BH - lh) // 2
banner.paste(logo_b, (px, py), logo_b)

draw.text((16, 10), "Alto Network Scanner", fill=(226, 232, 240))
draw.text(
    (16, 32),
    "Network IP & MAC Address Scanner  |  AltoTech Global Co., Ltd.",
    fill=(148, 163, 184),
)

banner.save(os.path.join(ASSETS, "banner.bmp"), format="BMP")
print("banner.bmp OK")

# ── 3. dialog.bmp  493×312  (MSI welcome / finish screen) ────────────────────
DW, DH = 493, 312
dlg = Image.new("RGB", (DW, DH), (10, 18, 35))
draw2 = ImageDraw.Draw(dlg)

# gradient left panel
for x in range(220):
    t = x / 220
    r2 = int(10 + t * (15 - 10))
    g2 = int(18 + t * (30 - 18))
    b2 = int(35 + t * (80 - 35))
    for y in range(DH):
        dlg.putpixel((x, y), (r2, g2, b2))

draw2.rectangle([0, 0, 4, DH], fill=(59, 130, 246))
draw2.rectangle([0, DH - 4, DW, DH], fill=(59, 130, 246))

logo_d = img.copy()
logo_d.thumbnail((120, 120), Image.LANCZOS)
ldw, ldh = logo_d.size
lx = (200 - ldw) // 2
ly = 30
dlg.paste(logo_d, (lx, ly), logo_d)

draw2.text((18, 170), "Alto Network Scanner", fill=(226, 232, 240))
draw2.text((18, 194), "Version 1.1.0", fill=(148, 163, 184))
draw2.text((18, 218), "AltoTech Global Co., Ltd.", fill=(100, 116, 139))
draw2.text((18, 256), "altotech.net", fill=(59, 130, 246))

dlg.save(os.path.join(ASSETS, "dialog.bmp"), format="BMP")
print("dialog.bmp OK")

# ── 4. logo_header.png  48×48  (HTML embed source) ───────────────────────────
logo_h = img.copy()
logo_h.thumbnail((48, 48), Image.LANCZOS)
logo_h.save(os.path.join(ASSETS, "logo_header.png"), format="PNG")
print("logo_header.png OK")

# ── 5. Print base64 for HTML injection ───────────────────────────────────────
with open(os.path.join(ASSETS, "logo_header.png"), "rb") as f:
    b64 = base64.b64encode(f.read()).decode()
with open(os.path.join(ASSETS, "logo_header.b64"), "w") as f:
    f.write(b64)
print("logo_header.b64 OK")

print("All assets created.")
