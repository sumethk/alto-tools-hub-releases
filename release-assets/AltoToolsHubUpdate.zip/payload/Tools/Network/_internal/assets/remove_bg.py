"""
Remove white background from logo.png via BFS flood-fill from all 4 corners.
Saves result as logo_transparent.png (RGBA) then overwrites logo.png.
Also regenerates all assets.
"""

import os
from collections import deque

from PIL import Image

ROOT = os.path.join(os.path.dirname(__file__), "..")
SRC = os.path.join(ROOT, "logo.png")
OUT = os.path.join(ROOT, "logo.png")

THRESHOLD = 30  # pixel must be within 30 of white on all channels to be removed

img = Image.open(SRC).convert("RGBA")
data = img.load()
W, H = img.size
print(f"Image: {W}x{H}  mode: {img.mode}")


def is_background(r, g, b, a):
    return r >= 255 - THRESHOLD and g >= 255 - THRESHOLD and b >= 255 - THRESHOLD


# BFS from all 4 corners
visited = set()
queue = deque()

seeds = [(0, 0), (W - 1, 0), (0, H - 1), (W - 1, H - 1)]
for sx, sy in seeds:
    r, g, b, a = data[sx, sy]
    if is_background(r, g, b, a) and (sx, sy) not in visited:
        visited.add((sx, sy))
        queue.append((sx, sy))

while queue:
    x, y = queue.popleft()
    data[x, y] = (255, 255, 255, 0)  # make transparent
    for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
        if 0 <= nx < W and 0 <= ny < H and (nx, ny) not in visited:
            r, g, b, a = data[nx, ny]
            if is_background(r, g, b, a):
                visited.add((nx, ny))
                queue.append((nx, ny))

print(f"Removed {len(visited):,} background pixels")

img.save(OUT, format="PNG")
print(f"Saved: {OUT}  ({os.path.getsize(OUT) // 1024} KB)")

# Quick sanity check
check = Image.open(OUT)
print(f"Result mode: {check.mode}  corner alpha: {check.getpixel((0, 0))[3]}")
