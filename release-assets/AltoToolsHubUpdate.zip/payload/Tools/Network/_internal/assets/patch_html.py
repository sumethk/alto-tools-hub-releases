import os
import re

ROOT = os.path.join(os.path.dirname(__file__), "..")
HTML = os.path.join(ROOT, "templates", "index.html")

with open(os.path.join(ROOT, "assets", "logo_header.b64")) as f:
    b64 = f.read().strip()

with open(HTML, encoding="utf-8") as f:
    html = f.read()

# Replace either existing SVG logo or existing <img> logo in header
new_img = f'<img src="data:image/png;base64,{b64}" alt="Alto Network Scanner" style="height:48px;width:48px;object-fit:contain;border-radius:12px;">'

# Match SVG block
svg_pattern = re.compile(r'<svg[^>]*style="flex-shrink:0"[^>]*>.*?</svg>', re.DOTALL)
if svg_pattern.search(html):
    html = svg_pattern.sub(new_img, html, count=1)
    print("Replaced SVG logo with new PNG")
else:
    # Match base64 img tag
    img_pattern = re.compile(r'<img src="data:image/png;base64,[^"]*"[^>]*>')
    if img_pattern.search(html):
        html = img_pattern.sub(new_img, html, count=1)
        print("Replaced PNG logo with new PNG")
    else:
        print("ERROR: no logo found to replace")
        exit(1)

with open(HTML, "w", encoding="utf-8") as f:
    f.write(html)
print("index.html updated")
