import base64
import io
import os
import re

from PIL import Image

ROOT = os.path.join(os.path.dirname(__file__), "..")
HTML = os.path.join(ROOT, "templates", "index.html")

img = Image.open(os.path.join(ROOT, "logo.png")).convert("RGBA").resize((32, 32), Image.LANCZOS)
buf = io.BytesIO()
img.save(buf, format="PNG")
b64 = base64.b64encode(buf.getvalue()).decode()

favicon_tag = f'<link rel="icon" type="image/png" href="data:image/png;base64,{b64}">'

with open(HTML, encoding="utf-8") as f:
    html = f.read()

# Replace existing favicon if present, otherwise insert after <meta charset>
existing = re.search(r'<link rel="icon"[^>]*>', html)
if existing:
    html = html[: existing.start()] + favicon_tag + html[existing.end() :]
    print("Favicon replaced in index.html")
else:
    old = '  <meta charset="UTF-8" />'
    assert old in html, "meta charset not found"
    html = html.replace(old, f'  <meta charset="UTF-8" />\n  {favicon_tag}', 1)
    print("Favicon added to index.html")

with open(HTML, "w", encoding="utf-8") as f:
    f.write(html)
