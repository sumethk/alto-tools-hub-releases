const modeInputs = Array.from(document.querySelectorAll("input[name='mode']"));
const transportSelect = document.querySelector("#transportSelect");
const tabs = Array.from(document.querySelectorAll(".tab"));
const viewSections = Array.from(document.querySelectorAll(".view-section"));
const ipSettings = document.querySelector("#ipSettings");
const connectionIpSettings = document.querySelector("#connectionIpSettings");
const customSubnetSettings = document.querySelector("#customSubnetSettings");
const customSubnetInput = document.querySelector("#customSubnetInput");
const addCustomSubnetButton = document.querySelector("#addCustomSubnetButton");
const mstpSettings = document.querySelector("#mstpSettings");
const routedGatewaySettings = document.querySelector(".routed-gateway");
const interfaceSelect = document.querySelector("#interfaceSelect");
const subnetSelect = document.querySelector("#subnetSelect");
const serialPortSelect = document.querySelector("#serialPortSelect");
const targetInput = document.querySelector("#targetInput");
const scanTargetInput = document.querySelector("#scanTargetInput");
const portInput = document.querySelector("#portInput");
const scanPortMirror = document.querySelector("#scanPortMirror");
const timeoutInput = document.querySelector("#timeoutInput");
const mstpTimeoutInput = document.querySelector("#mstpTimeoutInput");
const baudrateSelect = document.querySelector("#baudrateSelect");
const mstpMacInput = document.querySelector("#mstpMacInput");
const lowLimitInput = document.querySelector("#lowLimitInput");
const highLimitInput = document.querySelector("#highLimitInput");
const retriesInput = document.querySelector("#retriesInput");
const sourcePortInput = document.querySelector("#sourcePortInput");
const routedRoutersInput = document.querySelector("#routedRoutersInput");
const routedNetworksInput = document.querySelector("#routedNetworksInput");
const routedMacsInput = document.querySelector("#routedMacsInput");
const routedRouterCount = document.querySelector("#routedRouterCount");
const routedNetworkCount = document.querySelector("#routedNetworkCount");
const routedNetworkFilter = document.querySelector("#routedNetworkFilter");
const sourcePortLabel = document.querySelector("#sourcePortLabel");
const globalBroadcastInput = document.querySelector("#globalBroadcastInput");
const globalBroadcastLabel = document.querySelector("#globalBroadcastLabel");
const scanButton = document.querySelector("#scanButton");
const stopScanButton = document.querySelector("#stopScanButton");
const useNetworkButton = document.querySelector("#useNetworkButton");
const clearTargetButton = document.querySelector("#clearTargetButton");
const quickScanButton = document.querySelector("#quickScanButton");
const refreshNetworkButton = document.querySelector("#refreshNetworkButton");
const useGatewayNetworkButton = document.querySelector("#useGatewayNetworkButton");
const selectedTargetBox = document.querySelector("#selectedTargetBox");
const gatewaySubtitle = document.querySelector("#gatewaySubtitle");
const gatewayScanStatus = document.querySelector("#gatewayScanStatus");
const scanPercent = document.querySelector("#scanPercent");
const scanProgressBar = document.querySelector("#scanProgressBar");
const gatewayResultCards = document.querySelector("#gatewayResultCards");
const statusText = document.querySelector("#statusText");
const apiStatus = document.querySelector("#apiStatus");
const modeStatus = document.querySelector("#modeStatus");
const lastScanStatus = document.querySelector("#lastScanStatus");
const connectionSubtitle = document.querySelector("#connectionSubtitle");
const deviceCountPill = document.querySelector("#deviceCountPill");
const deviceCards = document.querySelector("#deviceCards");
const deviceInventorySummary = document.querySelector("#deviceInventorySummary");
const selectedDeviceText = document.querySelector("#selectedDeviceText");
const pointFilterInput = document.querySelector("#pointFilterInput");
const pointSourceFilter = document.querySelector("#pointSourceFilter");
const pointTypeFilter = document.querySelector("#pointTypeFilter");
const pointIdFilter = document.querySelector("#pointIdFilter");
const pointGroupButtons = Array.from(document.querySelectorAll("[data-point-group]"));
const pointTimeoutInput = document.querySelector("#pointTimeoutInput");
const pointReadStrategy = document.querySelector("#pointReadStrategy");
const scanPointsButton = document.querySelector("#scanPointsButton");
const stopPointsButton = document.querySelector("#stopPointsButton");
const covToggleButton = document.querySelector("#covToggleButton");
const exportPointsButton = document.querySelector("#exportPointsButton");
const pointStatus = document.querySelector("#pointStatus");
const pointCountPill = document.querySelector("#pointCountPill");
const pointReadableCount = document.querySelector("#pointReadableCount");
const pointTotalCount = document.querySelector("#pointTotalCount");
const pointEmptyCount = document.querySelector("#pointEmptyCount");
const pointDiagnostics = document.querySelector("#pointDiagnostics");
const pointProgressText = document.querySelector("#pointProgressText");
const pointProgressPercent = document.querySelector("#pointProgressPercent");
const pointProgressBar = document.querySelector("#pointProgressBar");
const pointsBody = document.querySelector("#pointsBody");
const summaryTransport = document.querySelector("#summaryTransport");
const summaryTarget = document.querySelector("#summaryTarget");
const summaryRange = document.querySelector("#summaryRange");
const summaryResponses = document.querySelector("#summaryResponses");
const summaryDuration = document.querySelector("#summaryDuration");
const summaryRequest = document.querySelector("#summaryRequest");
const devicesBody = document.querySelector("#devicesBody");
const deviceScanSection = document.querySelector("#deviceScan");
const deviceScanActivityPanel = document.querySelector("#deviceScanActivity");
const pointScanActivityPanel = document.querySelector("#pointScanActivity");
const scanSummaryPanel = document.querySelector("#scanSummaryPanel") || document.querySelector(".panel.summary");
const bacnetModalBackdrop = document.querySelector("#bacnetModalBackdrop");
const bacnetAdvancedModal = document.querySelector("#bacnetAdvancedModal");
const openBacnetActivityModalBtn = document.querySelector("#openBacnetActivityModalBtn");
const bacnetActivityModalBadge = document.querySelector("#bacnetActivityModalBadge");
const openScanSummaryModalBtn = document.querySelector("#openScanSummaryModalBtn");
const scanSummaryModalBadge = document.querySelector("#scanSummaryModalBadge");
const openAdvancedRouteModalBtn = document.querySelector("#openAdvancedRouteModalBtn");
const advancedRouteBadge = document.querySelector("#advancedRouteBadge");
const advancedRouteSummaryHint = document.querySelector("#advancedRouteSummaryHint");
const gatewayOpenActivityBtn = document.querySelector("#gatewayOpenActivityBtn");
const pointOpenActivityBtn = document.querySelector("#pointOpenActivityBtn");
const pointToolbarActivityBtn = document.querySelector("#pointToolbarActivityBtn");
const inlineDeviceProgressWrap = document.querySelector("#inlineDeviceProgressWrap");
const inlineDeviceProgressBar = document.querySelector("#inlineDeviceProgressBar");
const inlineDeviceProgressPercent = document.querySelector("#inlineDeviceProgressPercent");
const inlinePointProgressWrap = document.querySelector("#inlinePointProgressWrap");
const inlinePointProgressLabel = document.querySelector("#inlinePointProgressLabel");
const inlinePointProgressBar = document.querySelector("#inlinePointProgressBar");
const inlinePointProgressPercent = document.querySelector("#inlinePointProgressPercent");
const bacnetViewportGuard = document.querySelector("#bacnetViewportGuard");
const bacnetViewportSizeReadout = document.querySelector("#bacnetViewportSizeReadout");
let discoveredDevices = [];
let lastDeviceInventoryScope = "";
const DEVICE_RESULT_PREVIEW_LIMIT = 5;
let enabledRoutedNetworks = new Set();
let advertisedRoutedNetworks = new Set();
let selectedDevice = null;
let networkInterfaces = [];
let appliedRoutedCidrOption = null;
let pointRows = [];
let activeScanController = null;
let activeScanJobId = null;
let activeScanStopRequested = false;
let activeScanStopPosted = false;
let activeScanGeneration = 0;
let covTimer = null;
let covPollRunning = false;
let covRunning = false;
let covDeviceKey = "";
let covJobId = null;
let covRequestedCount = 0;
let activePointGroup = "all";
const POST_CONTROL_DELAYS = [200, 700, 1500, 3000, 6000];
let postControlGeneration = 0;
let postControlTimer = null;
let postControlController = null;
let postControlAttempt = 0;
let lastControlledPoint = null;

function createActivityView(root, resultLabel) {
  const role = (name) => root?.querySelector(`[data-activity-role="${name}"]`) || null;
  const phaseNode = role("phase");
  const progressNode = role("progress");
  const elapsedNode = role("elapsed");
  const stateNode = role("state");
  const txNode = role("tx");
  const rxNode = role("rx");
  const timeoutNode = role("timeout");
  const errorNode = role("error");
  const resultNode = role("result");
  const txCard = role("tx-card");
  const rxCard = role("rx-card");
  const timeoutCard = role("timeout-card");
  const errorCard = role("error-card");
  const resultCard = role("result-card");
  const progressTrack = role("activity-progress");
  const timeline = role("timeline");
  const truncationNode = role("truncation");
  const logBody = role("log-body");
  const copyButton = role("copy");
  const downloadButton = role("download");
  const clearButton = role("clear");
  const filterButtons = Array.from(root?.querySelectorAll("[data-activity-filter]") || []);
  const events = new Map();
  let filter = "All";
  let running = false;
  let droppedCount = 0;
  let lastSummary = {};
  let elapsedMs = 0;
  let runningSince = 0;
  let elapsedTimer = null;

  const text = (value) => value === null || value === undefined ? "" : String(value);
  const now = () => performance.now();
  const currentElapsedMs = () => elapsedMs + (running ? Math.max(0, now() - runningSince) : 0);
  const renderElapsed = () => {
    if (elapsedNode) elapsedNode.textContent = `${(currentElapsedMs() / 1000).toFixed(1)}s`;
  };
  const stopElapsedTimer = () => {
    if (elapsedTimer === null) return;
    clearInterval(elapsedTimer);
    elapsedTimer = null;
  };
  const startElapsedTimer = () => {
    if (elapsedTimer !== null) return;
    elapsedTimer = setInterval(renderElapsed, 250);
  };
  const freezeElapsed = () => {
    elapsedMs = currentElapsedMs();
    running = false;
    runningSince = 0;
    stopElapsedTimer();
    root?.classList.remove("running");
    renderElapsed();
  };
  const kindName = (event) => {
    const value = text(event.kind).toLowerCase();
    return value ? value.charAt(0).toUpperCase() + value.slice(1) : "Event";
  };
  const timeText = (event) => {
    const timestamp = text(event.timestamp);
    const separator = timestamp.indexOf("T");
    return separator >= 0 ? timestamp.slice(separator + 1, separator + 13) : timestamp;
  };
  const formatTarget = (target, compact = false) => {
    if (!target || typeof target !== "object") return text(target);
    const address = target.ip ? `${text(target.ip)}${target.port ? `:${text(target.port)}` : ""}` : "";
    const mac = target.mstp_mac ?? target.mac;
    const route = [
      target.network === null || target.network === undefined ? "" : `network ${text(target.network)}`,
      mac === null || mac === undefined ? "" : `MAC ${text(mac)}`,
    ].filter(Boolean).join(" / ");
    if (!target.serial_port) return [address, route].filter(Boolean).join(" · ");

    const baudRate = target.baud_rate ?? target.baudrate;
    const serial = `serial ${text(target.serial_port)}${baudRate === null || baudRate === undefined
      ? ""
      : ` @ ${text(baudRate)} baud`}`;
    const sourceMac = target.source_mac;
    const destinationMac = target.destination_mac;
    const hasPacketMac = sourceMac !== null && sourceMac !== undefined
      || destinationMac !== null && destinationMac !== undefined;
    const directRoute = [
      target.network === null || target.network === undefined ? "" : `network ${text(target.network)}`,
      hasPacketMac || mac === null || mac === undefined ? "" : `MAC ${text(mac)}`,
    ].filter(Boolean).join(" / ");
    const scannerMac = target.scanner_mac;
    const local = scannerMac === null || scannerMac === undefined
      ? ""
      : compact ? `local ${text(scannerMac)}` : `local MAC ${text(scannerMac)}`;
    let packet = "";
    if (sourceMac !== null && sourceMac !== undefined && destinationMac !== null && destinationMac !== undefined) {
      packet = compact
        ? `packet ${text(sourceMac)}→${text(destinationMac)}`
        : `source MAC ${text(sourceMac)} → destination MAC ${text(destinationMac)}`;
    } else if (sourceMac !== null && sourceMac !== undefined) {
      packet = compact ? `source ${text(sourceMac)}` : `source MAC ${text(sourceMac)}`;
    } else if (destinationMac !== null && destinationMac !== undefined) {
      packet = compact ? `destination ${text(destinationMac)}` : `destination MAC ${text(destinationMac)}`;
    }
    const broadcastMode = text(target.broadcast_mode).trim()
      || (target.global_broadcast === true ? "global" : target.global_broadcast === false ? "local" : "");
    const broadcast = broadcastMode ? `${broadcastMode} broadcast` : "";
    return [serial, directRoute, local, packet, broadcast].filter(Boolean).join(" · ");
  };
  const identityText = (event) => [
    event.device_id === null || event.device_id === undefined ? "" : `device ${text(event.device_id)}`,
    text(event.object_id),
    text(event.property || event.property_id),
  ].filter(Boolean).join(" / ");
  const metricsText = (event) => [
    event.duration_ms === null || event.duration_ms === undefined ? "" : `${text(event.duration_ms)} ms`,
    event.response_bytes === null || event.response_bytes === undefined ? "" : `${text(event.response_bytes)} B`,
  ].filter(Boolean).join(" / ");
  const messageText = (event) => text(event.message).trim() || [
    kindName(event),
    text(event.service),
    text(event.phase),
  ].filter(Boolean).join(" · ");
  const compactMessageText = (event) => [
    messageText(event),
    event?.target?.serial_port ? formatTarget(event.target, true) : "",
  ].filter(Boolean).join(" · ");
  const matchesFilter = (event) => {
    const kind = text(event.kind).toLowerCase();
    const direction = text(event.direction).toLowerCase();
    const level = text(event.level).toLowerCase();
    if (filter === "All") return true;
    if (filter === "TX") return kind === "tx" || direction === "tx";
    if (filter === "RX") return kind === "rx" || direction === "rx";
    if (filter === "Timeout") return kind === "timeout";
    return kind === "error" || level === "error" || Boolean(text(event.error));
  };
  const readableLine = (event) => [
    timeText(event),
    kindName(event),
    text(event.phase),
    text(event.service),
    formatTarget(event.target),
    identityText(event),
    metricsText(event),
    text(event.message),
    text(event.error),
  ].filter(Boolean).join(" | ");
  const eventClass = (event) => {
    const kind = text(event.kind).toLowerCase();
    const level = text(event.level).toLowerCase();
    return ["tx", "rx", "timeout", "retry", "error", "discovered", "complete", "cancelled"].includes(kind)
      ? kind
      : level === "error" ? "error" : "event";
  };
  const appendTextCell = (row, value, className = "") => {
    const cell = document.createElement("td");
    cell.className = className;
    cell.textContent = text(value);
    row.append(cell);
    return cell;
  };
  const sortedEvents = () => [...events.values()].sort((left, right) => Number(left.sequence) - Number(right.sequence));
  const setState = (status = "") => {
    if (!stateNode) return;
    const normalized = text(status).toLowerCase();
    const presentation = normalized === "error"
      ? ["Error", "error"]
      : normalized === "done"
        ? ["Complete", "complete"]
        : normalized === "partial"
          ? ["Partial", "warning"]
          : normalized === "cancelled"
            ? ["Stopped", "warning"]
            : running || normalized === "running"
              ? ["Scanning", "running"]
              : ["Ready", "ready"];
    const nextClassName = `activity-state ${presentation[1]}`;
    if (stateNode.textContent !== presentation[0]) stateNode.textContent = presentation[0];
    if (stateNode.className !== nextClassName) stateNode.className = nextClassName;
    if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
  };
  const setCounterCard = (node, baseClass, value) => {
    if (!node) return;
    node.className = `activity-kpi ${baseClass}${Number(value || 0) > 0 ? " active" : ""}`;
  };
  const render = () => {
    if (!timeline || !logBody) return;
    const rows = sortedEvents();
    timeline.replaceChildren();
    for (const event of rows.slice(-12).reverse()) {
      const item = document.createElement("div");
      item.className = `activity-event ${eventClass(event)}`;
      const timestamp = document.createElement("time");
      timestamp.textContent = timeText(event);
      const message = document.createElement("span");
      message.textContent = compactMessageText(event);
      item.append(timestamp, message);
      timeline.append(item);
    }
    timeline.scrollTop = 0;

    logBody.replaceChildren();
    for (const event of rows.filter(matchesFilter).reverse()) {
      const row = document.createElement("tr");
      row.className = `activity-log-row ${eventClass(event)}`;
      appendTextCell(row, timeText(event));
      appendTextCell(row, kindName(event));
      appendTextCell(row, event.phase);
      appendTextCell(row, [text(event.service), formatTarget(event.target)].filter(Boolean).join(" · "));
      appendTextCell(row, identityText(event));
      appendTextCell(row, metricsText(event));
      const messageCell = appendTextCell(row, messageText(event));
      if (event.packet_hex) {
        const packet = document.createElement("details");
        packet.className = "activity-packet";
        const summary = document.createElement("summary");
        summary.textContent = event.packet_truncated ? "Raw packet (first 256 bytes)" : "Raw packet";
        const raw = document.createElement("pre");
        raw.textContent = text(event.packet_hex);
        packet.append(summary, raw);
        messageCell.append(packet);
      }
      if (event.error) {
        const error = document.createElement("div");
        error.className = "activity-error-text";
        error.textContent = text(event.error);
        messageCell.append(error);
      }
      logBody.append(row);
    }
    if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
  };
  const renderSummary = (job) => {
    const counters = job?.counters || {};
    if (txNode) txNode.textContent = `TX ${Number(counters.tx || 0)}`;
    if (rxNode) rxNode.textContent = `RX ${Number(counters.rx || 0)}`;
    if (timeoutNode) timeoutNode.textContent = `Timeout ${Number(counters.timeout || 0)}`;
    if (errorNode) errorNode.textContent = `Error ${Number(counters.error || 0)}`;
    if (resultNode) resultNode.textContent = `${resultLabel} ${Number(counters.discovered || 0)}`;
    setCounterCard(resultCard, "found", counters.discovered);
    setCounterCard(rxCard, "response", counters.rx);
    setCounterCard(txCard, "request", counters.tx);
    setCounterCard(timeoutCard, "timeout", counters.timeout);
    setCounterCard(errorCard, "error", counters.error);
    setState(job?.status);
    const rows = sortedEvents();
    const latest = rows.at(-1);
    if (phaseNode) phaseNode.textContent = text(job?.phase || latest?.phase || "Ready");
    renderElapsed();
    const total = Number(job?.total);
    const completed = Number(job?.completed);
    const terminal = ["done", "partial", "cancelled", "error"].includes(text(job?.status));
    if (Number.isFinite(total) && total > 0 && Number.isFinite(completed)) {
      const roundedPercent = Math.max(0, Math.min(100, Math.round((completed / total) * 100)));
      const percent = completed < total ? Math.min(99, roundedPercent) : roundedPercent;
      const incompleteTerminal = job?.status === "partial" && completed >= total;
      if (progressNode) progressNode.textContent = incompleteTerminal
        ? `Partial (${completed}/${total})`
        : `${percent}% (${completed}/${total})`;
      progressTrack?.classList.remove("indeterminate");
      if (progressTrack?.children?.[0]) {
        progressTrack.children[0].style.width = incompleteTerminal ? "0%" : `${percent}%`;
      }
    } else {
      if (progressNode) progressNode.textContent = job?.status === "error"
        ? "Failed"
        : job?.status === "cancelled"
          ? "Stopped"
          : terminal
            ? "Complete"
            : running ? "Working" : "Idle";
      progressTrack?.classList.toggle("indeterminate", running && !terminal);
      if (progressTrack?.children?.[0] && terminal) {
        progressTrack.children[0].style.width = job?.status === "done" ? "100%" : "0%";
      }
    }
    if (truncationNode) {
      truncationNode.textContent = droppedCount ? `${droppedCount} earlier events dropped` : "";
      truncationNode.hidden = droppedCount === 0;
    }
    if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
  };
  const setFilter = (nextFilter) => {
    filter = ["All", "TX", "RX", "Timeout", "Error"].includes(nextFilter) ? nextFilter : "All";
    for (const button of filterButtons) {
      const pressed = button.dataset.activityFilter === filter;
      button.classList.toggle("active", pressed);
      button.setAttribute("aria-pressed", String(pressed));
    }
    render();
  };
  const reset = () => {
    stopElapsedTimer();
    running = false;
    runningSince = 0;
    elapsedMs = 0;
    root?.classList.remove("running");
    events.clear();
    filter = "All";
    droppedCount = 0;
    lastSummary = {};
    if (phaseNode) phaseNode.textContent = "Ready";
    if (progressNode) progressNode.textContent = "Idle";
    if (elapsedNode) elapsedNode.textContent = "0.0s";
    for (const [node, label] of [[txNode, "TX"], [rxNode, "RX"], [timeoutNode, "Timeout"], [errorNode, "Error"]]) {
      if (node) node.textContent = `${label} 0`;
    }
    if (resultNode) resultNode.textContent = `${resultLabel} 0`;
    setState();
    setCounterCard(resultCard, "found", 0);
    setCounterCard(rxCard, "response", 0);
    setCounterCard(txCard, "request", 0);
    setCounterCard(timeoutCard, "timeout", 0);
    setCounterCard(errorCard, "error", 0);
    progressTrack?.classList.remove("indeterminate");
    if (progressTrack?.children?.[0]) progressTrack.children[0].style.width = "0%";
    if (truncationNode) {
      truncationNode.textContent = "";
      truncationNode.hidden = true;
    }
    setFilter("All");
  };
  const append = (job = {}) => {
    const first = Number(job.first_sequence);
    if (Number.isFinite(first) && Number(job.dropped_count || 0) > 0) {
      for (const sequence of events.keys()) if (sequence < first) events.delete(sequence);
    }
    for (const event of Array.isArray(job.activities) ? job.activities : []) {
      const sequence = Number(event?.sequence);
      if (Number.isFinite(sequence)) events.set(sequence, {...event});
    }
    while (events.size > 1000) events.delete(events.keys().next().value);
    droppedCount = Math.max(droppedCount, Number(job.dropped_count || 0));
    const current = currentElapsedMs();
    const latest = sortedEvents().at(-1);
    const reportedElapsed = Number(latest?.elapsed_ms);
    elapsedMs = Number.isFinite(reportedElapsed) ? Math.max(current, reportedElapsed) : current;
    if (running) runningSince = now();
    lastSummary = {...job};
    if (["done", "partial", "cancelled", "error"].includes(text(job.status))) freezeElapsed();
    renderSummary(job);
    render();
  };
  const setTerminal = (status, phase = status) => {
    const normalized = text(status).toLowerCase();
    if (!["done", "partial", "cancelled", "error"].includes(normalized)) return;
    lastSummary = {
      ...lastSummary,
      status: normalized,
      phase: text(phase) || lastSummary.phase,
    };
    freezeElapsed();
    renderSummary(lastSummary);
    render();
  };
  const setRunning = (value) => {
    const nextRunning = Boolean(value);
    if (nextRunning && !running) {
      running = true;
      runningSince = now();
      startElapsedTimer();
    } else if (!nextRunning && running) {
      freezeElapsed();
    }
    root?.classList.toggle("running", running);
    renderSummary(lastSummary);
  };
  const copy = () => {
    const output = sortedEvents().filter(matchesFilter).map(readableLine).join("\n");
    if (navigator?.clipboard?.writeText) void navigator.clipboard.writeText(output);
    return output;
  };
  const download = (summary = {}) => {
    const output = JSON.stringify({summary, activities: sortedEvents()}, null, 2);
    const blob = new Blob([output], {type: "application/json"});
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `bacnet-activity-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(link.href);
    return output;
  };
  const clear = () => {
    events.clear();
    droppedCount = 0;
    if (truncationNode) {
      truncationNode.textContent = "";
      truncationNode.hidden = true;
    }
    render();
  };

  for (const button of filterButtons) button.addEventListener("click", () => setFilter(button.dataset.activityFilter));
  copyButton?.addEventListener("click", copy);
  downloadButton?.addEventListener("click", () => download(lastSummary));
  clearButton?.addEventListener("click", clear);
  reset();
  return {reset, append, setTerminal, setRunning, setFilter, copy, download};
}

const deviceActivityView = createActivityView(document.querySelector("#deviceScanActivity"), "Devices");
const pointActivityView = createActivityView(document.querySelector("#pointScanActivity"), "Points");

function normalizeView(view) {
  return ["deviceScan", "devicesPanel", "pointScan"].includes(view) ? view : "deviceScan";
}

function setActiveView(view, options = {}) {
  const activeView = normalizeView(view);
  for (const section of viewSections) {
    const views = (section.dataset.view || "").split(/\s+/);
    section.classList.toggle("view-hidden", !views.includes(activeView));
  }
  for (const tab of tabs) {
    tab.classList.toggle("active", tab.getAttribute("href") === `#${activeView}`);
  }
  if (options.updateHash !== false && window.location.hash !== `#${activeView}`) {
    history.pushState(null, "", `#${activeView}`);
  }
  if (options.scroll !== false) {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  if (typeof syncModalParentVisibility === "function") syncModalParentVisibility();
  if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
}

function navigateToView(view) {
  setActiveView(view);
}

async function loadInterfaces() {
  try {
    const response = await fetch("/api/network/interfaces");
    const interfaces = await response.json();
    networkInterfaces = interfaces;
    interfaceSelect.replaceChildren();

    for (const [index, item] of interfaces.entries()) {
      const label = interfaceOptionLabel(item);
      const option = new Option(label, String(index));
      option.dataset.interfaceIndex = String(index);
      option.dataset.role = item.scan_role || "local";
      option.dataset.address = item.address;
      option.dataset.prefixLength = item.prefix_length;
      option.dataset.scanNetwork = item.scan_network || "";
      option.dataset.scanPrefixLength = item.scan_prefix_length || "";
      option.dataset.scanTarget = item.scan_target || item.broadcast;
      if (item.is_default) {
        option.selected = true;
      }
      interfaceSelect.append(option);
    }
    const manualOption = new Option("Manual global broadcast - 255.255.255.255", "manual-global");
    manualOption.dataset.scanTarget = "255.255.255.255";
    manualOption.dataset.scanNetwork = "255.255.255.255";
    manualOption.dataset.scanPrefixLength = "32";
    interfaceSelect.append(manualOption);
    const selected = interfaceSelect.selectedOptions[0] || interfaceSelect.options[0];
    if (selected) {
      scanTargetInput.value = selected.dataset.scanTarget || "255.255.255.255";
      interfaceSelect.value = selected.value;
    }
    updateSubnetSelect();
    apiStatus.textContent = "API ready";
    apiStatus.className = "pill ok";
  } catch {
    networkInterfaces = [];
    interfaceSelect.replaceChildren(new Option("Global broadcast - 255.255.255.255", "255.255.255.255"));
    subnetSelect.replaceChildren(new Option("255.255.255.255", "255.255.255.255"));
    apiStatus.textContent = "API limited";
    apiStatus.className = "pill warn";
  } finally {
    updateSelectedTargetBox();
    updateSummary();
  }
}

function interfaceOptionLabel(item) {
  const isDown = item.is_up === false || item.isUp === false;
  const interfaceSubnet = `${item.address}/${item.prefix_length}`;
  const scanSubnet = item.scan_network && item.scan_prefix_length != null ? `${item.scan_network}/${item.scan_prefix_length}` : interfaceSubnet;
  const subnet = item.interface_subnet || (item.scan_role === "vpn" ? interfaceSubnet : scanSubnet);
  return `${item.name} \u2014 ${item.address} (${subnet})${isDown ? " [Offline]" : ""}`;
}

function selectedInterfaceItem() {
  const option = interfaceSelect.selectedOptions[0];
  if (!option) {
    return null;
  }
  const index = Number.parseInt(option.dataset.interfaceIndex || "", 10);
  if (Number.isFinite(index) && networkInterfaces[index]) {
    return networkInterfaces[index];
  }
  return (
    networkInterfaces.find(
      (item) =>
        String(item.address) === option.dataset.address &&
        String(item.prefix_length) === option.dataset.prefixLength &&
        String(item.scan_target || item.broadcast) === option.dataset.scanTarget,
    ) || null
  );
}

function ipv4ToUint32(address) {
  return address
    .split(".")
    .reduce((result, octet) => ((result << 8) | Number(octet)) >>> 0, 0);
}

function uint32ToIpv4(value) {
  return [24, 16, 8, 0].map((shift) => (value >>> shift) & 255).join(".");
}

function parseIpv4Cidr(value) {
  const match = String(value || "").trim().match(/^(\d{1,3}(?:\.\d{1,3}){3})\/(\d{1,2})$/);
  if (!match) return null;
  const octets = match[1].split(".").map(Number);
  const prefixLength = Number(match[2]);
  if (
    octets.some((octet) => !Number.isInteger(octet) || octet < 0 || octet > 255)
    || !Number.isInteger(prefixLength)
    || prefixLength < 0
    || prefixLength > 32
  ) return null;
  const addressValue = ipv4ToUint32(match[1]);
  const mask = prefixLength === 0 ? 0 : (0xffffffff << (32 - prefixLength)) >>> 0;
  const networkValue = (addressValue & mask) >>> 0;
  const broadcastValue = (networkValue | (~mask >>> 0)) >>> 0;
  const network = uint32ToIpv4(networkValue);
  return {
    cidr: `${network}/${prefixLength}`,
    network,
    target: uint32ToIpv4(broadcastValue),
    prefixLength,
    hostCount: hostCount(prefixLength),
  };
}

function addCustomSubnet() {
  const item = selectedInterfaceItem();
  if (!item) {
    customSubnetInput.setCustomValidity("Select a network interface first.");
    customSubnetInput.reportValidity();
    return;
  }
  const parsed = parseIpv4Cidr(customSubnetInput.value);
  if (!parsed) {
    customSubnetInput.setCustomValidity(
      "Enter a valid IPv4 CIDR, for example 192.168.2.0/24.",
    );
    customSubnetInput.reportValidity();
    return;
  }
  customSubnetInput.setCustomValidity("");
  appliedRoutedCidrOption = parsed;
  customSubnetInput.value = "";
  updateSubnetSelect(parsed.cidr);
  updateSummary();
  flashCustomSubnetAdded();
}

const addCustomSubnetLabel = addCustomSubnetButton.textContent.trim();
let customSubnetFeedbackTimer = 0;

function flashCustomSubnetAdded() {
  addCustomSubnetButton.textContent = `Applied — scanning ${appliedRoutedCidrOption?.cidr || ""}`;
  addCustomSubnetButton.classList.add("applied");
  subnetSelect.classList.add("applied");
  window.clearTimeout(customSubnetFeedbackTimer);
  customSubnetFeedbackTimer = window.setTimeout(() => {
    addCustomSubnetButton.textContent = addCustomSubnetLabel;
    addCustomSubnetButton.classList.remove("applied");
    subnetSelect.classList.remove("applied");
  }, 2400);
}

function appendSubnetOption(optionItem, custom = false) {
  const prefixLength = optionItem.prefixLength ?? optionItem.prefix_length;
  const count = optionItem.hostCount ?? optionItem.host_count ?? hostCount(prefixLength);
  const option = new Option(
    `${optionItem.cidr} (${Number(count).toLocaleString()} hosts)`,
    optionItem.target,
  );
  option.dataset.scanNetwork = optionItem.network;
  option.dataset.scanPrefixLength = prefixLength;
  option.dataset.cidr = optionItem.cidr;
  if (custom) option.dataset.custom = "true";
  subnetSelect.append(option);
  return option;
}

function updateSubnetSelect(preferredCidr = subnetSelect.selectedOptions[0]?.dataset.cidr || "") {
  subnetSelect.replaceChildren();
  const knownCidrs = new Set();
  const item = selectedInterfaceItem();
  const options = item
    ? (
      Array.isArray(item.scan_options) && item.scan_options.length
        ? item.scan_options
        : [defaultSubnetOption(item)]
    )
    : [];

  for (const optionItem of options) {
    appendSubnetOption(optionItem);
    knownCidrs.add(optionItem.cidr);
  }
  if (appliedRoutedCidrOption && !knownCidrs.has(appliedRoutedCidrOption.cidr)) {
    appendSubnetOption(appliedRoutedCidrOption, true);
    knownCidrs.add(appliedRoutedCidrOption.cidr);
  }
  if (!subnetSelect.options.length) {
    const target = interfaceSelect.selectedOptions[0]?.dataset.scanTarget
      || scanTargetInput.value
      || "255.255.255.255";
    appendSubnetOption({
      cidr: `${target}/32`,
      network: target,
      target,
      prefixLength: 32,
      hostCount: 1,
    });
  }
  const preferredIndex = Array.from(subnetSelect.options).findIndex(
    (option) => option.dataset.cidr === preferredCidr,
  );
  subnetSelect.selectedIndex = preferredIndex >= 0 ? preferredIndex : 0;
  syncTargetFromSubnet();
}

function defaultSubnetOption(item) {
  const network = item.scan_network || item.address;
  const prefixLength = item.scan_prefix_length ?? item.prefix_length;
  return {
    network,
    prefix_length: prefixLength,
    target: item.scan_target || item.broadcast,
    cidr: `${network}/${prefixLength}`,
    host_count: hostCount(prefixLength),
  };
}

function syncTargetFromSubnet() {
  const value = subnetSelect.value || interfaceSelect.selectedOptions[0]?.dataset.scanTarget || "255.255.255.255";
  scanTargetInput.value = value;
}

function hostCount(prefixLength) {
  const prefix = Number(prefixLength);
  if (!Number.isFinite(prefix)) {
    return 0;
  }
  if (prefix >= 31) {
    return 1;
  }
  return Math.max(0, 2 ** (32 - prefix) - 2);
}

async function loadSerialPorts() {
  try {
    const response = await fetch("/api/serial/ports");
    const ports = await response.json();
    serialPortSelect.replaceChildren();

    if (!ports.length) {
      serialPortSelect.append(new Option("No serial ports found", ""));
      return;
    }

    for (const item of ports) {
      const label = item.description ? `${item.device} - ${item.description}` : item.device;
      serialPortSelect.append(new Option(label, item.device));
    }
  } catch {
    serialPortSelect.replaceChildren(new Option("Serial ports unavailable", ""));
  } finally {
    updateSummary();
  }
}

function optionalNumber(input) {
  return input.value.trim() === "" ? null : Number(input.value);
}

function setStatus(text, state = "idle") {
  statusText.textContent = text;
  statusText.dataset.state = state;
  gatewayScanStatus.textContent = text;
  gatewayScanStatus.dataset.state = state;
  if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
}

function activeMode() {
  if (transportSelect?.value) {
    return transportSelect.value;
  }
  return modeInputs.find((input) => input.checked)?.value || "ip";
}

function formatDeviceAddress(device) {
  if (device.transport === "mstp") {
    return `${device.serial_port || "MS/TP"} MAC ${device.mstp_mac ?? ""}`;
  }
  return `${device.ip || ""}:${device.port || ""}`;
}

function objectTypeLabel(objectType) {
  if (objectType === 8) {
    return "Device (8)";
  }
  return objectType ?? "";
}

const SITE_DEVICE_PROFILES = {
  1: { name: "Chiller 1 - HOLIDAY INN CH1 - E26A06544", vendor: "Trane", model: "RTHD", network: 1, mac: "10.22.36.249:0xBAC0" },
  3: { name: "Chiller 3 - HOLIDAY INN CH-3 RTHD - F25M19454", vendor: "Trane", model: "RTHD", network: 1, mac: "10.22.36.99:0xBAC0" },
  4: { name: "SCHWP-B-02-AC DRIVE 4", vendor: "ABB", model: "ACH550", network: 2, mac: 4 },
  5: { name: "SCHWP-B-03-AC DRIVE 5", vendor: "ABB", model: "ACH550", network: 2, mac: 5 },
  6: { name: "SCHWP-B-04-AC DRIVE 6", vendor: "ABB", model: "ACH550", network: 2, mac: 6 },
  16: { name: "SCHWP-B-01-AC DRIVE 3", vendor: "ABB", model: "ACH550", network: 2, mac: 16 },
  500: { name: "CPMS Existing", vendor: "JCI", model: "MS-NAE3511-2", network: 1, mac: "10.100.100.127:0xBAC0" },
  1007: { name: "CT-03-2-AC Drive 1007", vendor: "ABB", model: "ACH580", network: 2, mac: 7 },
  1008: { name: "CT-03-1-AC Drive 1008", vendor: "ABB", model: "ACH580", network: 2, mac: 8 },
  1009: { name: "CT-02-2-AC Drive 1009", vendor: "ABB", model: "ACH580", network: 2, mac: 9 },
  1010: { name: "CT-02-1-AC Drive 1010", vendor: "ABB", model: "ACH580", network: 2, mac: 10 },
  1011: { name: "CT-01-2-AC Drive 1011", vendor: "ABB", model: "ACH580", network: 2, mac: 11 },
  1012: { name: "CT-01-1-AC Drive 1012", vendor: "ABB", model: "ACH580", network: 2, mac: 12 },
  1013: { name: "CWP-B-01-AC Drive 1013", vendor: "ABB", model: "ACH580", network: 2, mac: 13 },
  1014: { name: "CWP-B-02-AC Drive 1014", vendor: "ABB", model: "ACH580", network: 2, mac: 14 },
  1015: { name: "CWP-B-03-AC Drive 1015", vendor: "ABB", model: "ACH580", network: 2, mac: 15 },
  5002: { name: "Chiller 2 - YK SSS IM-G 5002", vendor: "JCI", model: "ELINK", network: 3, mac: 2 },
  57017: { name: "BTU 2 High Zone - System-20 - 001289611", vendor: "ONICON Inc", model: "System-20-BAC", network: 2, mac: 17 },
  57018: { name: "BTU 1 Low Zone - System-20 - 001289611", vendor: "ONICON Inc", model: "System-20-BAC", network: 2, mac: 18 },
};

const VENDOR_ID_LABELS = {
  2: "Trane",
  5: "JCI",
  127: "ABB",
  206: "ONICON Inc",
};

function siteDeviceProfile(device) {
  return SITE_DEVICE_PROFILES[Number(device.device_id)] || {};
}

function deviceName(device) {
  const profile = siteDeviceProfile(device);
  return device.device_name || profile.name || `Device ${device.device_id ?? "-"}`;
}

function vendorLabel(device) {
  const profile = siteDeviceProfile(device);
  return device.vendor_name || profile.vendor || VENDOR_ID_LABELS[Number(device.vendor_id)] || (device.vendor_id != null ? `Vendor ${device.vendor_id}` : "Unknown vendor");
}

function modelLabel(device) {
  const profile = siteDeviceProfile(device);
  return device.model_name || profile.model || "Unknown model";
}

function networkLabel(device) {
  const profile = siteDeviceProfile(device);
  return device.network_number ?? profile.network ?? "-";
}

function macLabel(device) {
  const profile = siteDeviceProfile(device);
  return device.mac_address ?? profile.mac ?? "-";
}

function deviceStatusLabel(device) {
  const mode = (device.transport || "ip").toUpperCase();
  const segmentation = device.segmentation_name || "segmentation unknown";
  const freshness = device.seen_in_latest_scan === false ? "Not seen in latest scan · " : "";
  return `${freshness}${mode} / ${segmentation}`;
}

function deviceSummaryLine(device) {
  return `${vendorLabel(device)} - ${modelLabel(device)}`;
}

function appendCardText(card, tagName, value) {
  const element = document.createElement(tagName);
  element.textContent = String(value ?? "");
  card.append(element);
}

function renderInventorySummary(devices) {
  if (!deviceInventorySummary) return;
  const vendors = new Set(devices.map(vendorLabel).filter(Boolean));
  const models = new Set(devices.map(modelLabel).filter((value) => value && value !== "Unknown model"));
  deviceInventorySummary.innerHTML = `
    <div>
      <strong>${devices.length}</strong>
      <span>Total devices</span>
    </div>
    <div>
      <strong>${vendors.size || "-"}</strong>
      <span>Vendors</span>
    </div>
    <div>
      <strong>${models.size || "-"}</strong>
      <span>Models</span>
    </div>
  `;
}

function pointScanDevices(devices, enabledNetworks, advertisedNetworks) {
  return devices.filter((device) => {
    if (device.network_number == null) {
      return true;
    }
    const network = Number(device.network_number);
    return !advertisedNetworks.has(network) || enabledNetworks.has(network);
  });
}

function inventoryCountLabel(devices, selectableCount) {
  const latestCount = devices.filter((device) => device.seen_in_latest_scan !== false).length;
  if (latestCount < devices.length) {
    return `${latestCount} seen / ${devices.length} known`;
  }
  return selectableCount === devices.length
    ? `${devices.length} found`
    : `${selectableCount}/${devices.length} selectable`;
}

function renderDevices(devices) {
  discoveredDevices = devices;
  const selectableDevices = pointScanDevices(
    devices,
    enabledRoutedNetworks,
    advertisedRoutedNetworks,
  );
  devicesBody.replaceChildren();
  deviceCountPill.textContent = inventoryCountLabel(devices, selectableDevices.length);
  renderInventorySummary(devices);
  renderDeviceCards(selectableDevices);

  if (!devices.length) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 9;
    cell.className = "empty";
    cell.textContent = "No BACnet devices answered.";
    row.append(cell);
    devicesBody.append(row);
    return;
  }

  for (const device of devices) {
    const row = document.createElement("tr");
    const selectable = pointScanDevices(
      [device],
      enabledRoutedNetworks,
      advertisedRoutedNetworks,
    ).length > 0;
    const values = [
      deviceName(device),
      device.device_id,
      networkLabel(device),
      macLabel(device),
      vendorLabel(device),
      modelLabel(device),
      device.address || formatDeviceAddress(device),
      device.max_apdu ?? "",
      deviceStatusLabel(device),
    ];
    for (const value of values) {
      const cell = document.createElement("td");
      cell.textContent = value;
      row.append(cell);
    }
    row.className = selectable ? "device-row" : "device-row routed-disabled";
    if (device.seen_in_latest_scan === false) {
      row.classList.add("scan-stale");
    }
    if (selectable) {
      row.addEventListener("click", () => {
        selectedDevice = device;
        renderDeviceCards(
          pointScanDevices(
            discoveredDevices,
            enabledRoutedNetworks,
            advertisedRoutedNetworks,
          ),
        );
        updateSelectedDevice();
        navigateToView("pointScan");
      });
    } else {
      row.title = "Enable this remote network before scanning points";
    }
    devicesBody.append(row);
  }
}

function renderGatewayCards(devices, options = {}) {
  const {
    emptyMessage = "Scan a subnet to discover BACnet devices.",
    inventoryCount = devices.length,
  } = options;
  gatewayResultCards.replaceChildren();
  if (!devices.length) {
    const empty = document.createElement("div");
    empty.className = "empty-mini";
    empty.textContent = emptyMessage;
    gatewayResultCards.append(empty);
    return;
  }

  const summary = document.createElement("div");
  summary.className = "gateway-result-summary";
  const vendors = new Set(devices.map(vendorLabel).filter(Boolean));
  const latestCount = devices.filter((device) => device.seen_in_latest_scan !== false).length;
  summary.innerHTML = `
    <strong>${latestCount}</strong>
    <span>${latestCount < devices.length ? `seen / ${devices.length} known` : "devices found"}</span>
    <em>${vendors.size || 0} vendor${vendors.size === 1 ? "" : "s"}</em>
  `;
  const list = document.createElement("div");
  list.className = "gateway-result-list";

  for (const device of devices.slice(0, DEVICE_RESULT_PREVIEW_LIMIT)) {
    const card = document.createElement("button");
    card.type = "button";
    card.className = "gateway-result-card";
    if (device.seen_in_latest_scan === false) {
      card.classList.add("scan-stale");
    }
    const address = device.address || formatDeviceAddress(device);
    const summaryText = deviceSummaryLine(device);
    card.title = `${deviceName(device)} | ${address} | ${summaryText}`;
    appendCardText(card, "strong", deviceName(device));
    appendCardText(card, "span", address);
    appendCardText(card, "em", summaryText);
    card.addEventListener("click", () => {
      if (
        !pointScanDevices(
          [device],
          enabledRoutedNetworks,
          advertisedRoutedNetworks,
        ).length
      ) {
        return;
      }
      selectedDevice = device;
      renderDeviceCards(
        pointScanDevices(
          discoveredDevices,
          enabledRoutedNetworks,
          advertisedRoutedNetworks,
        ),
      );
      updateSelectedDevice();
      navigateToView("pointScan");
    });
    list.append(card);
  }

  if (inventoryCount > Math.min(devices.length, DEVICE_RESULT_PREVIEW_LIMIT)) {
    const viewAll = document.createElement("button");
    viewAll.type = "button";
    viewAll.className = "gateway-result-more";
    viewAll.textContent = `View all ${inventoryCount} devices`;
    viewAll.addEventListener("click", () => navigateToView("devicesPanel"));
    list.append(viewAll);
  }

  gatewayResultCards.append(summary, list);
}

function renderDeviceCards(devices) {
  deviceCards.replaceChildren();
  if (!devices.length) {
    const empty = document.createElement("div");
    empty.className = "empty-card";
    empty.textContent = "Scan devices to populate this list.";
    deviceCards.append(empty);
    selectedDevice = null;
    updateSelectedDevice();
    return;
  }

  for (const device of devices) {
    const card = document.createElement("button");
    card.type = "button";
    card.className = "device-card";
    if (device.seen_in_latest_scan === false) {
      card.classList.add("scan-stale");
    }
    if (selectedDevice && sameDevice(selectedDevice, device)) {
      card.classList.add("selected");
    }
    appendCardText(card, "strong", deviceName(device));
    appendCardText(card, "span", vendorLabel(device));
    appendCardText(card, "em", `${modelLabel(device)} / ID ${device.device_id}`);
    card.addEventListener("click", () => {
      selectedDevice = device;
      renderDeviceCards(
        pointScanDevices(
          discoveredDevices,
          enabledRoutedNetworks,
          advertisedRoutedNetworks,
        ),
      );
      updateSelectedDevice();
      navigateToView("pointScan");
    });
    deviceCards.append(card);
  }
}

function sameDevice(left, right) {
  return left.device_id === right.device_id
    && (left.network_number ?? null) === (right.network_number ?? null)
    && (left.mac_address ?? null) === (right.mac_address ?? null)
    && (left.ip ?? null) === (right.ip ?? null)
    && (left.port ?? null) === (right.port ?? null)
    && (left.mstp_mac ?? null) === (right.mstp_mac ?? null)
    && (left.serial_port ?? null) === (right.serial_port ?? null);
}

function mergeScanDevices(previousDevices, latestDevices) {
  const merged = previousDevices.map((device) => ({
    ...device,
    seen_in_latest_scan: false,
  }));
  for (const device of latestDevices) {
    const latest = { ...device, seen_in_latest_scan: true };
    const existingIndex = merged.findIndex((candidate) => sameDevice(candidate, latest));
    if (existingIndex >= 0) {
      merged[existingIndex] = latest;
    } else {
      merged.push(latest);
    }
  }
  return merged;
}

function scanInventoryScope(payload) {
  if (payload.mode === "mstp") {
    return JSON.stringify([
      "mstp",
      String(payload.serial_port || ""),
      Number(payload.baudrate || 0),
      Boolean(payload.global_broadcast),
    ]);
  }
  const targets = payload.subnet_scan
    ? (Array.isArray(payload.scan_cidrs) && payload.scan_cidrs.length
      ? payload.scan_cidrs
      : [payload.scan_cidr])
    : [payload.target];
  return JSON.stringify([
    "ip",
    Number(payload.port || 47808),
    targets.map((target) => String(target || "")),
    String(payload.routed_routers || ""),
    String(payload.routed_networks || ""),
    String(payload.routed_macs || ""),
  ]);
}

function mergeScanInventory(previousScope, currentScope, previousDevices, latestDevices) {
  const sameScopeDevices = previousScope === currentScope ? previousDevices : [];
  return mergeScanDevices(sameScopeDevices, latestDevices);
}

function deviceRuntimeKey(device) {
  if (!device) {
    return "";
  }
  return [device.ip || "", device.port || "", device.network_number ?? "", device.mac_address ?? "", device.device_id ?? ""].join("|");
}

function canScanDevicePoints(device) {
  return Boolean(device && device.ip);
}

function updateSelectedDevice() {
  cancelPostControlRefresh();
  if (!selectedDevice) {
    stopCovLive();
    selectedDeviceText.textContent = "Select a BACnet/IP device from Devices first.";
    scanPointsButton.disabled = true;
    updateCovButton();
    return;
  }
  if (covRunning && covDeviceKey && covDeviceKey !== deviceRuntimeKey(selectedDevice)) {
    stopCovLive();
  }
  selectedDeviceText.textContent = `${deviceName(selectedDevice)} - ${selectedDevice.address || formatDeviceAddress(selectedDevice)} - ID ${selectedDevice.device_id}`;
  scanPointsButton.disabled = !canScanDevicePoints(selectedDevice);
  updateCovButton();
  if (!canScanDevicePoints(selectedDevice)) {
    pointStatus.textContent = "Serial MS/TP point scan needs an IP router path";
    pointStatus.className = "pill warn";
  }
}

function deviceRangeLabel() {
  const low = optionalNumber(lowLimitInput);
  const high = optionalNumber(highLimitInput);
  if (low === null && high === null) {
    return "All device IDs";
  }
  if (low === null || high === null) {
    return "Range incomplete";
  }
  return `${low} - ${high}`;
}

function updateSummary() {
  if (typeof updateAdvancedRouteBadge === "function") updateAdvancedRouteBadge();
  const mstp = activeMode() === "mstp";
  summaryTransport.textContent = mstp ? "BACnet MS/TP" : "BACnet/IP";
  summaryRange.textContent = deviceRangeLabel();
  summaryRequest.textContent = mstp
    ? globalBroadcastInput.checked
      ? "Who-Is global broadcast"
      : "Who-Is local MS/TP broadcast"
    : hasRoutedScan()
      ? isAutoRemoteNetworkMode()
        ? "Who-Is subnet + smart routed MS/TP sweep"
        : "Who-Is subnet + routed MS/TP sweep"
      : shouldAutoSubnetScan()
      ? "Who-Is unicast subnet sweep"
      : "Who-Is UDP broadcast";

  if (mstp) {
    const port = serialPortSelect.value || "No COM port";
    summaryTarget.textContent = `${port} @ ${baudrateSelect.value} baud, MAC ${mstpMacInput.value || 127}`;
    connectionSubtitle.textContent = "BACnet MS/TP serial scan over RS-485";
    modeStatus.textContent = "BACnet MS/TP";
  } else {
    summaryTarget.textContent = `${scanTargetInput.value || targetInput.value || "255.255.255.255"}:${portInput.value || 47808}`;
    connectionSubtitle.textContent = "BACnet/IP UDP broadcast scan";
    gatewaySubtitle.textContent = gatewaySubtitleText();
    modeStatus.textContent = "BACnet/IP";
  }
}

function gatewaySubtitleText() {
  const item = selectedInterfaceItem();
  if (!item) {
    return `Manual target - scan ${scanTargetInput.value || targetInput.value || "255.255.255.255"}`;
  }
  const subnetOption = subnetSelect.selectedOptions[0];
  const scanCidr = subnetOption?.dataset.cidr || `${item.scan_network || item.address}/${item.scan_prefix_length ?? item.prefix_length}`;
  return `${item.name} ${item.address}/${item.prefix_length} - scan ${scanCidr}`;
}

function selectedScanCidr() {
  const subnetOption = subnetSelect.selectedOptions[0];
  if (subnetOption?.dataset.scanNetwork && subnetOption?.dataset.scanPrefixLength) {
    return `${subnetOption.dataset.scanNetwork}/${subnetOption.dataset.scanPrefixLength}`;
  }

  const item = selectedInterfaceItem();
  if (item) {
    const scanNetwork = item.scan_network || item.address;
    const scanPrefix = item.scan_prefix_length ?? item.prefix_length;
    return `${scanNetwork}/${scanPrefix}`;
  }

  const option = interfaceSelect.selectedOptions[0];
  if (option?.dataset.scanNetwork && option?.dataset.scanPrefixLength) {
    return `${option.dataset.scanNetwork}/${option.dataset.scanPrefixLength}`;
  }

  const target = scanTargetInput.value.trim() || targetInput.value.trim() || "255.255.255.255";
  return target.includes("/") ? target : `${target}/32`;
}

function selectedScanCidrs() {
  return [selectedScanCidr()];
}

function shouldAutoSubnetScan() {
  if (activeMode() !== "ip") {
    return false;
  }
  const subnetOption = subnetSelect.selectedOptions[0];
  const item = selectedInterfaceItem();
  const prefix = Number(
    subnetOption?.dataset.scanPrefixLength
      ?? item?.scan_prefix_length
      ?? item?.prefix_length,
  );
  return Number.isFinite(prefix) && prefix < 31;
}

function hasRoutedScan() {
  return Boolean(routedRoutersInput.value.trim() || routedNetworksInput.value.trim());
}

function isAutoRemoteNetworkMode() {
  const value = routedNetworksInput.value.trim().toLowerCase();
  return value === "auto" || (!value && Boolean(routedRoutersInput.value.trim()));
}

function syncMode() {
  const mstp = activeMode() === "mstp";
  for (const input of modeInputs) {
    input.checked = input.value === activeMode();
  }
  ipSettings.classList.toggle("hidden", mstp);
  customSubnetSettings.classList.toggle("hidden", mstp);
  connectionIpSettings.classList.toggle("hidden", mstp);
  mstpSettings.classList.toggle("hidden", !mstp);
  routedGatewaySettings.classList.toggle("hidden", mstp);
  sourcePortLabel.classList.toggle("hidden", mstp);
  globalBroadcastLabel.classList.toggle("hidden", !mstp);
  updateSummary();
}

function scanPayload(options = {}) {
  const payload = {
    mode: activeMode(),
    retries: Number(retriesInput.value || 1),
    low_limit: optionalNumber(lowLimitInput),
    high_limit: optionalNumber(highLimitInput),
  };

  if (payload.mode === "mstp") {
    payload.serial_port = serialPortSelect.value;
    payload.baudrate = Number(baudrateSelect.value || 38400);
    payload.mac = Number(mstpMacInput.value || 127);
    payload.timeout = Number(mstpTimeoutInput.value || 5);
    payload.global_broadcast = globalBroadcastInput.checked;
  } else {
    payload.target = scanTargetInput.value.trim() || targetInput.value.trim() || "255.255.255.255";
    payload.port = Number(portInput.value || 47808);
    payload.timeout = Number(timeoutInput.value || 3);
    payload.source_port = Number(sourcePortInput.value || 0);
    payload.subnet_scan = Boolean(options.subnetScan);
    payload.scan_cidr = selectedScanCidr();
    payload.scan_cidrs = selectedScanCidrs();
    payload.routed_routers = routedRoutersInput.value.trim();
    payload.routed_networks = routedNetworksInput.value.trim();
    payload.routed_auto = true;
    payload.routed_macs = routedMacsInput.value.trim() || "0-127";
  }

  return payload;
}

async function scan(options = {}) {
  if (activeScanController) {
    return;
  }
  const subnetScan = Boolean((options.subnetScan ?? shouldAutoSubnetScan()) && activeMode() === "ip");
  if (subnetScan) {
    syncTargetFromSubnet();
  }
  const requestPayload = scanPayload({ subnetScan });
  const currentInventoryScope = scanInventoryScope(requestPayload);
  activeScanController = new AbortController();
  activeScanGeneration += 1;
  activeScanJobId = null;
  activeScanStopRequested = false;
  activeScanStopPosted = false;
  renderGatewayCards([], {
    emptyMessage: "Scanning for BACnet devices...",
  });
  deviceActivityView.reset();
  deviceActivityView.setRunning(true);
  scanButton.disabled = true;
  quickScanButton.disabled = true;
  stopScanButton.disabled = false;
  stopScanButton.classList.remove("hidden");
  const startedAt = performance.now();
  setStatus(subnetScan ? "Scanning subnet..." : "Scanning...", "busy");
  lastScanStatus.textContent = "Scanning";
  lastScanStatus.className = "pill warn";
  scanPercent.textContent = "—";
  scanProgressBar.style.width = "100%";
  scanProgressBar.classList.add("indeterminate");
  if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
  updateSummary();
  if (hasRoutedScan()) {
    const routedLabel = isAutoRemoteNetworkMode() ? "smart routed MS/TP sweep" : "routed MS/TP sweep";
    summaryRequest.textContent = subnetScan ? `Who-Is subnet + ${routedLabel}` : `Who-Is ${routedLabel}`;
  } else if (subnetScan) {
    summaryRequest.textContent = "Who-Is unicast subnet sweep";
  }

  try {
    const response = await fetch("/api/scan/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Alto-Request": "json" },
      body: JSON.stringify(requestPayload),
      signal: activeScanController.signal,
    });
    const created = await response.json();
    if (!response.ok) {
      throw new Error(created.error || "Scan failed");
    }
    activeScanJobId = created.job_id;
    if (activeScanStopRequested) await stopActiveScan();
    const result = await pollDeviceScanJob(created.job_id, activeScanController.signal);

    const elapsedSeconds = ((performance.now() - startedAt) / 1000).toFixed(2);
    const cancelled = result.status === "cancelled" || result.phase === "cancelled";
    scanPercent.textContent = cancelled
      ? "Stopped"
      : result.status === "done"
      ? "Done"
      : result.status === "partial" ? "Partial" : "Stopped";
    scanProgressBar.style.width = !cancelled && result.status === "done" ? "100%" : "0%";
    scanProgressBar.classList.remove("indeterminate");
    if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
    if (cancelled) {
      deviceActivityView.setTerminal("cancelled", "cancelled");
      renderGatewayCards([], {
        emptyMessage: "Scan stopped. No current results.",
      });
      setStatus("Scan stopped - current results discarded", "warn");
      summaryResponses.textContent = discoveredDevices.length
        ? `${discoveredDevices.length} retained`
        : "0 device(s)";
      summaryDuration.textContent = `${elapsedSeconds} sec`;
      lastScanStatus.textContent = "Stopped";
      lastScanStatus.title = "Scan stopped by user; current results were discarded";
      lastScanStatus.className = "pill warn";
      return;
    }
    updateRoutedAutoHint(result);
    renderRoutedNetworkFilter(result);
    const latestDevices = result.devices || [];
    const mergedDevices = mergeScanInventory(
      lastDeviceInventoryScope,
      currentInventoryScope,
      discoveredDevices,
      latestDevices,
    );
    lastDeviceInventoryScope = currentInventoryScope;
    renderDevices(mergedDevices);
    renderGatewayCards(latestDevices, {
      emptyMessage: "No BACnet devices answered in this scan.",
      inventoryCount: mergedDevices.length,
    });
    const selectableDevices = pointScanDevices(
      mergedDevices,
      enabledRoutedNetworks,
      advertisedRoutedNetworks,
    );
    selectedDevice = selectableDevices[0] || null;
    renderDeviceCards(selectableDevices);
    updateSelectedDevice();
    if (mergedDevices.length) {
      navigateToView("devicesPanel");
    }
    const retainedCount = mergedDevices.length - latestDevices.length;
    const terminalLabel = result.status === "cancelled"
      ? "Scan cancelled"
      : result.status === "partial"
        ? "Partial scan"
        : "";
    const inventoryLabel = retainedCount > 0
      ? `${latestDevices.length} seen / ${mergedDevices.length} known (${retainedCount} retained)`
      : `${latestDevices.length} device${latestDevices.length === 1 ? "" : "s"} found`;
    setStatus([terminalLabel, inventoryLabel].filter(Boolean).join(" - "), result.status === "done" ? "ok" : "warn");
    summaryResponses.textContent = retainedCount > 0
      ? `${latestDevices.length} seen / ${mergedDevices.length} known`
      : `${latestDevices.length} device(s)`;
    summaryDuration.textContent = `${elapsedSeconds} sec`;
    lastScanStatus.textContent = terminalLabel || `${elapsedSeconds} sec`;
    lastScanStatus.className = result.status === "done" ? "pill ok" : "pill warn";
  } catch (error) {
    const stopped = error.name === "AbortError";
    renderGatewayCards([], {
      emptyMessage: stopped
        ? "Scan stopped. No current results."
        : "Scan failed. No current results.",
    });
    deviceActivityView.setTerminal(stopped ? "cancelled" : "error", stopped ? "cancelled" : "error");
    scanPercent.textContent = stopped ? "Stopped" : "Failed";
    scanProgressBar.style.width = "0%";
    scanProgressBar.classList.remove("indeterminate");
    if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
    if (!discoveredDevices.length) {
      devicesBody.replaceChildren();
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 9;
      cell.className = stopped ? "empty" : "empty error";
      cell.textContent = stopped ? "Scan stopped." : error.message;
      row.append(cell);
      devicesBody.append(row);
    }
    setStatus(stopped ? "Scan stopped" : `Scan failed: ${error.message}`, stopped ? "warn" : "error");
    summaryResponses.textContent = discoveredDevices.length
      ? `${discoveredDevices.length} retained`
      : "0 device(s)";
    summaryDuration.textContent = "-";
    lastScanStatus.textContent = stopped ? "Stopped" : "Failed";
    lastScanStatus.title = stopped ? "Scan stopped by user" : error.message;
    lastScanStatus.className = stopped ? "pill warn" : "pill error";
  } finally {
    deviceActivityView.setRunning(false);
    activeScanController = null;
    activeScanJobId = null;
    activeScanStopRequested = false;
    activeScanStopPosted = false;
    scanButton.disabled = false;
    quickScanButton.disabled = false;
    stopScanButton.disabled = true;
    stopScanButton.classList.add("hidden");
    updateSummary();
    if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
  }
}

async function pollDeviceScanJob(jobId, signal) {
  let cursor = 0;
  let failures = 0;
  while (true) {
    if (signal?.aborted) {
      const error = new Error("Scan polling cancelled");
      error.name = "AbortError";
      throw error;
    }
    let response;
    let job;
    try {
      response = await fetch(`/api/scan/jobs/${jobId}?after=${cursor}`, {signal});
      job = await response.json();
    } catch (error) {
      if (error?.name === "AbortError") throw error;
      failures += 1;
      if (failures >= 5) throw new Error(`Device scan polling failed after 5 attempts: ${error.message}`);
      await delay(Math.min(3200, 400 * (2 ** (failures - 1))));
      continue;
    }
    if (!response.ok) throw new Error(job.error || "Device scan status failed");
    failures = 0;
    deviceActivityView.append(job);
    updateDeviceJobProgress(job);
    const nextCursor = Number(job.next_sequence);
    if (Number.isFinite(nextCursor) && nextCursor >= cursor) cursor = nextCursor;
    if (["done", "partial", "cancelled"].includes(job.status)) return job;
    if (job.status === "error") throw new Error(job.error || "Device scan failed");
    await delay(400);
  }
}

function updateDeviceJobProgress(job) {
  const total = Number(job.total);
  const completed = Number(job.completed);
  const hasNumericProgress = Number.isFinite(total) && total > 0 && Number.isFinite(completed);
  if (job.status === "partial" && hasNumericProgress && completed >= total) {
    scanPercent.textContent = "Partial";
    scanProgressBar.style.width = "0%";
    scanProgressBar.classList.remove("indeterminate");
  } else if (hasNumericProgress) {
    const roundedPercent = Math.max(0, Math.min(100, Math.round((completed / total) * 100)));
    const percent = completed < total ? Math.min(99, roundedPercent) : roundedPercent;
    scanPercent.textContent = `${percent}%`;
    scanProgressBar.style.width = `${percent}%`;
    scanProgressBar.classList.remove("indeterminate");
  } else if (["done", "partial", "cancelled"].includes(job.status)) {
    scanPercent.textContent = job.status === "done" ? "Done" : job.status === "partial" ? "Partial" : "Stopped";
    scanProgressBar.style.width = job.status === "done" ? "100%" : "0%";
    scanProgressBar.classList.remove("indeterminate");
  } else {
    scanPercent.textContent = "—";
    scanProgressBar.style.width = "100%";
    scanProgressBar.classList.add("indeterminate");
  }
  gatewayScanStatus.textContent = job.message || job.phase || "Scanning";
  if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
}

async function stopActiveScan() {
  if (!activeScanController) return;
  if (!activeScanStopRequested) {
    activeScanStopRequested = true;
    setStatus("Stopping scan...", "warn");
    lastScanStatus.textContent = "Stopping";
    lastScanStatus.className = "pill warn";
  }
  if (!activeScanJobId || activeScanStopPosted) return;
  activeScanStopPosted = true;
  const stopController = activeScanController;
  const stopJobId = activeScanJobId;
  const stopGeneration = activeScanGeneration;
  const isCurrentStop = () => activeScanController === stopController
    && activeScanJobId === stopJobId
    && activeScanGeneration === stopGeneration;
  try {
    const response = await fetch(`/api/scan/jobs/${stopJobId}/stop`, {
      method: "POST",
      headers: { "X-Alto-Request": "json" },
    });
    const result = await response.json();
    if (!isCurrentStop()) return;
    if (!response.ok) throw new Error(result.error || "Unable to stop scan");
    deviceActivityView.append(result);
  } catch (error) {
    if (!isCurrentStop()) return;
    setStatus(`Stop request failed: ${error.message}; scan status is still being checked`, "warn");
  }
}

function updateRoutedAutoHint(result) {
  if (!result?.routed_auto || !Array.isArray(result.routed_networks)) {
    return;
  }
  const networks = result.routed_networks.filter((value) => value !== null && value !== undefined);
  if (networks.length) {
    routedNetworksInput.placeholder = `Auto found: ${networks.join(",")}`;
    return;
  }
  routedNetworksInput.placeholder = "Auto could not detect network; try 1,2,3";
}

function renderRoutedNetworkFilter(result) {
  const networks = [...new Set((result?.routed_networks || []).map(Number))]
    .filter((network) => Number.isInteger(network) && network >= 1 && network <= 65535)
    .sort((left, right) => left - right);
  const routers = [...new Set((result?.routed_routers || []).map(String).filter(Boolean))];
  advertisedRoutedNetworks = new Set(networks);
  enabledRoutedNetworks = new Set(networks);
  routedRouterCount.textContent = String(routers.length);
  routedNetworkCount.textContent = String(networks.length);
  routedNetworkFilter.replaceChildren();

  for (const network of networks) {
    const label = document.createElement("label");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.value = String(network);
    checkbox.checked = true;
    checkbox.addEventListener("change", () => {
      if (checkbox.checked) {
        enabledRoutedNetworks.add(network);
      } else {
        enabledRoutedNetworks.delete(network);
      }
      if (
        selectedDevice
        && !pointScanDevices(
          [selectedDevice],
          enabledRoutedNetworks,
          advertisedRoutedNetworks,
        ).length
      ) {
        selectedDevice = null;
      }
      renderDevices(discoveredDevices);
      updateSelectedDevice();
    });
    label.append(checkbox, document.createTextNode(`Network ${network}`));
    routedNetworkFilter.append(label);
  }
}

function renderPoints(points) {
  pointRows = sortPoints(points);
  updatePointReadSummary(pointRows);
  refreshPointFilterOptions();
  renderFilteredPoints();
  updateCovButton();
}

function renderFilteredPoints() {
  const points = filteredPointRows();
  pointsBody.replaceChildren();
  const readable = countReadablePoints(pointRows);
  const hasFilter = pointFilterActive();
  pointCountPill.textContent = hasFilter
    ? `${points.length}/${pointRows.length} shown - ${readable} read`
    : `${readable}/${pointRows.length} read`;
  if (exportPointsButton) {
    exportPointsButton.disabled = !points.length;
  }
  updateCovButton();
  if (!pointRows.length) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 10;
    cell.className = "empty";
    cell.textContent = "No BACnet objects returned from this device.";
    row.append(cell);
    pointsBody.append(row);
    return;
  }
  if (!points.length) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 10;
    cell.className = "empty";
    cell.textContent = "No points match this filter.";
    row.append(cell);
    pointsBody.append(row);
    return;
  }

  for (const point of points) {
    const row = document.createElement("tr");
    const sourceCell = document.createElement("td");
    sourceCell.append(pointSourceBadge(point));
    row.append(sourceCell);

    const nameCell = document.createElement("td");
    nameCell.textContent = propertyOutcomeLabel(point, "name") || point.name || "-";
    row.append(nameCell);

    const idCell = document.createElement("td");
    idCell.textContent = objectInstanceLabel(point);
    row.append(idCell);

    const typeCell = document.createElement("td");
    typeCell.append(pointTypeBadge(point));
    row.append(typeCell);

    const values = [
      displayPresentValue(point),
      formatOutValue(point),
      propertyOutcomeLabel(point, "units") || point.units || "",
      propertyOutcomeLabel(point, "description") || point.description || "",
      point.status,
    ];
    for (const value of values) {
      const cell = document.createElement("td");
      cell.textContent = value;
      row.append(cell);
    }
    row.append(controlCell(point));
    pointsBody.append(row);
  }
}

function isControllablePoint(point) {
  return [1, 2, 4, 5, 14, 19].includes(Number(point.object_type));
}

function formatOutValue(point) {
  const value = point.out_value ?? point.present_value;
  const status = point.out_status || point.status || "ok";
  const source = point.out_source ? ` @ ${point.out_source}` : "";
  if (value === null || value === undefined || value === "") {
    if (source) {
      return `- {${status}}${source}`;
    }
    return "-";
  }
  return `${formatOutDisplayValue(point, value)} {${status}}${source}`;
}

function formatOutDisplayValue(point, value) {
  const objectType = Number(point.object_type);
  if ([3, 4, 5].includes(objectType)) {
    const binaryValue = binaryState(value);
    if (binaryValue === null) {
      return formatPointValue(value);
    }
    if (objectType === 3 && isNormalAlarmPoint(point)) {
      return binaryValue ? "Alarm" : "Normal";
    }
    return binaryValue ? "ON" : "OFF";
  }
  return formatPointValue(value);
}

function binaryState(value) {
  if (typeof value === "boolean") {
    return value;
  }
  if (typeof value === "number") {
    return value !== 0;
  }
  const text = String(value || "").trim().toLowerCase();
  if (["1", "true", "active", "on", "alarm"].includes(text)) {
    return true;
  }
  if (["0", "false", "inactive", "off", "normal"].includes(text)) {
    return false;
  }
  return null;
}

function isNormalAlarmPoint(point) {
  const text = `${point.name || ""} ${point.description || ""}`.toLowerCase();
  return /alarm|fault|fail|filter|dirty|trip|safety|leak|smoke/.test(text);
}

function controlCell(point) {
  const cell = document.createElement("td");
  if (!isControllablePoint(point)) {
    cell.textContent = "-";
    return cell;
  }
  const wrap = document.createElement("div");
  wrap.className = "control-cell";
  const input = document.createElement("input");
  input.type = "text";
  input.value = point.present_value ?? "";
  input.placeholder = controlPlaceholder(point);
  const button = document.createElement("button");
  button.type = "button";
  button.className = "secondary control-write";
  button.textContent = "Write";
  button.addEventListener("click", () => controlPoint(point, input, button));
  wrap.append(input, button);
  cell.append(wrap);
  return cell;
}

function controlPlaceholder(point) {
  const type = Number(point.object_type);
  if ([4, 5].includes(type)) {
    return "0/1";
  }
  if ([14, 19].includes(type)) {
    return "state #";
  }
  return "value";
}

function objectInstanceLabel(point) {
  const instance = point.instance ?? instanceFromObjectId(point.object_id);
  return Number.isFinite(Number(instance)) ? String(instance) : "-";
}

function objectIdLabel(point) {
  const type = displayObjectTypeName(point) || objectTypeShortCode(point) || "object";
  return `${type}:${objectInstanceLabel(point)}`;
}

function objectTypeShortCode(point) {
  const type = Number(point.object_type);
  const codes = {
    0: "AI",
    1: "AO",
    2: "AV",
    3: "BI",
    4: "BO",
    5: "BV",
    8: "D",
    13: "MI",
    14: "MO",
    15: "NC",
    19: "MV",
  };
  return codes[type] || "";
}

function displayObjectTypeName(point) {
  const raw = String(point.object_type_name || "").trim();
  if (raw === "object-15") {
    return "notification-class";
  }
  if (!raw && Number(point.object_type) === 15) {
    return "notification-class";
  }
  return raw;
}

function pointFamily(point) {
  const type = Number(point.object_type);
  if ([0, 1, 2].includes(type)) return "analog";
  if ([3, 4, 5].includes(type)) return "binary";
  if ([13, 14, 19].includes(type)) return "multistate";
  if (type === 8) return "device";
  if (type === 15) return "notification";
  return "other";
}

function pointRole(point) {
  const type = Number(point.object_type);
  if (type === 8) return "device";
  if (type === 15) return "notification";
  if ([0, 3, 13].includes(type)) return "input";
  if ([1, 4, 14].includes(type)) return "output";
  if ([2, 5, 19].includes(type)) return "value";
  return "other";
}

function pointSource(point) {
  if (point.source) {
    return String(point.source);
  }
  const name = String(point.name || "").trim();
  if (!name) {
    return "Unknown";
  }
  const slash = name.split(/[/.]/).filter(Boolean);
  if (slash.length > 1) {
    return normalizePointSource(slash[0]);
  }
  const match = name.match(/^(.+?)(?:[_\s-])(?:AI|AO|AV|BI|BO|BV|MI|MO|MV)(?:[_\s-]|\d|$)/i);
  if (match?.[1]) {
    return normalizePointSource(match[1]);
  }
  const prefix = name.split(/[_\s-]/).filter(Boolean)[0];
  return normalizePointSource(prefix || "General");
}

function normalizePointSource(value) {
  return String(value || "Unknown").replace(/[_-]+/g, " ").trim() || "Unknown";
}

function pointSourceBadge(point) {
  const badge = document.createElement("span");
  badge.className = `source-badge ${pointFamily(point)}`;
  const icon = document.createElement("span");
  icon.className = `point-dot ${pointFamily(point)}`;
  icon.textContent = objectTypeShortCode(point).slice(0, 1) || "P";
  badge.append(icon, document.createTextNode(pointSource(point)));
  return badge;
}

function pointTypeBadge(point) {
  const badge = document.createElement("span");
  badge.className = `type-badge ${pointFamily(point)} ${pointRole(point)}`;
  const code = objectTypeShortCode(point);
  const label = displayObjectTypeName(point) || "object";
  badge.textContent = code ? `${code} - ${label}` : label;
  return badge;
}

function pointHasReadableValue(point) {
  return point.present_value !== null && point.present_value !== undefined && point.present_value !== "";
}

function countReadablePoints(points) {
  return points.filter(pointHasReadableValue).length;
}

function updatePointReadSummary(points) {
  const total = points.length;
  const readable = countReadablePoints(points);
  const empty = Math.max(0, total - readable);
  if (pointReadableCount) pointReadableCount.textContent = String(readable);
  if (pointTotalCount) pointTotalCount.textContent = String(total);
  if (pointEmptyCount) pointEmptyCount.textContent = String(empty);
}

function updateCovButton() {
  if (!covToggleButton) {
    return;
  }
  const canRun = Boolean(selectedDevice && selectedDevice.ip && pointRows.length);
  covToggleButton.disabled = !canRun;
  covToggleButton.textContent = covRunning ? "Stop COV" : "Subscribe COV";
  covToggleButton.classList.toggle("active", covRunning);
}

function sortPoints(points) {
  return [...points].sort((left, right) => {
    const leftType = Number(left.object_type ?? 9999);
    const rightType = Number(right.object_type ?? 9999);
    if (leftType !== rightType) {
      return leftType - rightType;
    }
    const leftInstance = Number(left.instance ?? instanceFromObjectId(left.object_id));
    const rightInstance = Number(right.instance ?? instanceFromObjectId(right.object_id));
    if (leftInstance !== rightInstance) {
      return leftInstance - rightInstance;
    }
    return String(left.name || left.object_id || "").localeCompare(String(right.name || right.object_id || ""));
  });
}

function instanceFromObjectId(objectId) {
  const match = String(objectId || "").match(/:(\d+)$/);
  return match ? Number(match[1]) : 999999999;
}

function pointMatchesFilter(point, query) {
  return [
    pointSource(point),
    point.name,
    objectIdLabel(point),
    objectInstanceLabel(point),
    objectTypeShortCode(point),
    displayObjectTypeName(point),
    displayPresentValue(point),
    formatOutValue(point),
    point.units,
    point.description,
    point.status,
  ]
    .filter((value) => value !== null && value !== undefined)
    .some((value) => String(value).toLowerCase().includes(query));
}

function pointMatchesGroup(point, group) {
  if (!group || group === "all") return true;
  if (group === "readonly") return !isControllablePoint(point);
  return pointFamily(point) === group || pointRole(point) === group;
}

function pointFilterActive() {
  return Boolean(
    activePointGroup !== "all" ||
      (pointFilterInput?.value || "").trim() ||
      (pointSourceFilter?.value || "").trim() ||
      (pointTypeFilter?.value || "").trim() ||
      (pointIdFilter?.value || "").trim(),
  );
}

function filteredPointRows() {
  const query = (pointFilterInput?.value || "").trim().toLowerCase();
  const source = (pointSourceFilter?.value || "").trim();
  const type = (pointTypeFilter?.value || "").trim();
  const idQuery = (pointIdFilter?.value || "").trim().toLowerCase();
  return pointRows.filter((point) => {
    if (!pointMatchesGroup(point, activePointGroup)) return false;
    if (source && pointSource(point) !== source) return false;
    if (type && displayObjectTypeName(point) !== type && String(point.object_type ?? "") !== type) return false;
    if (idQuery) {
      const labels = [objectInstanceLabel(point), objectIdLabel(point), String(point.object_id || "")].join(" ").toLowerCase();
      if (!labels.includes(idQuery)) return false;
    }
    return !query || pointMatchesFilter(point, query);
  });
}

function refreshPointFilterOptions() {
  replaceSelectOptions(pointSourceFilter, "All sources", uniqueSorted(pointRows.map(pointSource)));
  replaceSelectOptions(pointTypeFilter, "All types", uniqueSorted(pointRows.map(displayObjectTypeName)));
}

function uniqueSorted(values) {
  return [...new Set(values.map((value) => String(value || "").trim()).filter(Boolean))].sort((left, right) =>
    left.localeCompare(right, undefined, { numeric: true, sensitivity: "base" }),
  );
}

function replaceSelectOptions(select, emptyLabel, values) {
  if (!select) return;
  const current = select.value;
  select.replaceChildren(new Option(emptyLabel, ""));
  for (const value of values) {
    select.append(new Option(value, value));
  }
  if (values.includes(current)) {
    select.value = current;
  }
}

function resetPointFilters() {
  if (pointFilterInput) pointFilterInput.value = "";
  if (pointSourceFilter) pointSourceFilter.value = "";
  if (pointTypeFilter) pointTypeFilter.value = "";
  if (pointIdFilter) pointIdFilter.value = "";
  activePointGroup = "all";
  updatePointGroupButtons();
}

function updatePointGroupButtons() {
  for (const button of pointGroupButtons) {
    button.classList.toggle("active", button.dataset.pointGroup === activePointGroup);
  }
}

function exportFilteredPointsCsv() {
  const points = filteredPointRows();
  if (!points.length) {
    return;
  }
  const headers = [
    "Source",
    "Object Name",
    "Object ID",
    "ID",
    "Type",
    "Present Value",
    "Out",
    "Units",
    "Description",
    "Status",
    "Device",
    "Device ID",
    "Network",
    "MAC Addr",
    "Address",
  ];
  const rows = points.map((point) => [
    pointSource(point),
    point.name || "",
    objectIdLabel(point),
    objectInstanceLabel(point),
    displayObjectTypeName(point) || "",
    displayPresentValue(point),
    formatOutValue(point),
    point.units ?? "",
    point.description ?? "",
    point.status || "",
    selectedDevice ? deviceName(selectedDevice) : "",
    selectedDevice?.device_id ?? "",
    selectedDevice ? networkLabel(selectedDevice) : "",
    selectedDevice ? macLabel(selectedDevice) : "",
    selectedDevice ? `${selectedDevice.ip || ""}:${selectedDevice.port || 47808}` : "",
  ]);
  const csv = [headers, ...rows].map((row) => row.map(csvCell).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  const device = selectedDevice ? deviceName(selectedDevice) : "bacnet-device";
  const timestamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  link.href = URL.createObjectURL(blob);
  link.download = `${safeFilename(device)}-points-${timestamp}.csv`;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(link.href);
}

function csvCell(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function safeFilename(value) {
  return String(value || "bacnet-device")
    .replace(/[^\w.-]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 80) || "bacnet-device";
}

function formatPointValue(value) {
  if (value === null || value === undefined) {
    return "";
  }
  if (typeof value === "number") {
    return Number.isInteger(value) ? String(value) : value.toFixed(3);
  }
  if (typeof value === "object") {
    return JSON.stringify(value);
  }
  return String(value);
}

function displayPresentValue(point) {
  const outcome = point.property_status?.present_value;
  if (outcome === "timeout") return "Timed out";
  if (outcome === "unsupported" || outcome === "missing") return "Unavailable";
  const objectType = Number(point.object_type);
  if ([3, 4, 5].includes(objectType) && point.present_value === 0) {
    return "inactive";
  }
  if ([3, 4, 5].includes(objectType) && point.present_value === 1) {
    return "active";
  }
  return formatPointValue(point.present_value);
}

function propertyOutcomeLabel(point, propertyName) {
  const outcome = point.property_status?.[propertyName];
  if (outcome === "timeout") return "Timed out";
  if (outcome === "unsupported" || outcome === "missing") return "Unavailable";
  return "";
}

async function controlPoint(point, input, button) {
  if (!selectedDevice || !selectedDevice.ip) {
    return;
  }
  const value = input.value.trim();
  if (!value) {
    pointStatus.textContent = "Enter a control value first";
    pointStatus.className = "pill warn";
    return;
  }
  button.disabled = true;
  pointStatus.textContent = `Writing ${point.name || point.object_id}...`;
  pointStatus.className = "pill warn";
  try {
    if (!covRunning && pointRows.length) {
      await startCovLive({ auto: true });
    }
    const response = await fetch("/api/control", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Alto-Request": "json" },
      body: JSON.stringify({
        ip: selectedDevice.ip,
        port: selectedDevice.port || 47808,
        device_id: selectedDevice.device_id,
        network_number: selectedDevice.network_number ?? null,
        mac_address: selectedDevice.mac_address ?? null,
        object_type: point.object_type,
        instance: point.instance ?? instanceFromObjectId(point.object_id),
        value,
        priority: 8,
        timeout: Math.max(5, Number(pointTimeoutInput.value || 3)),
      }),
    });
    const result = await response.json();
    if (!response.ok || !result.ok) {
      throw new Error(result.error || "Control failed");
    }
    if (result.present_value !== null && result.present_value !== undefined) {
      point.present_value = result.present_value;
      point.out_value = result.present_value;
      point.out_status = "ok";
      point.out_source = "p8";
    }
    point.status = result.readback_error ? "write ok / readback failed" : "ok";
    updatePointReadSummary(pointRows);
    renderFilteredPoints();
    schedulePostControlRefresh(point);
    if (result.readback_error) {
      pointStatus.textContent = `Write sent, readback failed: ${result.readback_error}`;
      pointStatus.className = "pill warn";
    } else if (result.warning) {
      pointStatus.textContent = `Control OK, value now ${formatPointValue(result.present_value)} (${result.warning})`;
      pointStatus.className = "pill warn";
    } else {
      pointStatus.textContent = `Control OK, value now ${formatPointValue(result.present_value)}`;
      pointStatus.className = "pill ok";
    }
  } catch (error) {
    pointStatus.textContent = `Control failed: ${error.message}`;
    pointStatus.className = "pill error";
  } finally {
    button.disabled = false;
  }
}

function pointScanPayload() {
  return {
    ip: selectedDevice.ip,
    port: selectedDevice.port || 47808,
    device_id: selectedDevice.device_id,
    network_number: selectedDevice.network_number ?? null,
    mac_address: selectedDevice.mac_address ?? null,
    max_apdu: selectedDevice.max_apdu ?? null,
    segmentation: selectedDevice.segmentation ?? null,
    timeout: Number(pointTimeoutInput.value || 3),
    concurrency: 16,
    read_strategy: pointReadStrategy?.value || "auto",
  };
}

let activePointJobId = null;

async function stopActivePointScan() {
  const jobId = activePointJobId;
  if (!jobId) return;
  stopPointsButton.disabled = true;
  try {
    const response = await fetch(`/api/points/jobs/${jobId}/stop`, {
      method: "POST",
      headers: { "X-Alto-Request": "json" },
    });
    if (!response.ok) {
      const result = await response.json().catch(() => ({}));
      throw new Error(result.error || "Unable to stop point scan");
    }
  } catch (error) {
    pointActivityView.setTerminal("error", `Stop failed: ${error.message}`);
  }
}

async function scanPoints() {
  if (!selectedDevice || !selectedDevice.ip) {
    return;
  }

  stopCovLive();
  pointActivityView.reset();
  pointActivityView.setRunning(true);
  scanPointsButton.disabled = true;
  stopPointsButton.disabled = false;
  stopPointsButton.classList.remove("hidden");
  pointStatus.textContent = "Scanning points...";
  pointStatus.className = "pill warn";
  setPointProgress(null, "Starting point scan");
  pointDiagnostics.textContent = "";
  resetPointFilters();
  renderPoints([]);

  try {
    const response = await fetch("/api/points/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Alto-Request": "json" },
      body: JSON.stringify(pointScanPayload()),
    });
    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || "Point scan failed");
    }
    activePointJobId = result.job_id;
    const job = await pollPointJob(result.job_id);
    if (job.status === "stopped") {
      pointStatus.textContent = `${countReadablePoints(pointRows)} point(s) read - stopped`;
      pointStatus.className = "pill warn";
    } else {
      pointStatus.textContent = job.status === "partial"
        ? `${countReadablePoints(pointRows)} point(s) read - partial result`
        : `${countReadablePoints(pointRows)} point(s) read`;
      pointStatus.className = job.status === "partial" ? "pill warn" : "pill ok";
    }
  } catch (error) {
    pointActivityView.setTerminal("error", "error");
    pointsBody.replaceChildren();
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 10;
    cell.className = "empty error";
    cell.textContent = error.message;
    row.append(cell);
    pointsBody.append(row);
    pointStatus.textContent = "Point scan failed";
    pointStatus.className = "pill error";
    updatePointReadSummary([]);
    pointDiagnostics.textContent = "";
    setPointProgress(null, "Point scan failed");
  } finally {
    activePointJobId = null;
    stopPointsButton.disabled = true;
    stopPointsButton.classList.add("hidden");
    pointActivityView.setRunning(false);
    updateSelectedDevice();
  }
}

function pointValuePayload(point) {
  if (!point || point.object_type === null || point.object_type === undefined) {
    return null;
  }
  const objectType = Number(point.object_type);
  const instance = Number(point.instance ?? instanceFromObjectId(point.object_id));
  if (!Number.isFinite(objectType) || !Number.isFinite(instance)) {
    return null;
  }
  return { object_type: objectType, instance };
}

function visiblePointsPayload(limit = 100) {
  return filteredPointRows()
    .slice(0, limit)
    .map(pointValuePayload)
    .filter(Boolean);
}

function covPointsPayload() {
  return visiblePointsPayload(100);
}

async function readPointValues(points, options = {}) {
  if (!selectedDevice || !selectedDevice.ip || !points.length) {
    return [];
  }
  const response = await fetch("/api/point-values", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Alto-Request": "json" },
    signal: options.signal,
    body: JSON.stringify({
      ip: selectedDevice.ip,
      port: selectedDevice.port || 47808,
      network_number: selectedDevice.network_number ?? null,
      mac_address: selectedDevice.mac_address ?? null,
      timeout: Math.max(3, Number(pointTimeoutInput.value || 3)),
      points,
    }),
  });
  const result = await response.json();
  if (!response.ok) {
    throw new Error(result.error || "Read value failed");
  }
  return result.values || [];
}

function applyPointValues(values) {
  const readableValues = values.filter((item) => item.ok);
  const valueMap = new Map(
    readableValues.map((item) => [`${Number(item.object_type)}:${Number(item.instance)}`, item.value]),
  );
  let changed = false;
  for (const point of pointRows) {
    const key = `${Number(point.object_type)}:${Number(point.instance ?? instanceFromObjectId(point.object_id))}`;
    if (valueMap.has(key)) {
      const value = valueMap.get(key);
      changed = changed
        || !Object.is(point.present_value, value)
        || !Object.is(point.out_value, value)
        || point.out_status !== "ok"
        || point.status !== "ok";
      point.present_value = value;
      point.out_value = value;
      point.out_status = "ok";
      point.status = "ok";
    }
  }
  updatePointReadSummary(pointRows);
  if (changed) renderFilteredPoints();
  return readableValues.length;
}

function cancelPostControlRefresh() {
  postControlGeneration += 1;
  if (postControlTimer !== null) {
    window.clearTimeout(postControlTimer);
    postControlTimer = null;
  }
  if (postControlController !== null) {
    postControlController.abort();
    postControlController = null;
  }
  postControlAttempt = 0;
  lastControlledPoint = null;
}

async function runPostControlRefresh(generation, point) {
  if (generation !== postControlGeneration) {
    return;
  }
  const controller = new AbortController();
  postControlController = controller;
  let updated = 0;
  try {
    const values = await readPointValues([point], { signal: controller.signal });
    if (generation !== postControlGeneration) {
      return;
    }
    updated = applyPointValues(values);
  } catch (error) {
    if (error?.name === "AbortError" || generation !== postControlGeneration) {
      return;
    }
  } finally {
    if (postControlController === controller) {
      postControlController = null;
    }
  }
  if (updated) {
    pointStatus.textContent = "Control feedback refreshed";
    pointStatus.className = "pill ok";
    return;
  }
  postControlAttempt += 1;
  if (postControlAttempt >= POST_CONTROL_DELAYS.length) {
    return;
  }
  postControlTimer = window.setTimeout(() => {
    postControlTimer = null;
    return runPostControlRefresh(generation, point);
  }, POST_CONTROL_DELAYS[postControlAttempt]);
}

function schedulePostControlRefresh(point = lastControlledPoint) {
  const payload = pointValuePayload(point);
  if (!payload) {
    return;
  }
  cancelPostControlRefresh();
  lastControlledPoint = point;
  const generation = postControlGeneration;
  postControlTimer = window.setTimeout(() => {
    postControlTimer = null;
    return runPostControlRefresh(generation, payload);
  }, POST_CONTROL_DELAYS[0]);
}

async function refreshVisiblePointValues() {
  if (!selectedDevice || !selectedDevice.ip) {
    return;
  }
  const points = visiblePointsPayload(100);
  if (!points.length) {
    return;
  }
  try {
    const values = await readPointValues(points);
    const updated = applyPointValues(values);
    if (updated) {
      pointStatus.textContent = `Feedback refreshed ${updated}/${points.length}`;
      pointStatus.className = "pill ok";
    }
  } catch {
    // Keep the original control result visible if a follow-up feedback read misses.
  }
}

async function pollCovJob() {
  if (!covRunning || !selectedDevice || deviceRuntimeKey(selectedDevice) !== covDeviceKey) {
    stopCovLive();
    return;
  }
  if (!covJobId) {
    return;
  }
  try {
    const response = await fetch(`/api/cov/jobs/${covJobId}`);
    const job = await response.json();
    if (!response.ok) {
      throw new Error(job.error || "COV status failed");
    }
    if (Array.isArray(job.values) && job.values.length) {
      applyPointValues(job.values);
    }
    const failed = Array.isArray(job.failed) ? job.failed.length : 0;
    const notifications = Number(job.notifications || 0);
    const subscribed = Number(job.subscribed || 0);
    const firstError = failed ? ` - ${job.failed[0]?.error || "subscribe failed"}` : "";
    pointStatus.textContent = `COV active: ${subscribed} subscribed, ${notifications} notification(s), ${failed} failed${firstError}`;
    pointStatus.className = failed ? "pill warn" : "pill ok";
    pointStatus.title = firstError ? job.failed[0]?.error || "" : "";
    if (subscribed === 0 && covRequestedCount > 0 && failed >= covRequestedCount) {
      stopCovLocal();
      pointStatus.textContent = `COV subscribe failed for all ${failed} point(s); using feedback refresh`;
      pointStatus.className = "pill warn";
      schedulePostControlRefresh(lastControlledPoint);
      return;
    }
    if (["done", "stopped", "error"].includes(job.status)) {
      stopCovLocal();
      pointStatus.textContent = job.error || job.message || "COV stopped";
      pointStatus.className = job.status === "error" ? "pill error" : "pill muted";
    }
  } catch (error) {
    pointStatus.textContent = `COV live failed: ${error.message}`;
    pointStatus.className = "pill error";
  }
}

function scheduleCovPoll(delayMs = 1000) {
  if (!covRunning || covTimer !== null || document.visibilityState !== "visible") return;
  covTimer = window.setTimeout(() => {
    covTimer = null;
    void runCovPoll();
  }, delayMs);
}

async function runCovPoll() {
  if (!covRunning || covPollRunning || document.visibilityState !== "visible") return;
  covPollRunning = true;
  try {
    await pollCovJob();
  } finally {
    covPollRunning = false;
    scheduleCovPoll();
  }
}

function syncCovPollVisibility() {
  if (document.visibilityState === "visible") {
    scheduleCovPoll(0);
    return;
  }
  if (covTimer !== null) {
    window.clearTimeout(covTimer);
    covTimer = null;
  }
}

async function startCovLive(options = {}) {
  if (!selectedDevice || !selectedDevice.ip || !pointRows.length) {
    return false;
  }
  const points = covPointsPayload();
  if (!points.length) {
    if (!options.auto) {
      pointStatus.textContent = "No visible points to subscribe COV";
      pointStatus.className = "pill warn";
    }
    return false;
  }
  covRunning = true;
  covRequestedCount = points.length;
  covDeviceKey = deviceRuntimeKey(selectedDevice);
  updateCovButton();
  pointStatus.textContent = options.auto ? "Preparing COV before control..." : "Starting BACnet SubscribeCOV...";
  pointStatus.className = "pill warn";
  try {
    const response = await fetch("/api/cov/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Alto-Request": "json" },
      body: JSON.stringify({
        ip: selectedDevice.ip,
        port: selectedDevice.port || 47808,
        network_number: selectedDevice.network_number ?? null,
        mac_address: selectedDevice.mac_address ?? null,
        timeout: Math.max(3, Number(pointTimeoutInput.value || 3)),
        lifetime: 300,
        points,
      }),
    });
    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || "COV start failed");
    }
    covJobId = result.job_id;
    await runCovPoll();
    return true;
  } catch (error) {
    stopCovLocal();
    pointStatus.textContent = `COV start failed: ${error.message}`;
    pointStatus.className = "pill error";
    return false;
  }
}

function stopCovLocal() {
  if (covTimer !== null) {
    window.clearTimeout(covTimer);
    covTimer = null;
  }
  covRunning = false;
  covDeviceKey = "";
  covJobId = null;
  covRequestedCount = 0;
  updateCovButton();
}

async function stopCovLive() {
  const jobId = covJobId;
  stopCovLocal();
  if (!jobId) {
    return;
  }
  try {
    await fetch(`/api/cov/jobs/${jobId}/stop`, {
    method: "POST",
    headers: { "X-Alto-Request": "json" },
  });
  } catch {
    // The local UI is already stopped; the backend job expires on lifetime if this request misses.
  }
}

function toggleCovLive() {
  if (covRunning) {
    stopCovLive();
    pointStatus.textContent = "COV live stopped";
    pointStatus.className = "pill muted";
    return;
  }
  startCovLive();
}

async function pollPointJob(jobId) {
  let cursor = 0;
  let failures = 0;
  let renderedRevision = "";
  while (true) {
    let response;
    let job;
    try {
      response = await fetch(`/api/points/jobs/${jobId}?after=${cursor}`);
      job = await response.json();
    } catch (error) {
      failures += 1;
      if (failures >= 5) throw new Error(`Point scan polling failed after 5 attempts: ${error.message}`);
      await delay(Math.min(3200, 400 * (2 ** (failures - 1))));
      continue;
    }
    if (!response.ok) {
      throw new Error(job.error || "Point scan failed");
    }
    failures = 0;
    pointActivityView.append(job);
    const nextCursor = Number(job.next_sequence);
    if (Number.isFinite(nextCursor) && nextCursor >= cursor) cursor = nextCursor;
    const points = job.points || [];
    const renderRevision = JSON.stringify({
      points,
      filters: [
        typeof activePointGroup === "undefined" ? "all" : activePointGroup,
        typeof pointFilterInput === "undefined" ? "" : pointFilterInput?.value || "",
        typeof pointSourceFilter === "undefined" ? "" : pointSourceFilter?.value || "",
        typeof pointTypeFilter === "undefined" ? "" : pointTypeFilter?.value || "",
        typeof pointIdFilter === "undefined" ? "" : pointIdFilter?.value || "",
      ],
    });
    if (renderRevision !== renderedRevision) {
      renderedRevision = renderRevision;
      renderPoints(points);
    }
    updatePointJobProgress(job);
    updatePointJobDiagnostics(job);
    if (isTerminalPointJob(job)) {
      const prefixes = { partial: "Partial", stopped: "Stopped" };
      const prefix = prefixes[job.status] || "Done";
      const total = Number(job.total);
      const completed = Number(job.completed);
      const terminalPercent = total > 0 && Number.isFinite(completed) && completed < total
        ? Math.max(0, Math.min(99, Math.round((completed / total) * 100)))
        : job.status === "done" && total > 0 && completed >= total
          ? 100
          : null;
      const terminalState = job.status === "partial" && total > 0 && completed >= total
        ? "Partial"
        : "";
      setPointProgress(
        terminalPercent,
        `${prefix} - ${countReadablePoints(points)} of ${points.length} point(s) read`,
        terminalState,
      );
      return job;
    }
    if (job.status === "error") {
      throw new Error(job.error || "Point scan failed");
    }
    await delay(400);
  }
}

function isTerminalPointJob(job) {
  return ["done", "partial", "stopped"].includes(job.status);
}

function updatePointJobDiagnostics(job) {
  const diagnostics = job.diagnostics || {};
  const missingIndexes = Array.isArray(diagnostics.missing_object_indexes)
    ? diagnostics.missing_object_indexes
    : [];
  const parts = [];
  if (missingIndexes.length) {
    parts.push(`Missing object-list indexes: ${missingIndexes.join(", ")}`);
  }
  if (diagnostics.selected_strategy) {
    const batch = diagnostics.rpm_batch ? `, RPM batch ${diagnostics.rpm_batch}` : "";
    parts.push(`Strategy: ${diagnostics.selected_strategy}${batch}`);
  }
  pointDiagnostics.textContent = parts.join(" · ");
}

function updatePointJobProgress(job) {
  const total = Number(job.total || 0);
  const completed = Number(job.completed || 0);
  if (total > 0) {
    const roundedPercent = Math.max(0, Math.min(100, Math.round((completed / total) * 100)));
    const percent = completed < total ? Math.min(99, roundedPercent) : roundedPercent;
    const points = job.points || [];
    const readable = countReadablePoints(points);
    setPointProgress(percent, `${job.message || "Scanning points"} ${completed}/${total} - ${readable} read`);
    pointStatus.textContent = `${readable} read / ${completed} scanned`;
    pointStatus.className = "pill warn";
    return;
  }
  setPointProgress(null, job.message || "Reading object list");
  pointStatus.textContent = job.message || "Reading object list";
  pointStatus.className = "pill warn";
}

function setPointProgress(percent, text, stateLabel = "") {
  if (percent === null || percent === undefined || !Number.isFinite(Number(percent))) {
    pointProgressPercent.textContent = stateLabel || "—";
    pointProgressBar.style.width = stateLabel ? "0%" : "100%";
    if (stateLabel) {
      pointProgressBar.classList.remove("indeterminate");
    } else {
      pointProgressBar.classList.add("indeterminate");
    }
    pointProgressText.textContent = text;
    if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
    return;
  }
  const value = Math.max(0, Math.min(100, Number(percent) || 0));
  pointProgressPercent.textContent = `${value}%`;
  pointProgressBar.style.width = `${value}%`;
  pointProgressBar.classList.remove("indeterminate");
  pointProgressText.textContent = text;
  if (typeof syncLiveCockpitIndicators === "function") syncLiveCockpitIndicators();
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

interfaceSelect.addEventListener("change", () => {
  customSubnetInput.value = "";
  customSubnetInput.setCustomValidity("");
  appliedRoutedCidrOption = null;
  updateSubnetSelect();
  updateSummary();
});

subnetSelect.addEventListener("change", () => {
  syncTargetFromSubnet();
  updateSummary();
});
addCustomSubnetButton.addEventListener("click", addCustomSubnet);
customSubnetInput.addEventListener("input", () => customSubnetInput.setCustomValidity(""));
customSubnetInput.addEventListener("keydown", (event) => {
  if (event.key !== "Enter") return;
  event.preventDefault();
  addCustomSubnet();
});

targetInput.addEventListener("input", () => {
  updateSelectedTargetBox();
  updateSummary();
});

scanTargetInput.addEventListener("input", () => {
  updateSummary();
});

portInput.addEventListener("input", () => {
  scanPortMirror.value = portInput.value;
  updateSelectedTargetBox();
  updateSummary();
});

scanPortMirror.addEventListener("input", () => {
  portInput.value = scanPortMirror.value;
  updateSelectedTargetBox();
  updateSummary();
});

useNetworkButton.addEventListener("click", () => {
  const value = targetInput.value.trim();
  scanTargetInput.value = value;
  updateSelectedTargetBox();
  updateSummary();
});

clearTargetButton.addEventListener("click", () => {
  targetInput.value = "";
  scanTargetInput.value = "";
  updateSelectedTargetBox();
  updateSummary();
});

quickScanButton.addEventListener("click", () => {
  scan({ subnetScan: true });
});

refreshNetworkButton.addEventListener("click", () => {
  loadInterfaces();
});

useGatewayNetworkButton.addEventListener("click", () => {
  const value = subnetSelect.value || interfaceSelect.selectedOptions[0]?.dataset.scanTarget || "255.255.255.255";
  scanTargetInput.value = value;
  updateSummary();
});

function updateSelectedTargetBox() {
  selectedTargetBox.textContent = targetInput.value ? `Target selected: ${targetInput.value}:${portInput.value || 47808}` : "No target selected.";
}

for (const input of modeInputs) {
  input.addEventListener("change", syncMode);
}

transportSelect?.addEventListener("change", () => {
  for (const input of modeInputs) {
    input.checked = input.value === transportSelect.value;
  }
  syncMode();
});

for (const tab of tabs) {
  tab.addEventListener("click", (event) => {
    event.preventDefault();
    navigateToView(tab.getAttribute("href")?.slice(1));
  });
}

window.addEventListener("hashchange", () => {
  setActiveView(window.location.hash.slice(1), { updateHash: false, scroll: false });
});

window.addEventListener("beforeunload", () => {
  activeScanController?.abort();
});

for (const input of [
  targetInput,
  scanTargetInput,
  subnetSelect,
  portInput,
  scanPortMirror,
  timeoutInput,
  mstpTimeoutInput,
  baudrateSelect,
  mstpMacInput,
  lowLimitInput,
  highLimitInput,
  retriesInput,
  sourcePortInput,
  routedRoutersInput,
  routedNetworksInput,
  routedMacsInput,
  globalBroadcastInput,
  serialPortSelect,
]) {
  input.addEventListener("input", updateSummary);
  input.addEventListener("change", updateSummary);
}

scanButton.addEventListener("click", scan);
stopScanButton.addEventListener("click", stopActiveScan);
scanPointsButton.addEventListener("click", scanPoints);
stopPointsButton?.addEventListener("click", stopActivePointScan);
covToggleButton?.addEventListener("click", toggleCovLive);
exportPointsButton?.addEventListener("click", exportFilteredPointsCsv);
pointFilterInput?.addEventListener("input", renderFilteredPoints);
pointSourceFilter?.addEventListener("change", renderFilteredPoints);
pointTypeFilter?.addEventListener("change", renderFilteredPoints);
pointIdFilter?.addEventListener("input", renderFilteredPoints);
for (const button of pointGroupButtons) {
  button.addEventListener("click", () => {
    activePointGroup = button.dataset.pointGroup || "all";
    updatePointGroupButtons();
    renderFilteredPoints();
  });
}

document.addEventListener("visibilitychange", syncCovPollVisibility);

function currentActiveViewId() {
  const activeTab = tabs.find((tab) => tab.classList.contains("active"));
  return normalizeView(activeTab?.getAttribute("href")?.slice(1) || window.location.hash.slice(1));
}

function syncModalParentVisibility() {
  if (!deviceScanSection || !deviceScanActivityPanel) return;
  const needsCarrier = deviceScanSection.classList.contains("view-hidden")
    && deviceScanActivityPanel.classList.contains("is-modal-open");
  deviceScanSection.classList.toggle("has-open-modal", needsCarrier);
}

function closeBacnetOverlayModals() {
  deviceScanActivityPanel?.classList.remove("is-modal-open");
  pointScanActivityPanel?.classList.remove("is-modal-open");
  scanSummaryPanel?.classList.remove("is-modal-open");
  if (bacnetModalBackdrop) bacnetModalBackdrop.hidden = true;
  syncModalParentVisibility();
}

function closeAdvancedRouteModal() {
  if (!bacnetAdvancedModal || bacnetAdvancedModal.hidden) return;
  bacnetAdvancedModal.hidden = true;
  updateAdvancedRouteBadge();
  updateSummary();
}

function closeAllBacnetModals() {
  closeBacnetOverlayModals();
  closeAdvancedRouteModal();
}

function openAdvancedRouteModal() {
  closeBacnetOverlayModals();
  if (!bacnetAdvancedModal) return;
  bacnetAdvancedModal.hidden = false;
  if (routedGatewaySettings && !routedGatewaySettings.classList.contains("hidden")) {
    routedGatewaySettings.open = true;
  }
  updateAdvancedRouteBadge();
}

function openBacnetActivityModal(targetKind = "") {
  closeAdvancedRouteModal();
  const usePoint = targetKind === "point"
    || (!targetKind && currentActiveViewId() === "pointScan");
  const panel = usePoint ? pointScanActivityPanel : deviceScanActivityPanel;
  const other = usePoint ? deviceScanActivityPanel : pointScanActivityPanel;
  other?.classList.remove("is-modal-open");
  scanSummaryPanel?.classList.remove("is-modal-open");
  if (!panel) return;
  panel.classList.add("is-modal-open");
  if (bacnetModalBackdrop) bacnetModalBackdrop.hidden = false;
  syncModalParentVisibility();
}

function openScanSummaryModal() {
  closeAdvancedRouteModal();
  deviceScanActivityPanel?.classList.remove("is-modal-open");
  pointScanActivityPanel?.classList.remove("is-modal-open");
  if (!scanSummaryPanel) return;
  scanSummaryPanel.classList.add("is-modal-open");
  if (bacnetModalBackdrop) bacnetModalBackdrop.hidden = false;
  syncModalParentVisibility();
}

function updateAdvancedRouteBadge() {
  if (!advancedRouteBadge) return;
  const hasLimits = Boolean(lowLimitInput?.value.trim() || highLimitInput?.value.trim());
  const nonDefaultRetries = Number(retriesInput?.value || 2) !== 2;
  const nonDefaultSourcePort = Number(sourcePortInput?.value || 0) !== 0;
  const hasRoutedFields = Boolean(routedRoutersInput?.value.trim() || routedNetworksInput?.value.trim());
  const nonDefaultMacs = (routedMacsInput?.value.trim() || "0-127") !== "0-127";
  const hasCustomCidr = Boolean(appliedRoutedCidrOption || customSubnetInput?.value.trim());
  const isCustom = hasLimits || nonDefaultRetries || nonDefaultSourcePort || hasRoutedFields || nonDefaultMacs || hasCustomCidr;
  advancedRouteBadge.textContent = isCustom ? "Custom" : "Default";
  advancedRouteBadge.classList.toggle("is-active", isCustom);
  openAdvancedRouteModalBtn?.classList.toggle("active", isCustom);
  if (advancedRouteSummaryHint) {
    const summaryParts = [];
    if (appliedRoutedCidrOption?.cidr) summaryParts.push(`CIDR ${appliedRoutedCidrOption.cidr}`);
    if (hasLimits) summaryParts.push(`IDs ${deviceRangeLabel()}`);
    if (hasRoutedFields) summaryParts.push("manual routed path");
    if (nonDefaultMacs) summaryParts.push(`MACs ${routedMacsInput.value.trim()}`);
    advancedRouteSummaryHint.textContent = summaryParts.length
      ? `Active overrides: ${summaryParts.join(" · ")}`
      : "Default Who-Is limits and automatic router discovery active.";
  }
}

function syncLiveCockpitIndicators() {
  if (inlineDeviceProgressPercent && scanPercent) {
    inlineDeviceProgressPercent.textContent = scanPercent.textContent || "0%";
  }
  if (inlineDeviceProgressBar && scanProgressBar) {
    inlineDeviceProgressBar.style.width = scanProgressBar.style.width || "0%";
    inlineDeviceProgressBar.classList.toggle(
      "indeterminate",
      scanProgressBar.classList.contains("indeterminate"),
    );
  }
  if (inlinePointProgressPercent && pointProgressPercent) {
    inlinePointProgressPercent.textContent = pointProgressPercent.textContent || "0%";
  }
  if (inlinePointProgressLabel && pointProgressText) {
    inlinePointProgressLabel.textContent = pointProgressText.textContent || "Idle";
  }
  if (inlinePointProgressBar && pointProgressBar) {
    inlinePointProgressBar.style.width = pointProgressBar.style.width || "0%";
    inlinePointProgressBar.classList.toggle(
      "indeterminate",
      pointProgressBar.classList.contains("indeterminate"),
    );
  }
  if (bacnetActivityModalBadge) {
    const onPoint = currentActiveViewId() === "pointScan";
    const activePanel = onPoint ? pointScanActivityPanel : deviceScanActivityPanel;
    const fallbackPanel = onPoint ? deviceScanActivityPanel : pointScanActivityPanel;
    const readPanelSnapshot = (panel) => {
      const stateText = (panel?.querySelector('[data-activity-role="state"]')?.textContent || "Ready").trim();
      const rxRaw = (panel?.querySelector('[data-activity-role="rx"]')?.textContent || "RX 0").trim();
      const txRaw = (panel?.querySelector('[data-activity-role="tx"]')?.textContent || "TX 0").trim();
      const logCount = panel?.querySelector('[data-activity-role="log-body"]')?.children?.length || 0;
      const rx = Number(rxRaw.replace(/[^0-9]/g, "") || 0);
      const tx = Number(txRaw.replace(/[^0-9]/g, "") || 0);
      const running = Boolean(panel?.classList.contains("running") || stateText === "Scanning");
      return { stateText, rx, tx, logCount, running };
    };
    const primary = readPanelSnapshot(activePanel);
    const secondary = readPanelSnapshot(fallbackPanel);
    const totalHistory = primary.logCount + secondary.logCount;
    const isRunning = primary.running || secondary.running;
    let badgeLabel = primary.stateText;
    if (isRunning) {
      const activeRx = primary.running ? primary.rx : secondary.rx;
      badgeLabel = activeRx > 0 ? `Scanning · RX ${activeRx}` : "Scanning";
    } else if (primary.rx > 0) {
      badgeLabel = `RX ${primary.rx}`;
    } else if (primary.logCount > 0) {
      badgeLabel = `${primary.logCount} log`;
    } else if (totalHistory > 0) {
      badgeLabel = `${totalHistory} log`;
    }
    bacnetActivityModalBadge.textContent = badgeLabel;
    bacnetActivityModalBadge.className = "btn-badge";
    if (isRunning) {
      bacnetActivityModalBadge.classList.add("is-running");
    } else if (primary.stateText === "Error") {
      bacnetActivityModalBadge.classList.add("is-error");
    } else if (primary.stateText === "Partial" || primary.stateText === "Stopped") {
      bacnetActivityModalBadge.classList.add("is-warn");
    } else if (primary.rx > 0 || totalHistory > 0 || primary.stateText === "Complete") {
      bacnetActivityModalBadge.classList.add("is-active");
    }
  }
  if (scanSummaryModalBadge) {
    const scanRunning = Boolean(activeScanController) || statusText?.dataset.state === "busy";
    const hasCompletedScan = Boolean(
      discoveredDevices.length > 0
        || (summaryDuration && summaryDuration.textContent && summaryDuration.textContent !== "-"),
    );
    const netCount = advertisedRoutedNetworks.size;
    scanSummaryModalBadge.className = "btn-badge";
    if (scanRunning) {
      scanSummaryModalBadge.textContent = "Scanning";
      scanSummaryModalBadge.classList.add("is-running");
    } else if (statusText?.dataset.state === "error") {
      scanSummaryModalBadge.textContent = discoveredDevices.length
        ? `${discoveredDevices.length} dev`
        : "Error";
      scanSummaryModalBadge.classList.add("is-error");
    } else if (hasCompletedScan) {
      scanSummaryModalBadge.textContent = netCount > 0
        ? `${discoveredDevices.length} dev · ${netCount} net`
        : `${discoveredDevices.length} dev`;
      scanSummaryModalBadge.classList.add(
        statusText?.dataset.state === "warn" ? "is-warn" : "is-active",
      );
    } else {
      scanSummaryModalBadge.textContent = "Idle";
    }
  }
}

function syncStandaloneViewportGuard() {
  if (!bacnetViewportGuard) return;
  if (window.parent !== window) {
    bacnetViewportGuard.hidden = true;
    return;
  }
  const width = Math.round(window.innerWidth || 0);
  const height = Math.round(window.innerHeight || 0);
  const tooSmall = width > 0 && height > 0 && (width < 1020 || height < 610);
  bacnetViewportGuard.hidden = !tooSmall;
  if (tooSmall && bacnetViewportSizeReadout) {
    bacnetViewportSizeReadout.textContent = `${width} × ${height} px`;
  }
}

openBacnetActivityModalBtn?.addEventListener("click", () => openBacnetActivityModal());
openScanSummaryModalBtn?.addEventListener("click", openScanSummaryModal);
openAdvancedRouteModalBtn?.addEventListener("click", openAdvancedRouteModal);
gatewayOpenActivityBtn?.addEventListener("click", () => openBacnetActivityModal("device"));
inlineDeviceProgressWrap?.addEventListener("click", () => openBacnetActivityModal("device"));
pointOpenActivityBtn?.addEventListener("click", () => openBacnetActivityModal("point"));
pointToolbarActivityBtn?.addEventListener("click", () => openBacnetActivityModal("point"));
inlinePointProgressWrap?.addEventListener("click", () => openBacnetActivityModal("point"));
bacnetModalBackdrop?.addEventListener("click", closeBacnetOverlayModals);
bacnetAdvancedModal?.addEventListener("click", (event) => {
  if (event.target === bacnetAdvancedModal) closeAdvancedRouteModal();
});
for (const closeBtn of document.querySelectorAll("[data-close-bacnet-modal]")) {
  closeBtn.addEventListener("click", closeBacnetOverlayModals);
}
for (const switchBtn of document.querySelectorAll("[data-switch-activity-modal]")) {
  switchBtn.addEventListener("click", () => {
    openBacnetActivityModal(switchBtn.dataset.switchActivityModal || "");
  });
}
for (const closeBtn of document.querySelectorAll("[data-close-advanced-modal]")) {
  closeBtn.addEventListener("click", closeAdvancedRouteModal);
}
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeAllBacnetModals();
});
window.addEventListener("resize", syncStandaloneViewportGuard);

loadInterfaces();
loadSerialPorts();
syncMode();
updateSelectedDevice();
updateSelectedTargetBox();
updatePointGroupButtons();
updateAdvancedRouteBadge();
syncLiveCockpitIndicators();
syncStandaloneViewportGuard();
setActiveView(window.location.hash.slice(1), { updateHash: false, scroll: false });

(() => {
  if (window.parent === window) return;
  document.documentElement.classList.add("in-hub");
  let lastHeight = 0;
  const postHubSize = () => {
    const height = Math.max(480, Math.ceil(window.innerHeight || 720));
    if (height === lastHeight) return;
    lastHeight = height;
    window.parent.postMessage({ type: "alto-tool-size", tool: "bacnet", height }, "*");
  };
  let frame = 0;
  const scheduleHubSize = () => {
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      postHubSize();
    });
  };
  window.addEventListener("load", scheduleHubSize);
  window.addEventListener("resize", scheduleHubSize);
  window.addEventListener("message", (event) => {
    if (event.data && event.data.type === "alto-hub-request-size") scheduleHubSize();
  });
  scheduleHubSize();
})();
