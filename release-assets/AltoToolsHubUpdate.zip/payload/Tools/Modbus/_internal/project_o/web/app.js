const els = {
  supportBadge: document.querySelector("#supportBadge"),
  connectionBadge: document.querySelector("#connectionBadge"),
  tabs: document.querySelectorAll("[data-tab]"),
  tabPanels: document.querySelectorAll("[data-panel]"),
  connectBtn: document.querySelector("#connectBtn"),
  disconnectBtn: document.querySelector("#disconnectBtn"),
  connectLabel: document.querySelector("#connectLabel"),
  disconnectLabel: document.querySelector("#disconnectLabel"),
  connectionDetail: document.querySelector("#connectionDetail"),
  readOnceBtn: document.querySelector("#readOnceBtn"),
  pollBtn: document.querySelector("#pollBtn"),
  stopPollBtn: document.querySelector("#stopPollBtn"),
  writeBtn: document.querySelector("#writeBtn"),
  quickScanBtn: document.querySelector("#quickScanBtn"),
  scanBtn: document.querySelector("#scanBtn"),
  stopBtn: document.querySelector("#stopBtn"),
  clearBtn: document.querySelector("#clearBtn"),
  gatewayScanBtn: document.querySelector("#gatewayScanBtn"),
  gatewayStopBtn: document.querySelector("#gatewayStopBtn"),
  gatewaySubnetBtn: document.querySelector("#gatewaySubnetBtn"),
  gatewayAutoNetworkBtn: document.querySelector("#gatewayAutoNetworkBtn"),
  networkRefreshBtn: document.querySelector("#networkRefreshBtn"),
  importScanBtn: document.querySelector("#importScanBtn"),
  exportBtn: document.querySelector("#exportBtn"),
  pollBody: document.querySelector("#pollBody"),
  resultsBody: document.querySelector("#resultsBody"),
  gatewayResults: document.querySelector("#gatewayResults"),
  gatewaySummary: document.querySelector("#gatewaySummary"),
  foundDevices: document.querySelector("#foundDevices"),
  foundSummary: document.querySelector("#foundSummary"),
  logList: document.querySelector("#logList"),
  registerSummary: document.querySelector("#registerSummary"),
  registerDeviceCount: document.querySelector("#registerDeviceCount"),
  registerPointCount: document.querySelector("#registerPointCount"),
  registerRangeCount: document.querySelector("#registerRangeCount"),
  registerMapBody: document.querySelector("#registerMapBody"),
  refreshRegisterMapBtn: document.querySelector("#refreshRegisterMapBtn"),
  trafficSummary: document.querySelector("#trafficSummary"),
  trafficBody: document.querySelector("#trafficBody"),
  clearTrafficBtn: document.querySelector("#clearTrafficBtn"),
  scanState: document.querySelector("#scanState"),
  gatewayScanState: document.querySelector("#gatewayScanState"),
  lastPollBadge: document.querySelector("#lastPollBadge"),
  scanProgressText: document.querySelector("#scanProgressText"),
  scanProgressPercent: document.querySelector("#scanProgressPercent"),
  scanProgressBar: document.querySelector("#scanProgressBar"),
  gatewayProgressText: document.querySelector("#gatewayProgressText"),
  gatewayProgressPercent: document.querySelector("#gatewayProgressPercent"),
  gatewayProgressBar: document.querySelector("#gatewayProgressBar"),
  devicesCount: document.querySelector("#devicesCount"),
  requestsCount: document.querySelector("#requestsCount"),
  errorsCount: document.querySelector("#errorsCount"),
  mode: document.querySelector("#mode"),
  rtuFields: document.querySelector("#rtuFields"),
  tcpFields: document.querySelector("#tcpFields"),
  slaveFromLabel: document.querySelector("#slaveFromLabel"),
  slaveToLabel: document.querySelector("#slaveToLabel"),
  baudRate: document.querySelector("#baudRate"),
  dataBits: document.querySelector("#dataBits"),
  stopBits: document.querySelector("#stopBits"),
  parity: document.querySelector("#parity"),
  tcpHost: document.querySelector("#tcpHost"),
  tcpPort: document.querySelector("#tcpPort"),
  unitId: document.querySelector("#unitId"),
  timeoutMs: document.querySelector("#timeoutMs"),
  readFunction: document.querySelector("#readFunction"),
  readAddress: document.querySelector("#readAddress"),
  readQuantity: document.querySelector("#readQuantity"),
  readType: document.querySelector("#readType"),
  readWordOrder: document.querySelector("#readWordOrder"),
  pollRate: document.querySelector("#pollRate"),
  writeFunction: document.querySelector("#writeFunction"),
  writeAddress: document.querySelector("#writeAddress"),
  writeValue: document.querySelector("#writeValue"),
  slaveFrom: document.querySelector("#slaveFrom"),
  slaveTo: document.querySelector("#slaveTo"),
  scanFunction: document.querySelector("#scanFunction"),
  scanAddress: document.querySelector("#scanAddress"),
  scanQuantity: document.querySelector("#scanQuantity"),
  gatewayRange: document.querySelector("#gatewayRange"),
  gatewayPort: document.querySelector("#gatewayPort"),
  gatewayProbeIds: document.querySelector("#gatewayProbeIds"),
  networkInterface: document.querySelector("#networkInterface"),
  networkSubnet: document.querySelector("#networkSubnet"),
  stopOnFound: document.querySelector("#stopOnFound"),
  fastTimeoutSkip: document.querySelector("#fastTimeoutSkip"),
  deviceMonitorBadge: document.querySelector("#deviceMonitorBadge"),
  deviceInsightBadge: document.querySelector("#deviceInsightBadge"),
  deviceTemplate: document.querySelector("#deviceTemplate"),
  deviceId: document.querySelector("#deviceId"),
  deviceName: document.querySelector("#deviceName"),
  deviceFunction: document.querySelector("#deviceFunction"),
  deviceInterval: document.querySelector("#deviceInterval"),
  covMode: document.querySelector("#covMode"),
  covDeadband: document.querySelector("#covDeadband"),
  customPointBuilder: document.querySelector("#customPointBuilder"),
  pointBuilderTitle: document.querySelector("#pointBuilderTitle"),
  customPointSummary: document.querySelector("#customPointSummary"),
  pointName: document.querySelector("#pointName"),
  pointAddress: document.querySelector("#pointAddress"),
  pointType: document.querySelector("#pointType"),
  pointWordOrder: document.querySelector("#pointWordOrder"),
  pointScale: document.querySelector("#pointScale"),
  pointUnit: document.querySelector("#pointUnit"),
  addPointBtn: document.querySelector("#addPointBtn"),
  clearPointDraftBtn: document.querySelector("#clearPointDraftBtn"),
  customPointList: document.querySelector("#customPointList"),
  addDeviceBtn: document.querySelector("#addDeviceBtn"),
  importFoundBtn: document.querySelector("#importFoundBtn"),
  exportDeviceConfigBtn: document.querySelector("#exportDeviceConfigBtn"),
  importDeviceConfigBtn: document.querySelector("#importDeviceConfigBtn"),
  deviceConfigInput: document.querySelector("#deviceConfigInput"),
  refreshDevicesBtn: document.querySelector("#refreshDevicesBtn"),
  startDeviceMonitorBtn: document.querySelector("#startDeviceMonitorBtn"),
  stopDeviceMonitorBtn: document.querySelector("#stopDeviceMonitorBtn"),
  clearDevicesBtn: document.querySelector("#clearDevicesBtn"),
  deviceSummary: document.querySelector("#deviceSummary"),
  deviceGrid: document.querySelector("#deviceGrid"),
  modalBackdrop: document.querySelector("#modbusModalBackdrop"),
  modals: document.querySelectorAll("[data-modbus-modal]"),
  openModalBtns: document.querySelectorAll("[data-open-modbus-modal]"),
  closeModalBtns: document.querySelectorAll("[data-close-modbus-modal]"),
  gatewayModalBadge: document.querySelector("#gatewayModalBadge"),
  activityCountBadge: document.querySelector("#activityCountBadge"),
  trafficModalBadge: document.querySelector("#trafficModalBadge"),
  foundDeviceWrap: document.querySelector("#foundDeviceWrap"),
  scanSearchInput: document.querySelector("#scanPanel .search-box"),
  viewportGuard: document.querySelector("#modbusViewportGuard"),
  viewportSize: document.querySelector("#modbusViewportSize")
};

const state = {
  port: null,
  reader: null,
  writer: null,
  readerActive: false,
  readLoopPromise: null,
  serialConnecting: false,
  serialClosing: false,
  readBuffer: [],
  rtuFailureCount: 0,
  rtuMonitorRetryAt: 0,
  activeTab: "poll",
  openModal: null,
  scanSearchQuery: "",
  scanning: false,
  polling: false,
  connected: false,
  mode: els.mode.value,
  tcpTarget: null,
  tcpAbortController: null,
  selectedGateway: null,
  gatewayScanning: false,
  gatewayScanStarted: false,
  gatewayAbortController: null,
  activeGatewayScan: null,
  gatewayResults: [],
  networkInterfaces: [],
  networkSelection: null,
  backendReady: false,
  results: [],
  requests: 0,
  errors: 0,
  devices: [],
  customPoints: [],
  draggedPointIndex: null,
  draggedDeviceIndex: null,
  deviceResize: null,
  pointEditor: null,
  deviceMonitoring: false,
  deviceMonitorTimer: null,
  deviceRefreshRunning: false,
  deviceMonitorRefreshRunning: false,
  modbusQueue: [],
  modbusQueueRunning: false,
  writeInProgress: false,
  traffic: []
};

const SCAN_RENDER_INTERVAL_MS = 100;
let scanResultsRenderTimer = null;
let gatewayResultsRenderTimer = null;
let trafficRenderTimer = null;

const NETWORK_SELECTION_KEY = "altoModbus.networkSelection.v1";
const RTU_MAX_BUFFER_BYTES = 512;
const RTU_DEFAULT_RECOVERY_ATTEMPTS = 2;
const RTU_LINE_FAILURE_THRESHOLD = 2;
const RTU_MONITOR_BACKOFF_MAX_MS = 3000;

const READ_FUNCTIONS = {
  1: "01 Coils",
  2: "02 Discrete inputs",
  3: "03 Holding registers",
  4: "04 Input registers"
};

const WRITE_FUNCTIONS = {
  5: "05 Write single coil",
  6: "06 Write single register",
  15: "15 Write multiple coils",
  16: "16 Write multiple registers"
};

const DEVICE_CARD_DEFAULT_SPAN = 6;
const DEVICE_CARD_MIN_SPAN = 2;
const DEVICE_CARD_MAX_SPAN = 12;
const DEVICE_CARD_DEFAULT_HEIGHT = 380;
const DEVICE_CARD_MIN_HEIGHT = 300;
const DEVICE_CARD_MAX_HEIGHT = 900;
const DEVICE_CARD_HEIGHT_STEP = 20;
const DEVICE_CARD_GRID_GAP = 8;
const DEVICE_CARD_AUTO_HEADER_HEIGHT = 180;
const DEVICE_CARD_AUTO_EDIT_EXTRA_HEIGHT = 130;
const DEVICE_CARD_AUTO_POINT_ROW_HEIGHT = 32;
const DEVICE_CARD_AUTO_MAX_VISIBLE_POINTS = 18;

const DEVICE_TEMPLATES = {
  generic: {
    label: "Generic register",
    functionCode: 3,
    name: (id) => `Device ${id}`,
    points: [{ name: "Value", address: 0, type: "uint16", wordOrder: "be", scale: 1, unit: "" }]
  },
  custom: {
    label: "Custom points",
    functionCode: 3,
    name: (id) => `Custom ${id}`,
    points: []
  }
};

const POINT_TYPES = {
  uint16: { label: "uint16", registers: 1 },
  int16: { label: "int16", registers: 1 },
  uint32: { label: "uint32 / ulong", registers: 2 },
  int32: { label: "int32 / long", registers: 2 },
  float32: { label: "float32", registers: 2 },
  uint64: { label: "uint64 / ulong64", registers: 4 },
  int64: { label: "int64 / long64", registers: 4 },
  float64: { label: "float64 / double", registers: 4 }
};

const ICON_EDIT = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21.2 6.8 8.1 19.9a2 2 0 0 1-.8.5L3 21.7l1.3-4.3a2 2 0 0 1 .5-.8L17.9 3.5a2.3 2.3 0 0 1 3.3 3.3Z"></path><path d="m15.5 5.9 2.6 2.6"></path></svg>';
const ICON_COPY = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="12" height="12" rx="2"></rect><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"></path></svg>';
const ICON_TRASH = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18"></path><path d="M8 6V4h8v2"></path><path d="M19 6l-1 14H6L5 6"></path><path d="M10 11v5"></path><path d="M14 11v5"></path></svg>';

function setBadge(el, text, kind) {
  el.textContent = text;
  el.className = `badge ${kind}`;
}

function setConnectionDetail(message, kind = "idle") {
  els.connectionDetail.textContent = message;
  els.connectionDetail.className = `connection-detail ${kind}`;
}

function shortError(error) {
  const message = typeof error === "string" ? error : error?.message || "unknown error";
  return message.replace(/^\[WinError\s+\d+\]\s*/i, "").trim();
}

function setSupportBadge() {
  if (state.mode === "tcp") {
    setBadge(els.supportBadge, state.backendReady ? "TCP API ready" : "TCP API inactive", state.backendReady ? "ready" : "error");
    return;
  }

  if ("serial" in navigator) {
    setBadge(els.supportBadge, "Web Serial ready", "ready");
  } else {
    setBadge(els.supportBadge, "Use Chrome or Edge", "error");
  }
}

async function checkBackend() {
  try {
    const response = await fetch("/api/health", { cache: "no-store" });
    const payload = await readApiPayload(response);
    state.backendReady = response.ok && payload.ok === true;
  } catch {
    state.backendReady = false;
  }
  setSupportBadge();
  return state.backendReady;
}

function networkInterfaceKey(item) {
  if (!item) return "";
  return `${item.index ?? ""}|${item.name || ""}|${item.ip || ""}`;
}

function networkInterfaceLabel(item) {
  const status = item.isUp === false || item.is_up === false ? "[DOWN]" : "[UP]";
  const subnet = item.subnet || item.scanSubnet || "";
  return `${status} ${item.name} - ${item.ip} (${subnet})`;
}

function readSavedNetworkSelection() {
  if (state.networkSelection) return state.networkSelection;
  try {
    const saved = JSON.parse(localStorage.getItem(NETWORK_SELECTION_KEY) || "null");
    if (saved && typeof saved === "object") {
      state.networkSelection = {
        interfaceKey: String(saved.interfaceKey || ""),
        subnetCidr: String(saved.subnetCidr || "")
      };
    }
  } catch {
    state.networkSelection = null;
  }
  return state.networkSelection;
}

function selectedNetworkSelection() {
  const item = selectedNetworkInterface();
  const option = els.networkSubnet.selectedOptions[0];
  const interfaceKey = networkInterfaceKey(item);
  if (!item || !interfaceKey) return readSavedNetworkSelection();
  return {
    interfaceKey,
    subnetCidr: option?.dataset.cidr || item.scanSubnet || item.subnet || ""
  };
}

function saveSelectedNetworkSelection() {
  const selection = selectedNetworkSelection();
  if (!selection?.interfaceKey) return;
  state.networkSelection = selection;
  try {
    localStorage.setItem(NETWORK_SELECTION_KEY, JSON.stringify(selection));
  } catch {
    // Local storage can be blocked; the in-memory selection still keeps this session stable.
  }
}

async function loadNetworkInterfaces(applyFirst = false) {
  if (!state.backendReady && !(await checkBackend())) {
    els.networkInterface.innerHTML = '<option value="">TCP API inactive</option>';
    els.networkSubnet.innerHTML = '<option value="">No subnet</option>';
    return;
  }

  try {
    const response = await fetch("/api/network/interfaces", { cache: "no-store" });
    const payload = await readApiPayload(response);
    if (!response.ok) throw new Error(payload.error || "Network detection failed");
    state.networkInterfaces = Array.isArray(payload.interfaces) ? payload.interfaces : [];
  } catch (error) {
    state.networkInterfaces = [];
    els.networkInterface.innerHTML = '<option value="">Cannot detect network</option>';
    els.networkSubnet.innerHTML = '<option value="">No subnet</option>';
    log(`Network detection failed: ${shortError(error)}.`);
    return;
  }

  const previousSelection = selectedNetworkSelection();
  const savedSelection = readSavedNetworkSelection();
  const desiredSelection = previousSelection?.interfaceKey ? previousSelection : savedSelection;

  els.networkInterface.innerHTML = "";
  els.networkSubnet.innerHTML = "";
  if (state.networkInterfaces.length === 0) {
    els.networkInterface.innerHTML = '<option value="">No active IPv4 network</option>';
    els.networkSubnet.innerHTML = '<option value="">No subnet</option>';
    els.gatewayScanState.textContent = "No active IPv4 network detected";
    return;
  }

  state.networkInterfaces.forEach((item, index) => {
    const option = document.createElement("option");
    option.value = String(index);
    option.textContent = networkInterfaceLabel(item);
    els.networkInterface.append(option);
  });

  let selectedIndex = state.networkInterfaces.findIndex((item) => networkInterfaceKey(item) === desiredSelection?.interfaceKey);
  if (selectedIndex < 0) {
    selectedIndex = applyFirst ? 0 : Number.parseInt(els.networkInterface.value, 10);
  }
  if (!Number.isFinite(selectedIndex) || selectedIndex < 0 || selectedIndex >= state.networkInterfaces.length) {
    selectedIndex = 0;
  }
  els.networkInterface.value = String(selectedIndex);
  populateNetworkSubnets(desiredSelection?.subnetCidr);
  applySelectedNetworkSubnet();
}

function selectedNetworkInterface() {
  const index = Number.parseInt(els.networkInterface.value, 10);
  return state.networkInterfaces[index] || null;
}

function populateNetworkSubnets(preferredCidr = "") {
  const item = selectedNetworkInterface();
  if (!item) {
    els.networkSubnet.innerHTML = '<option value="">No subnet</option>';
    return;
  }
  const subnets = Array.isArray(item.subnets) && item.subnets.length
    ? item.subnets
    : [{ cidr: item.scanSubnet || item.subnet, scanRange: item.scanRange, hosts: item.hosts, source: "interface" }];
  els.networkSubnet.innerHTML = "";
  subnets.forEach((subnet, index) => {
    const option = document.createElement("option");
    option.value = String(index);
    option.textContent = `${subnet.cidr} (${subnet.hosts} hosts)`;
    option.dataset.scanRange = subnet.scanRange;
    option.dataset.cidr = subnet.cidr;
    option.dataset.hosts = String(subnet.hosts);
    els.networkSubnet.append(option);
  });

  const defaultIndex = subnets.findIndex((subnet) => subnet.cidr === preferredCidr);
  const fallbackIndex = subnets.findIndex((subnet) => subnet.cidr === item.scanSubnet);
  els.networkSubnet.value = String(defaultIndex >= 0 ? defaultIndex : fallbackIndex >= 0 ? fallbackIndex : 0);
}

function applySelectedNetworkSubnet() {
  if (state.gatewayScanning) return;
  const item = selectedNetworkInterface();
  const option = els.networkSubnet.selectedOptions[0];
  if (!item || !option) {
    log("No subnet selected.");
    return;
  }
  els.gatewayRange.value = option.dataset.scanRange || "";
  els.gatewayPort.value = readNumber(els.tcpPort, 502, 1, 65535);
  const cidr = option.dataset.cidr || "";
  els.gatewayScanState.textContent = `${item.name} ${item.ip}/${item.prefixLength} - scan ${cidr}`;
  saveSelectedNetworkSelection();
  clearGatewayScanResultsForSubnetChange();
  log(`Gateway scan range set from ${item.name}: ${els.gatewayRange.value} (${cidr}).`);
}

function applySelectedNetworkInterface() {
  populateNetworkSubnets();
  applySelectedNetworkSubnet();
}

function syncDevicesToTcpTarget(host, port) {
  const targetHost = String(host || "").trim();
  const targetPort = Number.parseInt(port || 502, 10) || 502;
  if (!targetHost || state.devices.length === 0) return;
  for (const device of state.devices) {
    device.tcpHost = targetHost;
    device.tcpPort = targetPort;
    device.nextMonitorAt = 0;
  }
  renderDevicesPreservingScroll();
  log(`Updated ${state.devices.length} device profile(s) to ${targetHost}:${targetPort}.`);
}

function setConnected(connected, label = connected ? "Connected" : "Disconnected") {
  state.connected = connected;
  setBadge(els.connectionBadge, label, connected ? "live" : "idle");
  els.connectBtn.disabled = connected;
  els.disconnectBtn.disabled = !connected;
  els.readOnceBtn.disabled = !connected;
  els.pollBtn.disabled = !connected || state.polling;
  els.writeBtn.disabled = !connected;
  els.scanBtn.disabled = !connected;
  updateDeviceControls();
}

function updateActivityCountBadge() {
  if (!els.activityCountBadge || !els.logList) return;
  els.activityCountBadge.textContent = String(els.logList.children.length);
}

function updateTrafficCountBadge() {
  if (!els.trafficModalBadge) return;
  els.trafficModalBadge.textContent = String(state.traffic.length);
}

function updateGatewayModalBadge() {
  if (!els.gatewayModalBadge) return;
  const candidates = state.gatewayResults.filter((result) => result.modbusOk || result.tcpOpen);
  els.gatewayModalBadge.classList.remove("is-live", "is-found");
  if (state.gatewayScanning) {
    els.gatewayModalBadge.textContent = "Scanning...";
    els.gatewayModalBadge.classList.add("is-live");
    return;
  }
  if (candidates.length > 0) {
    els.gatewayModalBadge.textContent = `${candidates.length} found`;
    els.gatewayModalBadge.classList.add("is-found");
    return;
  }
  els.gatewayModalBadge.textContent = state.gatewayScanStarted ? "0 found" : "Ready";
}

function openModbusModal(name) {
  if (!name) return;
  state.openModal = name;
  els.modals.forEach((modal) => {
    modal.classList.toggle("is-modal-open", modal.dataset.modbusModal === name);
  });
  els.openModalBtns.forEach((btn) => {
    btn.classList.toggle("is-modal-active", btn.dataset.openModbusModal === name);
  });
  els.tabs.forEach((tab) => {
    if (tab.dataset.tab === "traffic") {
      tab.classList.toggle("is-modal-active", name === "traffic");
    }
  });
  if (els.modalBackdrop) {
    els.modalBackdrop.classList.remove("hidden");
    els.modalBackdrop.setAttribute("aria-hidden", "false");
  }
  if (name === "traffic") {
    scheduleTrafficRender();
    flushTrafficRender();
  }
}

function closeModbusModal() {
  state.openModal = null;
  els.modals.forEach((modal) => {
    modal.classList.remove("is-modal-open");
  });
  els.openModalBtns.forEach((btn) => {
    btn.classList.remove("is-modal-active");
  });
  els.tabs.forEach((tab) => {
    if (tab.dataset.tab === "traffic") {
      tab.classList.remove("is-modal-active");
    }
  });
  if (els.modalBackdrop) {
    els.modalBackdrop.classList.add("hidden");
    els.modalBackdrop.setAttribute("aria-hidden", "true");
  }
}

function updateViewportGuard() {
  if (!els.viewportGuard) return;
  const width = Math.round(window.innerWidth || 0);
  const height = Math.round(window.innerHeight || 0);
  if (els.viewportSize) {
    els.viewportSize.textContent = `${width} × ${height} px`;
  }
  const isStandalone = window.parent === window;
  const tooSmall = isStandalone && (width < 1020 || height < 610);
  els.viewportGuard.hidden = !tooSmall;
}

function log(message) {
  const timestamp = new Date();
  const item = document.createElement("li");
  item.textContent = `${timestamp.toLocaleTimeString()} ${message}`;
  els.logList.prepend(item);
  while (els.logList.children.length > 100) {
    els.logList.lastElementChild.remove();
  }
  updateActivityCountBadge();
  addTrafficEvent(message, timestamp);
}

function trafficKind(message) {
  if (/failed|failure|error|warning|timeout|timed out|read-only/i.test(message)) {
    return { code: "err", label: "ERROR" };
  }
  if (/replied|OK|connected|completed|refreshed|changed|found|imported|exported/i.test(message)) {
    return { code: "rx", label: "RX" };
  }
  if (/read |write|wrote|scan started|polling started|gateway scan started|loaded|target selected/i.test(message)) {
    return { code: "tx", label: "TX" };
  }
  return { code: "sys", label: "SYS" };
}

function addTrafficEvent(message, timestamp = new Date()) {
  if (!els.trafficBody) return;
  const kind = trafficKind(message);
  state.traffic.unshift({
    time: timestamp.toLocaleTimeString(),
    code: kind.code,
    label: kind.label,
    detail: message
  });
  if (state.traffic.length > 300) state.traffic.length = 300;
  updateTrafficCountBadge();
  if (state.activeTab === "traffic") scheduleTrafficRender();
  if (state.openModal === "traffic") scheduleTrafficRender();
}

function scheduleTrafficRender() {
  if (trafficRenderTimer !== null) return;
  trafficRenderTimer = window.setTimeout(() => {
    trafficRenderTimer = null;
    renderTraffic();
  }, SCAN_RENDER_INTERVAL_MS);
}

function flushTrafficRender() {
  if (trafficRenderTimer !== null) {
    window.clearTimeout(trafficRenderTimer);
    trafficRenderTimer = null;
  }
  renderTraffic();
}

function renderTraffic() {
  if (!els.trafficBody) return;
  els.trafficBody.innerHTML = "";
  if (state.traffic.length === 0) {
    els.trafficSummary.textContent = "No traffic yet";
    els.trafficBody.innerHTML = `
      <tr class="empty-row">
        <td colspan="4">Traffic events will appear here after connect, read, write, scan, or monitor.</td>
      </tr>
    `;
    return;
  }

  els.trafficSummary.textContent = `${state.traffic.length} event(s) captured`;
  for (const entry of state.traffic) {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${escapeHtml(entry.time)}</td>
      <td><span class="traffic-direction ${escapeHtml(entry.code)}">${escapeHtml(entry.label)}</span></td>
      <td>Modbus</td>
      <td>${escapeHtml(entry.detail)}</td>
    `;
    els.trafficBody.append(row);
  }
}

function readNumber(input, fallback, min, max) {
  if (!input) return fallback;
  const value = Number.parseInt(input.value, 10);
  if (Number.isNaN(value)) return fallback;
  return Math.min(max, Math.max(min, value));
}

function readSecondsAsMs(input, fallbackMs, minMs, maxMs) {
  if (!input) return fallbackMs;
  const value = Number.parseFloat(input.value);
  if (Number.isNaN(value)) return fallbackMs;
  return Math.min(maxMs, Math.max(minMs, Math.round(value * 1000)));
}

function intervalMsFromValue(value, fallbackMs = 1000, unit = "ms") {
  const number = Number.parseFloat(value);
  if (Number.isNaN(number)) return fallbackMs;
  const ms = unit === "sec" ? Math.round(number * 1000) : Math.round(number);
  return Math.min(60000, Math.max(500, ms));
}

function msToSecondsValue(value, fallbackMs = 1000) {
  const ms = Number.isFinite(Number(value)) ? Number(value) : fallbackMs;
  return Number.parseFloat((ms / 1000).toFixed(3)).toString();
}

function formatDurationSec(ms) {
  return `${msToSecondsValue(ms, 0)} sec`;
}

function rtuSerialLabel() {
  return state.connected && state.mode === "rtu" && state.port
    ? "Web Serial connected"
    : "Use Connect above";
}

function getBaseConfig() {
  return {
    mode: state.mode,
    unitId: readNumber(els.unitId, 1, 1, 247),
    timeoutMs: readSecondsAsMs(els.timeoutMs, 1000, 100, 10000),
    tcpHost: els.tcpHost.value.trim(),
    tcpPort: readNumber(els.tcpPort, 502, 1, 65535)
  };
}

function getReadConfig() {
  const base = getBaseConfig();
  const functionCode = Number.parseInt(els.readFunction.value, 10);
  const maxQuantity = functionCode === 1 || functionCode === 2 ? 2000 : 125;
  const type = normalizePointType(els.readType?.value);
  const minQuantity = functionCode === 1 || functionCode === 2 ? 1 : registersForType(type);
  const quantity = readNumber(els.readQuantity, minQuantity, minQuantity, maxQuantity);
  if (els.readQuantity) els.readQuantity.value = String(quantity);
  return {
    ...base,
    functionCode,
    startAddress: normalizeProbeAddress(readNumber(els.readAddress, 0, 0, 65535), functionCode),
    quantity,
    type,
    wordOrder: els.readWordOrder?.value === "swap" ? "swap" : "be"
  };
}

function parseAddressList(text) {
  const addresses = [];
  const seen = new Set();
  const parts = String(text || "")
    .split(/[,\s;]+/)
    .map((part) => part.trim())
    .filter(Boolean);

  for (const part of parts) {
    const range = part.match(/^(\d+)\s*-\s*(\d+)$/);
    const values = [];
    if (range) {
      const start = Number.parseInt(range[1], 10);
      const end = Number.parseInt(range[2], 10);
      if (Number.isNaN(start) || Number.isNaN(end)) continue;
      const step = start <= end ? 1 : -1;
      for (let value = start; step > 0 ? value <= end : value >= end; value += step) {
        values.push(value);
      }
    } else {
      const value = Number.parseInt(part, 10);
      if (!Number.isNaN(value)) values.push(value);
    }

    for (const value of values) {
      const address = Math.min(65535, Math.max(0, value));
      if (!seen.has(address)) {
        seen.add(address);
        addresses.push(address);
      }
      if (addresses.length >= 128) return addresses;
    }
  }

  return addresses.length ? addresses : [2];
}

function parseScanAddresses() {
  const text = String(els.scanAddress?.value || "").trim();
  return text ? parseAddressList(text) : [2];
}

function normalizeModbusReferenceAddress(value, functionCode) {
  const address = Number.parseInt(value, 10);
  if (!Number.isFinite(address)) return 0;
  if (functionCode === 3 && address >= 40001 && address <= 49999) return address - 40001;
  if (functionCode === 4 && address >= 30001 && address <= 39999) return address - 30001;
  if (functionCode === 2 && address >= 10001 && address <= 19999) return address - 10001;
  return Math.min(65535, Math.max(0, address));
}

function normalizeProbeAddress(value, functionCode) {
  const address = Number.parseInt(value, 10);
  if (!Number.isFinite(address)) return 0;
  return normalizeModbusReferenceAddress(address, functionCode);
}

function pointAddressMode(point, device) {
  if (point?.addressMode === "raw" || point?.addressMode === "reference") return point.addressMode;
  return "raw";
}

function pointRawAddress(point, device, functionCode = pointFunctionCode(point, device)) {
  const address = Number.parseInt(point?.address, 10);
  if (!Number.isFinite(address)) return 0;
  if (pointAddressMode(point, device) === "raw") {
    return Math.min(65535, Math.max(0, address));
  }
  return normalizeProbeAddress(address, functionCode);
}

function scanFunctionList(functionCode) {
  return functionCode === "all" ? [3, 4, 1, 2] : [functionCode];
}

function buildScanProbes(config) {
  const seen = new Set();
  const probes = [];
  for (const startAddress of config.addresses) {
    for (const functionCode of scanFunctionList(config.functionCode)) {
      const normalizedAddress = normalizeProbeAddress(startAddress, functionCode);
      const key = `${functionCode}-${normalizedAddress}`;
      if (seen.has(key)) continue;
      seen.add(key);
      probes.push({ startAddress: normalizedAddress, functionCode, sourceAddress: startAddress });
    }
  }
  return probes;
}

function tcpScanPorts(config) {
  const primaryPort = Number.parseInt(state.tcpTarget?.port || config.tcpPort || 502, 10) || 502;
  return [primaryPort];
}

function isExceptionResult(result) {
  return result?.status === "modbus_exception" || /^exception\s+\d+/i.test(String(result?.error || ""));
}

function isFoundScanResult(result) {
  return Boolean(result?.ok) || isExceptionResult(result);
}

function modbusExceptionText(error) {
  const code = String(error || "").match(/exception\s+(\d+)/i)?.[1];
  const labels = {
    1: "Illegal function",
    2: "Illegal address",
    3: "Illegal value",
    4: "Device failure",
    5: "Accepted",
    6: "Device busy"
  };
  return code ? `${labels[code] || "Modbus exception"} (${code})` : String(error || "");
}

function ipv4ToInt(ip) {
  const parts = String(ip || "").trim().split(".");
  if (parts.length !== 4) return null;
  let value = 0;
  for (const part of parts) {
    if (!/^\d{1,3}$/.test(part)) return null;
    const octet = Number.parseInt(part, 10);
    if (octet < 0 || octet > 255) return null;
    value = (value << 8) + octet;
  }
  return value >>> 0;
}

function intToIpv4(value) {
  return [
    (value >>> 24) & 255,
    (value >>> 16) & 255,
    (value >>> 8) & 255,
    value & 255
  ].join(".");
}

function deriveSubnetRange(host) {
  const parts = String(host || "").trim().split(".");
  if (parts.length !== 4 || parts.some((part) => !/^\d{1,3}$/.test(part))) {
    return "192.168.0.1-254";
  }
  const octets = parts.map((part) => Number.parseInt(part, 10));
  if (octets.some((octet) => octet < 0 || octet > 255)) {
    return "192.168.0.1-254";
  }
  return `${octets[0]}.${octets[1]}.${octets[2]}.1-254`;
}

function expandGatewayTargets(text, limit = 1024) {
  const targets = [];
  const seen = new Set();
  const addTarget = (target) => {
    const value = String(target || "").trim();
    if (!value || seen.has(value) || targets.length >= limit) return;
    seen.add(value);
    targets.push(value);
  };
  const tokens = String(text || "")
    .split(/[,\s;]+/)
    .map((token) => token.trim())
    .filter(Boolean);

  for (const token of tokens) {
    if (targets.length >= limit) break;
    const cidr = token.match(/^(\d{1,3}(?:\.\d{1,3}){3})\/(\d{1,2})$/);
    if (cidr) {
      const base = ipv4ToInt(cidr[1]);
      const prefix = Number.parseInt(cidr[2], 10);
      if (base === null || prefix < 0 || prefix > 32) continue;
      const size = 2 ** (32 - prefix);
      const mask = prefix === 0 ? 0 : (0xffffffff << (32 - prefix)) >>> 0;
      const network = (base & mask) >>> 0;
      const first = size > 2 ? network + 1 : network;
      const last = size > 2 ? network + size - 2 : network + size - 1;
      for (let value = first; value <= last && targets.length < limit; value += 1) {
        addTarget(intToIpv4(value >>> 0));
      }
      continue;
    }

    const range = token.match(/^(\d{1,3}(?:\.\d{1,3}){3})-(\d{1,3}(?:\.\d{1,3}){3}|\d{1,3})$/);
    if (range) {
      const start = ipv4ToInt(range[1]);
      let end = null;
      if (range[2].includes(".")) {
        end = ipv4ToInt(range[2]);
      } else {
        const prefix = range[1].split(".").slice(0, 3).join(".");
        end = ipv4ToInt(`${prefix}.${range[2]}`);
      }
      if (start === null || end === null) continue;
      const step = start <= end ? 1 : -1;
      for (let value = start; step > 0 ? value <= end : value >= end; value += step) {
        addTarget(intToIpv4(value >>> 0));
        if (targets.length >= limit) break;
      }
      continue;
    }

    addTarget(token);
  }

  return targets;
}

function getGatewayScanConfig() {
  const functionValue = els.scanFunction.value;
  const functionCode = functionValue === "all" ? 3 : Number.parseInt(functionValue, 10);
  const maxQuantity = functionCode === 1 || functionCode === 2 ? 2000 : 125;
  const probeIds = parseAddressList(els.gatewayProbeIds.value)
    .filter((id) => id >= 1 && id <= 247)
    .slice(0, 32);
  return {
    targets: expandGatewayTargets(els.gatewayRange.value),
    port: readNumber(els.gatewayPort, 502, 1, 65535),
    timeoutMs: readSecondsAsMs(els.timeoutMs, 1000, 100, 10000),
    unitIds: probeIds.length ? probeIds : [1],
    functionCode,
    startAddress: normalizeProbeAddress(parseScanAddresses(functionCode)[0] ?? 1, functionCode),
    quantity: readNumber(els.scanQuantity, 1, 1, maxQuantity),
    rangeText: els.gatewayRange.value.trim(),
    subnetText: els.networkSubnet.selectedOptions[0]?.dataset.cidr || "",
    interfaceText: selectedNetworkInterface()?.name || ""
  };
}

function getScanConfig() {
  const base = getBaseConfig();
  const from = readNumber(els.slaveFrom, 1, 1, 247);
  const to = readNumber(els.slaveTo, from, 1, 247);
  const functionValue = els.scanFunction.value;
  const functionCode = functionValue === "all" ? "all" : Number.parseInt(functionValue, 10);
  const maxQuantity = functionCode === 1 || functionCode === 2 ? 2000 : 125;
  return {
    ...base,
    from: Math.min(from, to),
    to: Math.max(from, to),
    functionCode,
    addresses: parseScanAddresses(functionCode),
    quantity: readNumber(els.scanQuantity, 1, 1, maxQuantity),
    stopOnFound: els.stopOnFound.checked,
    fastTimeoutSkip: els.fastTimeoutSkip.checked
  };
}

function getWriteConfig() {
  const functionCode = Number.parseInt(els.writeFunction.value, 10);
  const addressFunction = functionCode === 6 || functionCode === 16 ? 3 : functionCode === 5 || functionCode === 15 ? 1 : 3;
  return {
    ...getBaseConfig(),
    functionCode,
    address: normalizeProbeAddress(readNumber(els.writeAddress, 0, 0, 65535), addressFunction),
    values: parseWriteValues(els.writeValue.value)
  };
}

function parseWriteValues(text) {
  const values = text
    .split(/[,\s]+/)
    .map((item) => item.trim())
    .filter(Boolean)
    .map((item) => Number(item));

  if (values.some((value) => !Number.isInteger(value))) {
    throw new Error("Raw register values must be whole numbers.");
  }
  if (values.length === 0) {
    throw new Error("Write value is required.");
  }
  if (values.some((value) => value < -32768 || value > 65535)) {
    throw new Error("Raw register values must be between -32768 and 65535.");
  }
  return values.map((value) => (value < 0 ? 0x10000 + value : value));
}

function updateStats() {
  const devices = new Set(state.results.filter(isFoundScanResult).map((row) => `${row.port || ""}-${row.slaveId}`));
  els.devicesCount.textContent = String(devices.size);
  els.requestsCount.textContent = String(state.requests);
  els.errorsCount.textContent = String(state.errors);
  els.exportBtn.disabled = state.results.length === 0;
  els.importScanBtn.disabled = devices.size === 0;
  if (state.activeTab === "scan") renderFoundDevices();
  if (state.activeTab === "register") renderRegisterMap();
}

function updateScanProgress(done, total, unitId = null) {
  const percent = total > 0 ? Math.round((done / total) * 100) : 0;
  els.scanProgressPercent.textContent = `${percent}%`;
  els.scanProgressBar.style.width = `${percent}%`;
  els.scanProgressText.textContent = unitId === null
    ? "Scan progress"
    : `Scanning ID ${unitId} (${done}/${total})`;
}

function resetScanProgress() {
  updateScanProgress(0, 1);
  els.scanProgressText.textContent = "Scan progress";
}

function updateGatewayProgress(done, total) {
  const percent = total > 0 ? Math.round((done / total) * 100) : 0;
  const scanLabel = state.activeGatewayScan?.subnetText || state.activeGatewayScan?.rangeText || "";
  els.gatewayProgressPercent.textContent = `${percent}%`;
  els.gatewayProgressBar.style.width = `${percent}%`;
  els.gatewayProgressText.textContent = done === 0
    ? "Gateway scan progress"
    : `Scanning ${scanLabel || "gateway"} ${done}/${total}`;
}

function resetGatewayProgress() {
  updateGatewayProgress(0, 1);
  els.gatewayProgressText.textContent = "Gateway scan progress";
}

function scheduleGatewayResultsRender() {
  if (gatewayResultsRenderTimer !== null) return;
  gatewayResultsRenderTimer = window.setTimeout(() => {
    gatewayResultsRenderTimer = null;
    renderGatewayResults();
  }, SCAN_RENDER_INTERVAL_MS);
}

function flushGatewayResultsRender() {
  if (gatewayResultsRenderTimer !== null) {
    window.clearTimeout(gatewayResultsRenderTimer);
    gatewayResultsRenderTimer = null;
  }
  renderGatewayResults();
}

function clearGatewayScanResultsForSubnetChange() {
  if (state.gatewayScanning) return;
  state.gatewayResults = [];
  state.gatewayScanStarted = false;
  state.activeGatewayScan = null;
  resetGatewayProgress();
  flushGatewayResultsRender();
}

function setGatewayScanControlsBusy(scanning) {
  els.gatewayScanBtn.disabled = scanning;
  els.gatewayStopBtn.disabled = !scanning;
  els.networkInterface.disabled = scanning;
  els.networkSubnet.disabled = scanning;
  els.gatewayRange.disabled = scanning;
  els.gatewayPort.disabled = scanning;
  els.gatewayProbeIds.disabled = scanning;
  els.gatewayAutoNetworkBtn.disabled = scanning;
  els.networkRefreshBtn.disabled = scanning;
  els.gatewaySubnetBtn.disabled = scanning;
  updateGatewayModalBadge();
}

function renderGatewayResults() {
  els.gatewayResults.innerHTML = "";
  const candidates = state.gatewayResults.filter((result) => result.modbusOk || result.tcpOpen);
  const modbusCount = candidates.filter((result) => result.modbusOk).length;
  const openCount = candidates.filter((result) => result.tcpOpen).length;
  updateGatewayModalBadge();
  els.gatewaySummary.textContent = candidates.length
    ? `${modbusCount} Modbus OK, ${openCount} TCP open`
    : state.gatewayScanning ? "Scanning... no gateway found yet" : state.gatewayScanStarted ? "No gateway found" : "No gateway scan yet";

  if (candidates.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-found";
    empty.textContent = state.gatewayScanning
      ? "Scanning subnet. Only Modbus OK or TCP open gateways will appear here."
      : state.gatewayScanStarted
        ? "No gateway found in the last scan."
        : "Scan a subnet to discover Modbus TCP gateways.";
    els.gatewayResults.append(empty);
    return;
  }

  const sorted = [...candidates].sort((a, b) => {
    const rank = (item) => (item.modbusOk ? 0 : item.tcpOpen ? 1 : 2);
    return rank(a) - rank(b) || a.host.localeCompare(b.host, undefined, { numeric: true });
  });

  for (const result of sorted) {
    const status = result.modbusOk ? "ok" : "warn";
    const label = result.modbusOk
      ? result.status === "modbus_exception" ? "Modbus exception reply" : "Modbus OK"
      : "TCP open";
    const card = document.createElement("button");
    card.type = "button";
    card.className = "gateway-card-btn";
    card.dataset.gatewayHost = result.host;
    card.dataset.gatewayPort = result.port;
    const selectedGateway = state.selectedGateway
      || (els.tcpHost.value.trim() ? { host: els.tcpHost.value.trim(), port: readNumber(els.tcpPort, 502, 1, 65535) } : null);
    if (selectedGateway && selectedGateway.host === result.host && Number.parseInt(selectedGateway.port, 10) === Number.parseInt(result.port, 10)) {
      card.classList.add("is-selected");
    }
    card.innerHTML = `
      <span class="gateway-host">${escapeHtml(result.host)}:${result.port}</span>
      <strong><span class="status-pill ${status}">${label}</span></strong>
      <span>${result.unitId ? `ID ${result.unitId}, ${READ_FUNCTIONS[result.functionCode]}` : "Click to use as target"}</span>
      <span>${result.latencyMs ? formatDurationSec(result.latencyMs) : shortError(result.error || "")}</span>
    `;
    els.gatewayResults.append(card);
  }
}

function clearResults() {
  state.results = [];
  state.requests = 0;
  state.errors = 0;
  flushScanResultsRender();
  els.scanState.textContent = "Ready";
}

function scheduleScanResultsRender() {
  if (scanResultsRenderTimer !== null) return;
  scanResultsRenderTimer = window.setTimeout(() => {
    scanResultsRenderTimer = null;
    renderScanResults();
    updateStats();
  }, SCAN_RENDER_INTERVAL_MS);
}

function flushScanResultsRender() {
  if (scanResultsRenderTimer !== null) {
    window.clearTimeout(scanResultsRenderTimer);
    scanResultsRenderTimer = null;
  }
  renderScanResults();
  updateStats();
}

function renderScanResults() {
  els.resultsBody.innerHTML = "";
  const query = String(state.scanSearchQuery || "").trim().toLowerCase();
  const filtered = query
    ? state.results.filter((result) => {
        const exceptionReply = isExceptionResult(result);
        const found = isFoundScanResult(result);
        const statusText = exceptionReply ? "Reply" : found ? "Online" : "Offline";
        const fnText = READ_FUNCTIONS[result.functionCode] || "";
        const valText = result.values?.length ? result.values.join(", ") : exceptionReply ? modbusExceptionText(result.error) : result.error || "";
        const haystack = `${result.slaveId} ${statusText} ${fnText} ${result.startAddress} ${valText}`.toLowerCase();
        return haystack.includes(query);
      })
    : state.results;

  if (filtered.length === 0) {
    const row = document.createElement("tr");
    row.className = "empty-row";
    row.innerHTML = `<td colspan="7">${state.results.length === 0 ? "Waiting for device scan results..." : "No matching scan results."}</td>`;
    els.resultsBody.append(row);
    return;
  }

  filtered.forEach((result, index) => {
    const row = document.createElement("tr");
    const exceptionReply = isExceptionResult(result);
    const found = isFoundScanResult(result);
    const status = found ? "ok" : "fail";
    const statusText = exceptionReply ? "Reply" : found ? "Online" : "Offline";
    const valueText = result.values?.length ? result.values.join(", ") : exceptionReply ? modbusExceptionText(result.error) : result.error;
    row.innerHTML = `
      <td>${index + 1}</td>
      <td><span class="status-pill ${status}">${statusText}</span></td>
      <td>${result.slaveId}</td>
      <td>${READ_FUNCTIONS[result.functionCode]}</td>
      <td>${result.startAddress}${result.port ? `:${result.port}` : ""}</td>
      <td class="values"></td>
      <td>${formatDurationSec(result.latencyMs)}</td>
    `;
    row.querySelector(".values").textContent = valueText;
    els.resultsBody.append(row);
  });
}

function renderFoundDevices() {
  const devices = Array.from(
    state.results
      .filter(isFoundScanResult)
      .reduce((map, row) => {
        const key = `${row.port || ""}-${row.slaveId}`;
        if (!map.has(key)) {
          map.set(key, {
            slaveId: row.slaveId,
            port: row.port,
            functions: new Map(),
            bestLatencyMs: row.latencyMs,
            primary: row
          });
        }
        const device = map.get(key);
        device.bestLatencyMs = Math.min(device.bestLatencyMs, row.latencyMs);
        if (!device.functions.has(row.functionCode)) {
          device.functions.set(row.functionCode, row);
        }
        if (row.functionCode === 3 || device.primary.functionCode !== 3) {
          device.primary = row;
        }
        return map;
      }, new Map())
      .values()
  ).sort((a, b) => a.slaveId - b.slaveId);

  els.foundSummary.textContent = devices.length
    ? `${devices.length} device(s) found`
    : "No devices found yet";
  els.foundDeviceWrap?.classList.toggle("hidden", devices.length === 0);
  els.foundDevices.innerHTML = "";

  if (devices.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-found";
    empty.textContent = "Scan to discover live Modbus devices.";
    els.foundDevices.append(empty);
    return;
  }

  for (const device of devices) {
    const primary = device.primary;
    const functionLabels = Array.from(device.functions.keys())
      .sort((a, b) => a - b)
      .map((functionCode) => `<span class="found-function">${READ_FUNCTIONS[functionCode].slice(0, 2)}</span>`)
      .join("");
    const card = document.createElement("button");
    card.type = "button";
    card.className = "found-card";
    card.innerHTML = `
      <span class="found-unit">ID ${device.slaveId}</span>
      <strong>${READ_FUNCTIONS[primary.functionCode]}</strong>
      <span>${device.port ? `Port ${device.port} / ` : ""}Address ${primary.startAddress}</span>
      <span>${formatDurationSec(device.bestLatencyMs)} best reply</span>
      <span class="found-functions">${functionLabels}</span>
    `;
    card.addEventListener("click", () => {
      els.unitId.value = device.slaveId;
      els.readFunction.value = String(primary.functionCode);
      els.readAddress.value = primary.startAddress;
      els.readQuantity.value = Math.max(1, primary.values.length);
      setActiveTab("poll");
      log(`Loaded ID ${device.slaveId}, ${READ_FUNCTIONS[primary.functionCode]} into Read Function.`);
    });
    els.foundDevices.append(card);
  }
}

function functionFamilyLabel(functionCode) {
  if (functionCode === 1) return "Coils";
  if (functionCode === 2) return "Discrete inputs";
  if (functionCode === 3) return "Holding registers";
  if (functionCode === 4) return "Input registers";
  return READ_FUNCTIONS[functionCode] || `Function ${functionCode}`;
}

function pointAddressRange(point, device) {
  const functionCode = pointFunctionCode(point, device);
  const width = functionCode === 1 || functionCode === 2 ? 1 : registersForType(point.type);
  const start = Number.parseInt(point.address, 10) || 0;
  const end = start + width - 1;
  return end === start ? String(start) : `${start}-${end}`;
}

function registerRowsFromDevices() {
  const rows = [];
  for (const device of state.devices) {
    for (const point of device.points) {
      const functionCode = pointFunctionCode(point, device);
      rows.push({
        device: device.name,
        id: device.id,
        functionText: functionFamilyLabel(functionCode),
        addressRange: pointAddressRange(point, device),
        point: point.name,
        type: functionCode === 1 || functionCode === 2 ? "bit" : pointTypeLabel(point),
        value: formatPointValue(point),
        control: isWritablePoint(point, device) ? "Control" : "-"
      });
    }
  }
  return rows;
}

function registerRowsFromScanResults() {
  return state.results
    .filter(isFoundScanResult)
    .map((result) => ({
      device: `Scanned ID ${result.slaveId}${result.port ? `:${result.port}` : ""}`,
      id: result.port ? `${result.port}-${result.slaveId}` : result.slaveId,
      functionText: functionFamilyLabel(result.functionCode),
      addressRange: result.values.length > 1
        ? `${result.startAddress}-${result.startAddress + result.values.length - 1}`
        : String(result.startAddress),
      point: "Scan result",
      type: result.functionCode === 1 || result.functionCode === 2 ? "bit" : "uint16",
      value: result.values?.length ? result.values.join(", ") : result.error,
      control: result.functionCode === 1 || result.functionCode === 3 ? "Possible" : "-"
    }));
}

function renderRegisterMap() {
  if (!els.registerMapBody) return;
  const deviceRows = registerRowsFromDevices();
  const scanRows = deviceRows.length ? [] : registerRowsFromScanResults();
  const rows = deviceRows.length ? deviceRows : scanRows;
  const deviceCount = deviceRows.length
    ? new Set(state.devices.map((device) => device.uid)).size
    : new Set(scanRows.map((row) => row.id)).size;
  const rangeCount = new Set(rows.map((row) => `${row.id}-${row.functionText}-${row.addressRange}`)).size;

  els.registerDeviceCount.textContent = String(deviceCount);
  els.registerPointCount.textContent = String(rows.length);
  els.registerRangeCount.textContent = String(rangeCount);
  els.registerSummary.textContent = rows.length
    ? deviceRows.length
      ? `${rows.length} point(s) from Device Monitor`
      : `${rows.length} scan result range(s)`
    : "No point map yet";

  els.registerMapBody.innerHTML = "";
  if (rows.length === 0) {
    els.registerMapBody.innerHTML = `
      <tr class="empty-row">
        <td colspan="8">Add devices or import scan results to build the register map.</td>
      </tr>
    `;
    return;
  }

  for (const rowData of rows) {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${escapeHtml(rowData.device)}</td>
      <td>${escapeHtml(rowData.id)}</td>
      <td>${escapeHtml(rowData.functionText)}</td>
      <td>${escapeHtml(rowData.addressRange)}</td>
      <td>${escapeHtml(rowData.point)}</td>
      <td>${escapeHtml(rowData.type)}</td>
      <td>${escapeHtml(rowData.value)}</td>
      <td>${escapeHtml(rowData.control)}</td>
    `;
    els.registerMapBody.append(row);
  }
}

function clonePoints(points) {
  return points.map((point) => ({
    name: point.name,
    address: point.address,
    addressMode: point.addressMode || null,
    functionCode: point.functionCode ? Number.parseInt(point.functionCode, 10) : null,
    type: normalizePointType(point.type),
    wordOrder: point.wordOrder === "swap" ? "swap" : "be",
    scale: point.scale ?? 1,
    unit: point.unit ?? "",
    controlEnabled: normalizeControlEnabled(point.controlEnabled),
    controlValue: String(point.controlValue ?? ""),
    raw: null,
    value: null
  }));
}

function readFloat(input, fallback, min, max) {
  if (!input) return fallback;
  const value = Number.parseFloat(input.value);
  if (Number.isNaN(value)) return fallback;
  return Math.min(max, Math.max(min, value));
}

function normalizePointType(type) {
  return POINT_TYPES[type] ? type : "uint16";
}

function registersForType(type) {
  return POINT_TYPES[normalizePointType(type)].registers;
}

function pointTypeLabel(point) {
  return POINT_TYPES[normalizePointType(point.type)].label;
}

function orderedWords(words, wordOrder) {
  const cleanWords = words.map((word) => Number(word) & 0xffff);
  return wordOrder === "swap" ? cleanWords.reverse() : cleanWords;
}

function unsignedFromWords(words, wordOrder) {
  return orderedWords(words, wordOrder).reduce(
    (value, word) => (value << 16n) | BigInt(word),
    0n
  );
}

function signedFromUnsigned(value, bitCount) {
  const signBit = 1n << BigInt(bitCount - 1);
  const fullRange = 1n << BigInt(bitCount);
  return (value & signBit) ? value - fullRange : value;
}

function numberFromWords(words, wordOrder, getter) {
  const ordered = orderedWords(words, wordOrder);
  const buffer = new ArrayBuffer(ordered.length * 2);
  const view = new DataView(buffer);
  ordered.forEach((word, index) => {
    view.setUint16(index * 2, word, false);
  });
  return getter(view);
}

function pointWriteInputStep(point) {
  const type = normalizePointType(point?.type);
  return type === "float32" || type === "float64" ? "any" : "1";
}

function pointWriteWords(point, text) {
  const valueText = String(text ?? "").trim();
  if (!valueText) throw new Error("Write value is required.");

  const engineeringValue = Number(valueText);
  if (!Number.isFinite(engineeringValue)) {
    throw new Error("Write value must be a finite number.");
  }

  const scale = Number(point?.scale ?? 1);
  if (!Number.isFinite(scale) || scale === 0) {
    throw new Error("Point scale must be a non-zero number before writing.");
  }

  const rawValue = engineeringValue / scale;
  const type = normalizePointType(point?.type);
  const buffer = new ArrayBuffer(registersForType(type) * 2);
  const view = new DataView(buffer);

  if (type === "uint16") {
    if (!Number.isInteger(rawValue) || rawValue < 0 || rawValue > 0xffff) {
      throw new Error("uint16 value must resolve to a whole number between 0 and 65535.");
    }
    view.setUint16(0, rawValue, false);
  } else if (type === "int16") {
    if (!Number.isInteger(rawValue) || rawValue < -0x8000 || rawValue > 0x7fff) {
      throw new Error("int16 value must resolve to a whole number between -32768 and 32767.");
    }
    view.setInt16(0, rawValue, false);
  } else if (type === "uint32") {
    if (!Number.isInteger(rawValue) || rawValue < 0 || rawValue > 0xffffffff) {
      throw new Error("uint32 value must resolve to a whole number between 0 and 4294967295.");
    }
    view.setUint32(0, rawValue, false);
  } else if (type === "int32") {
    if (!Number.isInteger(rawValue) || rawValue < -0x80000000 || rawValue > 0x7fffffff) {
      throw new Error("int32 value is outside the supported range.");
    }
    view.setInt32(0, rawValue, false);
  } else if (type === "float32") {
    view.setFloat32(0, rawValue, false);
  } else if (type === "float64") {
    view.setFloat64(0, rawValue, false);
  } else if (type === "uint64" || type === "int64") {
    if (!Number.isSafeInteger(rawValue)) {
      throw new Error(`${type} value must resolve to a safe whole number.`);
    }
    const bigValue = BigInt(rawValue);
    if (type === "uint64") {
      if (bigValue < 0n) throw new Error("uint64 value cannot be negative.");
      view.setBigUint64(0, bigValue, false);
    } else {
      view.setBigInt64(0, bigValue, false);
    }
  }

  const words = [];
  for (let offset = 0; offset < buffer.byteLength; offset += 2) {
    words.push(view.getUint16(offset, false));
  }
  return point?.wordOrder === "swap" ? words.reverse() : words;
}

function formatDataValue(value) {
  if (value === null || value === undefined) return "-";
  if (typeof value === "bigint") return value.toString();
  if (!Number.isFinite(value)) return String(value);
  if (Number.isInteger(value)) return String(value);
  return Number.parseFloat(value.toFixed(6)).toString();
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function scaleRawValue(raw, scale) {
  const factor = scale ?? 1;
  if (raw === null || raw === undefined) return null;
  if (factor === 1) return raw;
  if (typeof raw === "bigint") {
    const maxSafe = BigInt(Number.MAX_SAFE_INTEGER);
    const minSafe = -maxSafe;
    if (raw > maxSafe || raw < minSafe) return null;
    return Number(raw) * factor;
  }
  return raw * factor;
}

function decodePointValue(point, values, startAddress, functionCode) {
  const offset = point.address - startAddress;
  if (offset < 0 || offset >= values.length) {
    return { raw: null, value: null };
  }

  if (functionCode === 1 || functionCode === 2) {
    const raw = values[offset] ?? null;
    return { raw, value: scaleRawValue(raw, point.scale) };
  }

  const type = normalizePointType(point.type);
  const required = registersForType(type);
  const words = values.slice(offset, offset + required);
  if (words.length < required || words.some((word) => word === undefined || word === null)) {
    return { raw: null, value: null };
  }

  let raw;
  if (type === "uint16") {
    raw = Number(words[0]) & 0xffff;
  } else if (type === "int16") {
    const unsigned = Number(words[0]) & 0xffff;
    raw = unsigned > 0x7fff ? unsigned - 0x10000 : unsigned;
  } else if (type === "float32") {
    raw = numberFromWords(words, point.wordOrder, (view) => view.getFloat32(0, false));
  } else if (type === "float64") {
    raw = numberFromWords(words, point.wordOrder, (view) => view.getFloat64(0, false));
  } else {
    const unsigned = unsignedFromWords(words, point.wordOrder);
    if (type === "uint32") {
      raw = Number(unsigned);
    } else if (type === "int32") {
      raw = Number(signedFromUnsigned(unsigned, 32));
    } else if (type === "uint64") {
      raw = unsigned;
    } else if (type === "int64") {
      raw = signedFromUnsigned(unsigned, 64);
    }
  }

  return { raw, value: scaleRawValue(raw, point.scale) };
}

function formatPointValue(point) {
  if (point.raw === null || point.raw === undefined) return "-";
  if (point.value === null || point.value === undefined) {
    return `${formatDataValue(point.raw)}${point.scale && point.scale !== 1 ? ` x ${point.scale}` : ""}${point.unit ? ` ${point.unit}` : ""}`;
  }
  return `${formatDataValue(point.value)}${point.unit ? ` ${point.unit}` : ""}`;
}

function pointCovValue(point) {
  const value = point.value ?? point.raw;
  if (value === null || value === undefined) return "";
  return typeof value === "bigint" ? value.toString() : String(value);
}

function captureDeviceCovValues(device) {
  return device.points.map((point) => pointCovValue(point));
}

function covValueChanged(previousValue, nextValue, deadband) {
  if (previousValue === nextValue) return false;
  const previousNumber = Number(previousValue);
  const nextNumber = Number(nextValue);
  if (Number.isFinite(previousNumber) && Number.isFinite(nextNumber)) {
    return Math.abs(nextNumber - previousNumber) > deadband;
  }
  return String(previousValue) !== String(nextValue);
}

function deviceCovChanged(previousValues, device) {
  const deadband = readFloat(els.covDeadband, 0, 0, 1000000);
  return device.points.some((point, index) =>
    covValueChanged(previousValues[index] ?? "", pointCovValue(point), deadband)
  );
}

function clampNumber(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function normalizeDeviceCardSpan(value) {
  const span = Number.parseInt(value ?? DEVICE_CARD_DEFAULT_SPAN, 10);
  if (Number.isNaN(span)) return DEVICE_CARD_DEFAULT_SPAN;
  return clampNumber(span, DEVICE_CARD_MIN_SPAN, DEVICE_CARD_MAX_SPAN);
}

function normalizeDeviceCardHeight(value) {
  const height = Number.parseInt(value ?? DEVICE_CARD_DEFAULT_HEIGHT, 10);
  if (Number.isNaN(height)) return DEVICE_CARD_DEFAULT_HEIGHT;
  const snapped = Math.round(height / DEVICE_CARD_HEIGHT_STEP) * DEVICE_CARD_HEIGHT_STEP;
  return clampNumber(snapped, DEVICE_CARD_MIN_HEIGHT, DEVICE_CARD_MAX_HEIGHT);
}

function deviceCardRowSpan(height) {
  const targetHeight = normalizeDeviceCardHeight(height);
  return Math.max(1, Math.ceil((targetHeight + DEVICE_CARD_GRID_GAP) / (DEVICE_CARD_HEIGHT_STEP + DEVICE_CARD_GRID_GAP)));
}

function isManualDeviceLayout(device) {
  return String(device.layoutMode || "").toLowerCase() === "manual";
}

function isManualDeviceHeight(device) {
  return String(device.heightMode || "").toLowerCase() === "manual";
}

function autoDeviceCardSpan(deviceCount) {
  if (deviceCount <= 1) return DEVICE_CARD_MAX_SPAN;
  if (deviceCount <= 2) return 6;
  if (deviceCount <= 6) return 4;
  return 3;
}

function autoDeviceCardHeight(device) {
  const pointCount = Array.isArray(device.points) ? device.points.length : 0;
  const visibleRows = Math.max(3, Math.min(pointCount || 1, DEVICE_CARD_AUTO_MAX_VISIBLE_POINTS));
  const editExtra = device.editingName ? DEVICE_CARD_AUTO_EDIT_EXTRA_HEIGHT : 0;
  return normalizeDeviceCardHeight(
    DEVICE_CARD_AUTO_HEADER_HEIGHT + editExtra + (visibleRows * DEVICE_CARD_AUTO_POINT_ROW_HEIGHT)
  );
}

function resolveDeviceCardLayout(device, deviceCount) {
  return {
    span: 1,
    height: isManualDeviceHeight(device)
      ? normalizeDeviceCardHeight(device.cardHeight)
      : autoDeviceCardHeight(device)
  };
}

function makeDevice({
  id,
  templateKey,
  name = "",
  functionCode = null,
  points = null,
  cardSpan = DEVICE_CARD_DEFAULT_SPAN,
  cardHeight = DEVICE_CARD_DEFAULT_HEIGHT,
  layoutMode = "auto",
  heightMode = "auto"
}) {
  const template = DEVICE_TEMPLATES[templateKey] || DEVICE_TEMPLATES.generic;
  const deviceFunction = functionCode || template.functionCode;
  const devicePoints = points || template.points;
  return {
    uid: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    id,
    name: name || template.name(id),
    templateKey,
    functionCode: deviceFunction,
    tcpHost: els.tcpHost.value.trim(),
    tcpPort: readNumber(els.tcpPort, 502, 1, 65535),
    intervalMs: readSecondsAsMs(els.deviceInterval, 1000, 500, 60000),
    cardSpan: normalizeDeviceCardSpan(cardSpan),
    cardHeight: normalizeDeviceCardHeight(cardHeight),
    layoutMode: layoutMode === "manual" ? "manual" : "auto",
    heightMode: heightMode === "manual" ? "manual" : "auto",
    points: clonePoints(devicePoints),
    editingName: false,
    lastLatencyMs: null,
    lastReadAt: null,
    lastError: ""
  };
}

function renderCustomPoints() {
  if (els.deviceTemplate.value !== "custom") {
    els.customPointSummary.textContent = "Press Add Device to use this point";
    els.customPointList.innerHTML = "";
    return;
  }

  els.customPointSummary.textContent = state.customPoints.length
    ? `${state.customPoints.length} custom point(s)`
    : "No custom points";
  els.customPointList.innerHTML = "";

  if (state.customPoints.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-found";
    empty.textContent = "Add point name and address before creating the device.";
    els.customPointList.append(empty);
    return;
  }

  for (const [index, point] of state.customPoints.entries()) {
    const controlAvailable = pointControlAvailable(point, {
      functionCode: Number.parseInt(els.deviceFunction.value, 10)
    });
    const item = document.createElement("div");
    item.className = "point-draft-item";
    item.draggable = true;
    item.dataset.pointIndex = String(index);
    item.innerHTML = `
      <span class="drag-handle" aria-hidden="true">::</span>
      <strong>${point.name}</strong>
      <span>Address ${point.address}</span>
      <span>${pointTypeLabel(point)}</span>
      <span>${point.wordOrder === "swap" ? "CDAB / GHEFCDAB" : "ABCD / ABCDEFGH"}</span>
      <span>Scale ${point.scale}</span>
      <span>${point.unit || "No unit"}</span>
      <label class="point-draft-control" title="${controlAvailable ? "Allow writes to this point" : "Control requires Coils or Holding registers"}">
        <input type="checkbox" data-custom-control="${index}" ${point.controlEnabled && controlAvailable ? "checked" : ""} ${controlAvailable ? "" : "disabled"} />
        <span>Control</span>
      </label>
      <button class="secondary-btn compact" type="button" data-icon="close" data-remove-point="${index}">Remove</button>
    `;
    els.customPointList.append(item);
  }
}

function moveCustomPoint(fromIndex, toIndex) {
  if (fromIndex === toIndex) return;
  if (fromIndex < 0 || toIndex < 0) return;
  if (fromIndex >= state.customPoints.length || toIndex >= state.customPoints.length) return;
  const [point] = state.customPoints.splice(fromIndex, 1);
  state.customPoints.splice(toIndex, 0, point);
  state.draggedPointIndex = null;
  renumberDefaultCustomPoints();
  renderCustomPoints();
}

function moveDevice(fromIndex, toIndex) {
  if (fromIndex === toIndex) return;
  if (fromIndex < 0 || toIndex < 0) return;
  if (fromIndex >= state.devices.length || toIndex >= state.devices.length) return;
  const [device] = state.devices.splice(fromIndex, 1);
  state.devices.splice(toIndex, 0, device);
  state.draggedDeviceIndex = null;
  renderDevices();
  log(`Moved ${device.name} to position ${toIndex + 1}.`);
}

function resetCustomPointDraftName() {
  els.pointName.value = `Point ${state.customPoints.length + 1}`;
}

function renumberDefaultCustomPoints() {
  state.customPoints.forEach((point, index) => {
    if (/^Point \d+$/i.test(point.name)) {
      point.name = `Point ${index + 1}`;
    }
  });
  resetCustomPointDraftName();
}

function addCustomPoint() {
  const point = readPointDraft(`Point ${state.customPoints.length + 1}`);
  const { name, address, type } = point;
  const duplicate = state.customPoints.some((point) => point.address === address && point.name === name);
  if (duplicate) {
    log("Custom point already exists.");
    return;
  }
  state.customPoints.push(point);
  renumberDefaultCustomPoints();
  els.pointAddress.value = address + registersForType(type);
  renderCustomPoints();
}

function readPointDraft(defaultName = "Value") {
  return {
    name: els.pointName.value.trim() || defaultName,
    address: readNumber(els.pointAddress, 0, 0, 65535),
    addressMode: "raw",
    type: normalizePointType(els.pointType.value),
    wordOrder: els.pointWordOrder.value === "swap" ? "swap" : "be",
    scale: readFloat(els.pointScale, 1, -1000000, 1000000),
    unit: els.pointUnit.value.trim(),
    controlEnabled: false,
    controlValue: ""
  };
}

function pointFunctionCode(point, device) {
  return Number.parseInt(point.functionCode || device.functionCode || 3, 10);
}

function functionOptions(selectedFunction) {
  const selected = Number.parseInt(selectedFunction || 3, 10);
  return Object.entries(READ_FUNCTIONS).map(([value, label]) =>
    `<option value="${value}" ${Number.parseInt(value, 10) === selected ? "selected" : ""}>${escapeHtml(label)}</option>`
  ).join("");
}

function normalizeControlEnabled(value) {
  if (typeof value === "boolean") return value;
  const text = String(value ?? "").trim().toLowerCase();
  return ["1", "true", "yes", "y", "on", "control"].includes(text);
}

function makePoint({
  name = "Value",
  address = 0,
  functionCode = null,
  type = "uint16",
  wordOrder = "be",
  scale = 1,
  unit = "",
  controlEnabled = false,
  controlValue = "",
  addressMode = null
}) {
  return {
    name,
    address,
    addressMode: addressMode === "raw" || addressMode === "reference" ? addressMode : null,
    functionCode: functionCode ? Number.parseInt(functionCode, 10) : null,
    type: normalizePointType(type),
    wordOrder: wordOrder === "swap" ? "swap" : "be",
    scale: Number.isFinite(Number(scale)) ? Number(scale) : 1,
    unit,
    controlEnabled: normalizeControlEnabled(controlEnabled),
    controlValue: String(controlValue ?? ""),
    writeStatus: null,
    raw: null,
    value: null
  };
}

function readDevicePointForm(scope, prefix) {
  const controlInput = scope.querySelector(`[data-field="${prefix}-control-value"]`);
  return makePoint({
    name: scope.querySelector(`[data-field="${prefix}-name"]`)?.value.trim() || "Value",
    address: readNumber(scope.querySelector(`[data-field="${prefix}-address"]`), 0, 0, 65535),
    addressMode: "raw",
    functionCode: Number.parseInt(scope.querySelector(`[data-field="${prefix}-function"]`)?.value || "3", 10),
    type: scope.querySelector(`[data-field="${prefix}-type"]`)?.value || "uint16",
    wordOrder: scope.querySelector(`[data-field="${prefix}-word-order"]`)?.value || "be",
    scale: readFloat(scope.querySelector(`[data-field="${prefix}-scale"]`), 1, -1000000, 1000000),
    unit: scope.querySelector(`[data-field="${prefix}-unit"]`)?.value.trim() || "",
    controlEnabled: scope.querySelector(`[data-field="${prefix}-control-enabled"]`)?.checked || false,
    controlValue: controlInput?.value.trim() || ""
  });
}

function pointTypeOptions(selectedType) {
  return Object.entries(POINT_TYPES).map(([value, meta]) =>
    `<option value="${value}" ${normalizePointType(selectedType) === value ? "selected" : ""}>${escapeHtml(meta.label)}</option>`
  ).join("");
}

function wordOrderOptions(selectedOrder) {
  const order = selectedOrder === "swap" ? "swap" : "be";
  return `
    <option value="be" ${order === "be" ? "selected" : ""}>ABCD / ABCDEFGH</option>
    <option value="swap" ${order === "swap" ? "selected" : ""}>CDAB / GHEFCDAB</option>
  `;
}

function writableFunctionCode(point, device) {
  const functionCode = pointFunctionCode(point, device);
  if (functionCode === 1) return 5;
  if (functionCode === 3) return registersForType(point.type) > 1 ? 16 : 6;
  return null;
}

function pointControlEnabled(point, device) {
  return !!point.controlEnabled && pointControlAvailable(point, device);
}

function isWritablePoint(point, device) {
  return writableFunctionCode(point, device) !== null;
}

function pointControlAvailable(point, device) {
  return isWritablePoint(point, device);
}

function pointReadSpan(point, device, functionCode) {
  const registerCount = functionCode === 1 || functionCode === 2 ? 1 : registersForType(point.type);
  const start = pointRawAddress(point, device, functionCode);
  return {
    point,
    start,
    end: Math.min(65535, start + registerCount - 1)
  };
}

function buildPointReadBlocks(points, device, functionCode) {
  const maxQuantity = functionCode === 1 || functionCode === 2 ? 2000 : 125;
  const spans = points
    .map((point) => pointReadSpan(point, device, functionCode))
    .sort((a, b) => a.start - b.start || a.end - b.end);
  const blocks = [];
  for (const span of spans) {
    const current = blocks[blocks.length - 1];
    if (!current || Math.max(current.end, span.end) - current.start + 1 > maxQuantity) {
      blocks.push({ start: span.start, end: span.end, spans: [span] });
      continue;
    }
    current.end = Math.max(current.end, span.end);
    current.spans.push(span);
  }
  return blocks;
}

function readPointControlValue(row, point, device, forcedValue = null) {
  const functionCode = writableFunctionCode(point, device);
  const rawValue = forcedValue ?? row?.querySelector("[data-control-value]")?.value ?? point.controlValue ?? "";
  if (functionCode === 5) {
    const values = parseWriteValues(String(rawValue));
    return [values[0] ? 1 : 0];
  }
  return pointWriteWords(point, rawValue);
}

function nextDevicePointAddress(device) {
  if (device.points.length === 0) return 0;
  const lastEnd = Math.max(...device.points.map((point) =>
    point.address + (device.functionCode === 1 || device.functionCode === 2 ? 1 : registersForType(point.type)) - 1
  ));
  return Math.min(65535, lastEnd + 1);
}

function addDevice(device) {
  const duplicate = state.devices.some((item) =>
    item.id === device.id
    && item.functionCode === device.functionCode
    && item.name === device.name
    && Number.parseInt(item.tcpPort || 502, 10) === Number.parseInt(device.tcpPort || 502, 10)
  );
  if (duplicate) return false;
  state.devices.push(device);
  renderDevices();
  return true;
}

function getDeviceBaseConfig(device) {
  const base = getBaseConfig();
  const tcpHost = String(device.tcpHost || "").trim() || base.tcpHost;
  const tcpPort = Number.parseInt(device.tcpPort || base.tcpPort || 502, 10);
  return {
    ...base,
    tcpHost,
    tcpPort: Number.isNaN(tcpPort) ? 502 : Math.min(65535, Math.max(1, tcpPort))
  };
}

function nextDuplicateDeviceName(name) {
  const baseName = name.replace(/\s+Copy(?:\s+\d+)?$/i, "");
  let candidate = `${baseName} Copy`;
  let index = 2;
  while (state.devices.some((device) => device.name === candidate)) {
    candidate = `${baseName} Copy ${index}`;
    index += 1;
  }
  return candidate;
}

function duplicateDevice(device) {
  const duplicate = makeDevice({
    id: device.id,
    templateKey: device.templateKey || "generic",
    name: nextDuplicateDeviceName(device.name),
    functionCode: device.functionCode,
    points: device.points,
    cardSpan: device.cardSpan,
    cardHeight: device.cardHeight,
    layoutMode: device.layoutMode,
    heightMode: device.heightMode
  });
  duplicate.intervalMs = device.intervalMs;
  duplicate.tcpHost = device.tcpHost || "";
  duplicate.tcpPort = device.tcpPort || 502;
  duplicate.editingName = true;
  const index = state.devices.findIndex((item) => item.uid === device.uid);
  state.devices.splice(index + 1, 0, duplicate);
  renderDevices();
  log(`Duplicated ${device.name}. Rename the new device if needed.`);
}

function readDeviceGridMetrics() {
  const style = getComputedStyle(els.deviceGrid);
  const columns = style.gridTemplateColumns
    .split(/\s+/)
    .map((value) => Number.parseFloat(value))
    .filter((value) => Number.isFinite(value) && value > 0);
  const columnGap = Number.parseFloat(style.columnGap) || 0;
  const rowGap = Number.parseFloat(style.rowGap) || DEVICE_CARD_HEIGHT_STEP;
  return {
    columnCount: Math.max(1, columns.length),
    columnWidth: columns[0] || 390,
    columnGap,
    rowGap
  };
}

function startDeviceCardResize(event) {
  const handle = event.target.closest("[data-resize-device]");
  if (!handle) return false;
  const device = state.devices.find((item) => item.uid === handle.dataset.uid);
  const card = handle.closest(".device-card");
  if (!device || !card) return false;
  const metrics = readDeviceGridMetrics();
  state.deviceResize = {
    uid: device.uid,
    pointerId: event.pointerId,
    startX: event.clientX,
    startY: event.clientY,
    startSpan: normalizeDeviceCardSpan(device.cardSpan),
    startHeight: normalizeDeviceCardHeight(device.cardHeight),
    startHeightMode: isManualDeviceHeight(device) ? "manual" : "auto",
    columnStep: metrics.columnWidth + metrics.columnGap,
    heightStep: DEVICE_CARD_HEIGHT_STEP,
    maxSpan: Math.min(DEVICE_CARD_MAX_SPAN, metrics.columnCount),
    changed: false
  };
  card.classList.add("is-resizing");
  handle.setPointerCapture?.(event.pointerId);
  event.preventDefault();
  event.stopPropagation();
  return true;
}

function updateDeviceCardResize(event) {
  if (!state.deviceResize) return;
  const resize = state.deviceResize;
  const device = state.devices.find((item) => item.uid === resize.uid);
  const card = els.deviceGrid.querySelector(`[data-uid="${CSS.escape(resize.uid)}"]`);
  if (!device || !card) return;
  const spanDelta = Math.round((event.clientX - resize.startX) / Math.max(1, resize.columnStep));
  const rawHeightDelta = event.clientY - resize.startY;
  const heightMoved = Math.abs(rawHeightDelta) >= resize.heightStep / 2;
  const heightDelta = Math.round(rawHeightDelta / resize.heightStep) * resize.heightStep;
  const nextSpan = clampNumber(resize.startSpan + spanDelta, DEVICE_CARD_MIN_SPAN, resize.maxSpan);
  const widthMoved = nextSpan !== resize.startSpan;
  if (!widthMoved && !heightMoved) return;
  const nextHeight = heightMoved || resize.startHeightMode === "manual"
    ? normalizeDeviceCardHeight(resize.startHeight + heightDelta)
    : autoDeviceCardHeight(device);
  device.cardSpan = nextSpan;
  device.cardHeight = nextHeight;
  if (widthMoved) device.layoutMode = "manual";
  device.heightMode = heightMoved ? "manual" : resize.startHeightMode;
  resize.changed = true;
  card.style.gridColumn = `span ${nextSpan}`;
  card.style.gridRow = `span ${deviceCardRowSpan(nextHeight)}`;
  card.style.setProperty("--device-card-height", `${nextHeight}px`);
}

function finishDeviceCardResize(event) {
  if (!state.deviceResize) return;
  const resize = state.deviceResize;
  const device = state.devices.find((item) => item.uid === resize.uid);
  const card = els.deviceGrid.querySelector(`[data-uid="${CSS.escape(resize.uid)}"]`);
  card?.classList.remove("is-resizing");
  event?.target?.releasePointerCapture?.(resize.pointerId);
  state.deviceResize = null;
  if (!resize.changed) return;
  renderDevicesPreservingScroll();
  if (device) {
    const heightLabel = isManualDeviceHeight(device) ? `${device.cardHeight}px high` : "auto height";
    log(`Resized ${device.name}: ${device.cardSpan} column(s), ${heightLabel}.`);
  }
}

function autoFitDeviceCardHeight(event) {
  const handle = event.target.closest("[data-resize-device]");
  if (!handle) return;
  const device = state.devices.find((item) => item.uid === handle.dataset.uid);
  if (!device) return;
  device.heightMode = "auto";
  device.cardHeight = autoDeviceCardHeight(device);
  renderDevicesPreservingScroll();
  log(`Auto-fitted ${device.name} height.`);
  event.preventDefault();
  event.stopPropagation();
}

function addDeviceFromControls() {
  const id = readNumber(els.deviceId, 1, 1, 247);
  const templateKey = els.deviceTemplate.value;
  const functionCode = Number.parseInt(els.deviceFunction.value, 10);
  const name = els.deviceName.value.trim();
  const points = templateKey === "custom" ? state.customPoints : [readPointDraft("Value")];
  if (templateKey === "custom" && state.customPoints.length === 0) {
    log("Add at least one custom point first.");
    return;
  }
  const added = addDevice(makeDevice({ id, templateKey, name, functionCode, points }));
  if (added) {
    closeModbusModal();
  }
  log(added ? `Added ${name || DEVICE_TEMPLATES[templateKey].name(id)}.` : "Device already exists.");
}

function importFoundDevices() {
  const found = Array.from(
    state.results
      .filter(isFoundScanResult)
      .reduce((map, row) => {
        const key = `${row.port || ""}-${row.slaveId}-${row.functionCode}`;
        if (!map.has(key)) map.set(key, row);
        return map;
      }, new Map())
      .values()
  );

  let added = 0;
  let updated = 0;
  for (const row of found) {
    const pointKind = row.functionCode === 1 || row.functionCode === 2 ? "Bit" : "Register";
    const point = makePoint({
      name: `${pointKind} ${row.startAddress}`,
      address: row.startAddress,
      addressMode: "raw",
      functionCode: row.functionCode,
      type: "uint16",
      wordOrder: "be",
      scale: 1,
      unit: ""
    });
    const existing = state.devices.find((item) =>
      item.id === row.slaveId && Number.parseInt(item.tcpPort || 502, 10) === Number.parseInt(row.port || state.tcpTarget?.port || 502, 10)
    );
    if (existing) {
      if (!existing.points.some((item) => pointFunctionCode(item, existing) === row.functionCode && item.address === point.address && item.name === point.name)) {
        existing.points.push(point);
        updated += 1;
      }
      continue;
    }
    const device = makeDevice({ id: row.slaveId, templateKey: "generic", functionCode: row.functionCode, points: [point] });
    device.tcpHost = state.tcpTarget?.host || els.tcpHost.value.trim();
    device.tcpPort = Number.parseInt(row.port || state.tcpTarget?.port || els.tcpPort.value || 502, 10) || 502;
    if (addDevice(device)) {
      added += 1;
    }
  }
  setActiveTab("devices");
  renderDevices();
  log(`Imported ${added} found device(s), updated ${updated} point(s). Use Edit Points to add or change registers.`);
}

function serializePoint(point, device) {
  return {
    name: point.name,
    address: point.address,
    addressMode: point.addressMode || pointAddressMode(point, device),
    functionCode: pointFunctionCode(point, device),
    type: normalizePointType(point.type),
    wordOrder: point.wordOrder === "swap" ? "swap" : "be",
    scale: point.scale ?? 1,
    unit: point.unit || "",
    controlEnabled: pointControlEnabled(point, device),
    controlValue: point.controlValue ?? ""
  };
}

function serializeDevice(device) {
  return {
    id: device.id,
    name: device.name,
    templateKey: device.templateKey || "generic",
    functionCode: Number.parseInt(device.functionCode || 3, 10),
    tcpHost: device.tcpHost || "",
    tcpPort: Number.parseInt(device.tcpPort || 502, 10),
    intervalMs: Number.parseInt(device.intervalMs || 1000, 10),
    intervalSec: Number.parseFloat(msToSecondsValue(device.intervalMs || 1000)),
    cardSpan: normalizeDeviceCardSpan(device.cardSpan),
    cardHeight: normalizeDeviceCardHeight(device.cardHeight),
    layoutMode: isManualDeviceLayout(device) ? "manual" : "auto",
    heightMode: isManualDeviceHeight(device) ? "manual" : "auto",
    points: device.points.map((point) => serializePoint(point, device))
  };
}

function escapeCsvCell(value) {
  let text = String(value ?? "").replaceAll('"', '""');
  // Neutralize spreadsheet formula injection: a leading =, +, -, @, tab, or CR
  // would execute as a formula when the exported CSV is opened in Excel.
  if(/^[=+\-@\t\r]/.test(text)) {
    text = `'${text}`;
  }
  return `"${text}"`;
}

function exportDeviceConfig() {
  if (state.devices.length === 0) {
    log("No device config to export.");
    return;
  }

  const header = [
    "device_order",
    "device_id",
    "device_name",
    "device_function_code",
    "host_ip",
    "tcp_port",
    "monitor_rate_sec",
    "card_span",
    "card_height",
    "layout_mode",
    "height_mode",
    "point_order",
    "point_name",
    "point_function_code",
    "address",
    "address_mode",
    "data_type",
    "word_order",
    "scale",
    "unit",
    "control_enabled",
    "control_value"
  ];
  const rows = state.devices.flatMap((device, deviceIndex) =>
    device.points.map((point, pointIndex) => [
      deviceIndex + 1,
      device.id,
      device.name,
      Number.parseInt(device.functionCode || 3, 10),
      device.tcpHost || "",
      Number.parseInt(device.tcpPort || 502, 10),
      msToSecondsValue(device.intervalMs || 1000),
      normalizeDeviceCardSpan(device.cardSpan),
      normalizeDeviceCardHeight(device.cardHeight),
      isManualDeviceLayout(device) ? "manual" : "auto",
      isManualDeviceHeight(device) ? "manual" : "auto",
      pointIndex + 1,
      point.name,
      pointFunctionCode(point, device),
      point.address,
      point.addressMode || pointAddressMode(point, device),
      normalizePointType(point.type),
      point.wordOrder === "swap" ? "swap" : "be",
      point.scale ?? 1,
      point.unit || "",
      pointControlEnabled(point, device) ? "1" : "0",
      point.controlValue ?? ""
    ])
  );
  const csv = [header, ...rows]
    .map((row) => row.map(escapeCsvCell).join(","))
    .join("\r\n");
  const blob = new Blob([`\ufeff${csv}`], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  link.href = url;
  link.download = `alto-modbus-devices-${stamp}.csv`;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  log(`Exported ${state.devices.length} device config(s) to CSV.`);
}

function normalizeImportedFunctionCode(value, fallback = 3) {
  const functionCode = Number.parseInt(value ?? fallback, 10);
  return [1, 2, 3, 4].includes(functionCode) ? functionCode : fallback;
}

function normalizeImportedDeviceId(value) {
  const id = Number.parseInt(value, 10);
  if (Number.isNaN(id)) return 1;
  return Math.min(247, Math.max(1, id));
}

function normalizeImportedAddress(value) {
  const address = Number.parseInt(value, 10);
  if (Number.isNaN(address)) return 0;
  return Math.min(65535, Math.max(0, address));
}

function normalizeImportedPointAddress(value, addressMode, functionCode) {
  const address = normalizeImportedAddress(value);
  if (addressMode !== "reference") {
    return { address, addressMode: "raw" };
  }
  const referenceAddress = normalizeModbusReferenceAddress(address, functionCode);
  if (referenceAddress !== address) {
    return { address: referenceAddress, addressMode: "raw" };
  }
  const legacyBaseOneAddress = address > 0 && address <= 9999 ? address - 1 : address;
  return { address: legacyBaseOneAddress, addressMode: "raw" };
}

function normalizeImportedDevice(item, index) {
  const source = item && typeof item === "object" ? item : {};
  const id = normalizeImportedDeviceId(source.id ?? source.slaveId ?? source.unitId ?? index + 1);
  const functionCode = normalizeImportedFunctionCode(source.functionCode ?? source.function ?? source.fc, 3);
  const name = String(source.name || `Device ${id}`);
  const importedPoints = Array.isArray(source.points) ? source.points : [];
  const points = importedPoints.map((point, pointIndex) => {
    const pointSource = point && typeof point === "object" ? point : {};
    const pointFunctionCode = normalizeImportedFunctionCode(
      pointSource.functionCode ?? pointSource.function ?? pointSource.fc,
      functionCode
    );
    const addressMode = pointSource.addressMode || (source.templateKey === "custom" ? "reference" : "raw");
    const importedAddress = normalizeImportedPointAddress(
      pointSource.address ?? pointSource.startAddress ?? pointSource.register ?? 0,
      addressMode,
      pointFunctionCode
    );
    return makePoint({
      name: String(pointSource.name || `Point ${pointIndex + 1}`),
      address: importedAddress.address,
      addressMode: importedAddress.addressMode,
      functionCode: pointFunctionCode,
      type: pointSource.type || pointSource.dataType || "uint16",
      wordOrder: pointSource.wordOrder || pointSource.order || "be",
      scale: pointSource.scale ?? 1,
      unit: String(pointSource.unit || ""),
      controlEnabled: pointSource.controlEnabled ?? pointSource.control ?? false,
      controlValue: pointSource.controlValue ?? pointSource.writeValue ?? ""
    });
  });

  if (points.length === 0) {
    points.push(makePoint({
      name: "Value",
      address: 0,
      functionCode,
      type: "uint16",
      wordOrder: "be",
      scale: 1,
      unit: "",
      controlEnabled: false,
      controlValue: ""
    }));
  }

  const device = makeDevice({
    id,
    templateKey: source.templateKey || "generic",
    name,
    functionCode,
    points,
    cardSpan: source.cardSpan ?? source.card_span ?? source.cardWidth ?? source.card_width,
    cardHeight: source.cardHeight ?? source.card_height,
    layoutMode: source.layoutMode ?? source.layout_mode ?? "auto",
    heightMode: source.heightMode ?? source.height_mode ?? "auto"
  });
  device.tcpHost = String(source.tcpHost ?? source.hostIp ?? source.host ?? "");
  device.tcpPort = Number.parseInt(source.tcpPort ?? source.port ?? 502, 10) || 502;
  const intervalSource = source.intervalSec ?? source.monitorRateSec ?? source.pollRateSec ?? source.intervalSeconds;
  device.intervalMs = intervalSource !== undefined
    ? intervalMsFromValue(intervalSource, device.intervalMs, "sec")
    : intervalMsFromValue(source.intervalMs ?? source.pollRate ?? device.intervalMs, device.intervalMs, "ms");
  device.editingName = false;
  return device;
}

function importDeviceConfigPayload(payload) {
  const devices = Array.isArray(payload) ? payload : payload.devices;
  if (!Array.isArray(devices)) {
    throw new Error("Config file must contain a devices array.");
  }
  stopDeviceMonitor();
  state.devices = devices.map(normalizeImportedDevice);
  setActiveTab("devices");
  renderDevices();
  const totalControls = state.devices.reduce(
    (sum, device) => sum + device.points.filter((point) => pointControlEnabled(point, device)).length,
    0
  );
  log(`Imported ${state.devices.length} device config(s), ${totalControls} control(s).`);
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  const source = String(text || "").replace(/^\ufeff/, "");

  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    const next = source[index + 1];
    if (quoted) {
      if (char === '"' && next === '"') {
        cell += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
    } else if (char === '"') {
      quoted = true;
    } else if (char === ",") {
      row.push(cell);
      cell = "";
    } else if (char === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else if (char !== "\r") {
      cell += char;
    }
  }

  row.push(cell);
  if (row.some((value) => value.trim() !== "")) rows.push(row);
  return rows;
}

function csvHeaderMap(header) {
  return header.reduce((map, value, index) => {
    map[String(value || "").trim().toLowerCase()] = index;
    return map;
  }, {});
}

function csvValue(row, map, names, fallback = "") {
  for (const name of names) {
    const index = map[name.toLowerCase()];
    if (index !== undefined && row[index] !== undefined && row[index] !== "") {
      return row[index];
    }
  }
  return fallback;
}

function parseFunctionCode(value, fallback = 3) {
  const text = String(value ?? "").trim().toLowerCase();
  const number = Number.parseInt(text, 10);
  if ([1, 2, 3, 4].includes(number)) return number;
  if (text.includes("coil")) return 1;
  if (text.includes("discrete")) return 2;
  if (text.includes("input")) return 4;
  if (text.includes("holding")) return 3;
  return fallback;
}

function importDeviceConfigCsv(text) {
  const rows = parseCsv(text).filter((row) => row.some((value) => value.trim() !== ""));
  if (rows.length < 2) throw new Error("CSV must include a header row and at least one point row.");

  const header = csvHeaderMap(rows[0]);
  const groups = new Map();
  for (const [rowIndex, row] of rows.slice(1).entries()) {
    const id = normalizeImportedDeviceId(csvValue(row, header, ["device_id", "id", "slave_id", "unit_id"], 1));
    const orderText = csvValue(row, header, ["device_order", "order"], "");
    const deviceName = csvValue(row, header, ["device_name", "name"], `Device ${id}`);
    const deviceFunctionCode = parseFunctionCode(csvValue(row, header, ["device_function_code", "device_function", "function_code", "function"], 3), 3);
    const hostIp = csvValue(row, header, ["host_ip", "tcp_host", "host", "ip"], els.tcpHost.value.trim());
    const tcpPort = Number.parseInt(csvValue(row, header, ["tcp_port", "port"], els.tcpPort.value || 502), 10) || 502;
    const groupKey = `device-${hostIp}-${tcpPort}-${id}-${deviceName}-${deviceFunctionCode}`;

    if (!groups.has(groupKey)) {
      groups.set(groupKey, {
        order: Number.parseInt(orderText, 10) || groups.size + 1,
        id,
        name: deviceName,
        templateKey: "generic",
        functionCode: deviceFunctionCode,
        tcpHost: hostIp,
        tcpPort,
        intervalMs: header.monitor_rate_sec !== undefined
          ? intervalMsFromValue(csvValue(row, header, ["monitor_rate_sec", "interval_sec", "poll_rate_sec"], 1), 1000, "sec")
          : intervalMsFromValue(csvValue(row, header, ["monitor_rate_ms", "interval_ms", "poll_rate_ms"], 1000), 1000, "ms"),
        cardSpan: normalizeDeviceCardSpan(csvValue(row, header, ["card_span", "card_width"], DEVICE_CARD_DEFAULT_SPAN)),
        cardHeight: normalizeDeviceCardHeight(csvValue(row, header, ["card_height"], DEVICE_CARD_DEFAULT_HEIGHT)),
        layoutMode: csvValue(row, header, ["layout_mode", "layout"], "auto").toLowerCase() === "manual" ? "manual" : "auto",
        heightMode: csvValue(row, header, ["height_mode"], "auto").toLowerCase() === "manual" ? "manual" : "auto",
        points: []
      });
    }

    const device = groups.get(groupKey);
    const pointName = csvValue(row, header, ["point_name", "point", "name"], `Point ${device.points.length + 1}`);
    const address = csvValue(row, header, ["address", "start_address", "register"], "");
    if (address === "") continue;
    const pointFunctionCode = parseFunctionCode(csvValue(row, header, ["point_function_code", "point_function", "function_code", "function"], device.functionCode), device.functionCode);
    const controlValue = csvValue(row, header, ["control_value", "write_value"], "");
    const addressMode = csvValue(row, header, ["address_mode", "address_type"], "raw");
    const importedAddress = normalizeImportedPointAddress(address, addressMode, pointFunctionCode);
    device.points.push({
      order: Number.parseInt(csvValue(row, header, ["point_order"], device.points.length + 1), 10) || device.points.length + 1,
      name: pointName,
      address: importedAddress.address,
      addressMode: importedAddress.addressMode,
      functionCode: pointFunctionCode,
      type: csvValue(row, header, ["data_type", "type"], "uint16"),
      wordOrder: csvValue(row, header, ["word_order", "order"], "be"),
      scale: csvValue(row, header, ["scale"], 1),
      unit: csvValue(row, header, ["unit"], ""),
      controlEnabled: normalizeControlEnabled(csvValue(row, header, ["control_enabled", "control", "is_control"], "")),
      controlValue
    });
  }

  const devices = Array.from(groups.values())
    .sort((a, b) => a.order - b.order || a.id - b.id || a.name.localeCompare(b.name))
    .map((device) => ({
      ...device,
      points: device.points
        .sort((a, b) => a.order - b.order)
        .map(({ order, ...point }) => point)
    }));

  importDeviceConfigPayload({ devices });
}

function importDeviceConfigFile(file) {
  const reader = new FileReader();
  reader.addEventListener("load", () => {
    try {
      const text = String(reader.result || "");
      if (file.name.toLowerCase().endsWith(".json") || text.trim().startsWith("{") || text.trim().startsWith("[")) {
        importDeviceConfigPayload(JSON.parse(text));
      } else {
        importDeviceConfigCsv(text);
      }
    } catch (error) {
      log(`Import config failed: ${error.message}`);
    }
  });
  reader.addEventListener("error", () => {
    log("Import config failed: cannot read file.");
  });
  reader.readAsText(file);
}

function covModeEnabled() {
  return !!els.covMode?.checked;
}

function updateDeviceControls() {
  const totalPoints = state.devices.reduce((sum, device) => sum + device.points.length, 0);
  const totalControls = state.devices.reduce(
    (sum, device) => sum + device.points.filter((point) => pointControlEnabled(point, device)).length,
    0
  );
  const online = state.devices.filter((device) => device.lastReadAt && !device.lastError).length;
  const covActive = state.deviceMonitoring && covModeEnabled();
  els.refreshDevicesBtn.disabled = !state.connected || state.devices.length === 0 || state.deviceRefreshRunning;
  els.startDeviceMonitorBtn.disabled = !state.connected || state.devices.length === 0 || state.deviceMonitoring;
  els.stopDeviceMonitorBtn.disabled = !state.deviceMonitoring;
  els.clearDevicesBtn.disabled = state.devices.length === 0;
  els.exportDeviceConfigBtn.disabled = state.devices.length === 0;
  setBadge(
    els.deviceMonitorBadge,
    state.devices.length ? `${online}/${state.devices.length} online` : "No devices",
    state.devices.length && online === state.devices.length ? "live" : state.devices.length ? "ready" : "idle"
  );
  setBadge(
    els.deviceInsightBadge,
    state.writeInProgress
      ? "Writing..."
      : state.deviceRefreshRunning
      ? covActive ? "COV checking..." : "Reading..."
      : state.deviceMonitoring
        ? covActive ? "COV watch" : "Monitoring"
        : `${totalPoints} point(s)`,
    state.deviceMonitoring ? "live" : "neutral"
  );
  els.deviceSummary.textContent = state.devices.length
    ? `${state.devices.length} device profile(s), ${totalPoints} point(s), ${totalControls} control(s)`
    : "No point list loaded";
}

function renderDeviceNameEditor(device) {
  if (!device.editingName) return "";
  return `
    <div class="device-name-editor" data-uid="${device.uid}">
      <label class="device-id-edit-field">
        <span>ID</span>
        <input data-field="device-id" type="number" min="1" max="247" value="${device.id}" />
      </label>
      <label>
        <span>Device name</span>
        <input data-field="device-name" type="text" value="${escapeHtml(device.name)}" />
      </label>
      <button class="secondary-btn compact" type="button" data-icon="check" data-action="save-device-name" data-uid="${device.uid}">Save</button>
    </div>
  `;
}

function renderPointWriteStatus(point) {
  if (!point.writeStatus) return "";
  const kind = point.writeStatus.kind === "ok" ? "ok" : "error";
  return `<span class="point-write-status ${kind}">${escapeHtml(point.writeStatus.message)}</span>`;
}

function setPointWriteStatus(device, point, kind, message) {
  const token = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  point.writeStatus = { kind, message, token };
  window.setTimeout(() => {
    if (!point.writeStatus || point.writeStatus.token !== token) return;
    point.writeStatus = null;
    updateDeviceCardLiveData(device, { forceControlRender: true });
  }, 5000);
}

function renderPointControlCell(point, device, pointIndex) {
  const writeFunction = writableFunctionCode(point, device);
  if (!pointControlEnabled(point, device)) {
    return '<span class="control-muted">-</span>';
  }
  if (!writeFunction) {
    return '<span class="control-muted">Read only</span>';
  }
  const disabled = state.connected ? "" : "disabled";
  if (writeFunction === 5) {
    const currentValue = point.raw ?? point.value ?? point.controlValue;
    const isOn = Number(currentValue) ? true : false;
    const nextValue = isOn ? "0" : "1";
    return `
      <div class="point-control point-control-coil">
        <button class="coil-toggle ${isOn ? "is-on" : ""}" type="button" role="switch" aria-checked="${isOn ? "true" : "false"}" data-action="write-device-point" data-uid="${device.uid}" data-point-index="${pointIndex}" data-control-value="${nextValue}" ${disabled}>
          <span class="coil-toggle-track"><span class="coil-toggle-thumb"></span></span>
          <span class="coil-toggle-label">${isOn ? "On" : "Off"}</span>
        </button>
        ${renderPointWriteStatus(point)}
      </div>
    `;
  }
  const placeholder = point.controlValue ? `Default ${point.controlValue}` : "Value";
  return `
    <div class="point-control">
      <input class="control-value-input" data-control-value type="number" step="${pointWriteInputStep(point)}" value="" placeholder="${escapeHtml(placeholder)}" ${disabled} />
      <button class="control-btn" type="button" data-icon="edit" data-action="write-device-point" data-uid="${device.uid}" data-point-index="${pointIndex}" ${disabled}>Write</button>
      ${renderPointWriteStatus(point)}
    </div>
  `;
}

function pointEditorDevice() {
  if (!state.pointEditor) return null;
  return state.devices.find((item) => item.uid === state.pointEditor.deviceUid) || null;
}

function openDevicePointEditor(device, selectedIndex = 0) {
  state.pointEditor = {
    deviceUid: device.uid,
    mode: device.points.length ? "edit" : "add",
    selectedIndex: clampNumber(selectedIndex, 0, Math.max(0, device.points.length - 1))
  };
  renderPointEditorModal();
}

function closeDevicePointEditor() {
  state.pointEditor = null;
  document.querySelector(".point-editor-overlay")?.remove();
}

function pointEditorMode() {
  return state.pointEditor?.mode === "add" ? "add" : "edit";
}

function setPointEditorMode(mode, selectedIndex = state.pointEditor?.selectedIndex || 0) {
  if (!state.pointEditor) return;
  const device = pointEditorDevice();
  if (!device) {
    closeDevicePointEditor();
    return;
  }
  state.pointEditor.mode = mode === "add" ? "add" : "edit";
  state.pointEditor.selectedIndex = clampNumber(selectedIndex, 0, Math.max(0, device.points.length - 1));
  renderPointEditorModal();
}

function pointEditorForm(point, device, prefix) {
  const formPoint = point || makePoint({
    name: `Point ${device.points.length + 1}`,
    address: nextDevicePointAddress(device),
    functionCode: device.functionCode,
    type: "uint16",
    wordOrder: "be",
    scale: 1,
    unit: "",
    controlEnabled: false,
    controlValue: ""
  });
  const controlAvailable = pointControlAvailable(formPoint, device);
  return `
    <div class="point-editor-form" data-point-editor-form>
      <label><span>Name</span><input data-field="${prefix}-name" type="text" value="${escapeHtml(formPoint.name)}" /></label>
      <label><span>Address (Base 0)</span><input data-field="${prefix}-address" type="number" min="0" max="65535" value="${formPoint.address}" /></label>
      <label><span>Function</span><select data-field="${prefix}-function">${functionOptions(pointFunctionCode(formPoint, device))}</select></label>
      <label><span>Type</span><select data-field="${prefix}-type">${pointTypeOptions(formPoint.type)}</select></label>
      <label><span>Word order</span><select data-field="${prefix}-word-order">${wordOrderOptions(formPoint.wordOrder)}</select></label>
      <label><span>Scale</span><input data-field="${prefix}-scale" type="number" step="0.001" value="${formPoint.scale ?? 1}" /></label>
      <label><span>Unit</span><input data-field="${prefix}-unit" type="text" value="${escapeHtml(formPoint.unit ?? "")}" placeholder="C, %, ppm..." /></label>
      <label><span>Write default</span><input data-field="${prefix}-control-value" type="text" value="${escapeHtml(formPoint.controlValue ?? "")}" placeholder="0 / 1 / value" /></label>
      <label class="point-editor-check" title="${controlAvailable ? "Allow this point to write values" : "This point is read only"}">
        <span>Control</span>
        <input data-field="${prefix}-control-enabled" type="checkbox" ${pointControlEnabled(formPoint, device) ? "checked" : ""} ${controlAvailable ? "" : "disabled"} />
      </label>
    </div>
  `;
}

function renderPointEditorModal() {
  const device = pointEditorDevice();
  const previousModal = document.querySelector(".point-editor-overlay");
  const previousListScrollTop = previousModal
    ?.querySelector(".point-editor-list-scroll")
    ?.scrollTop ?? null;
  previousModal?.remove();
  if (!device || !state.pointEditor) return;

  let mode = pointEditorMode();
  if (mode === "edit" && device.points.length === 0) {
    state.pointEditor.mode = "add";
    mode = "add";
  }
  const selectedIndex = clampNumber(state.pointEditor.selectedIndex || 0, 0, Math.max(0, device.points.length - 1));
  state.pointEditor.selectedIndex = selectedIndex;
  const selectedPoint = device.points[selectedIndex] || null;
  const pointList = device.points.map((point, index) => {
    const functionCode = pointFunctionCode(point, device);
    const isSelected = mode === "edit" && index === selectedIndex;
    const controlAvailable = pointControlAvailable(point, device);
    const controlEnabled = pointControlEnabled(point, device);
    const controlLabel = `Control for ${point.name}`;
    const controlTitle = controlAvailable
      ? `${controlEnabled ? "Disable" : "Enable"} control for ${point.name}`
      : `${point.name} is read only`;
    return `
      <div class="point-editor-list-row ${isSelected ? "is-selected" : ""}">
        <button class="point-editor-list-item" type="button" data-action="select-editor-point" data-point-index="${index}">
          <strong>${escapeHtml(point.name)}</strong>
          <span>${point.address} - ${escapeHtml(READ_FUNCTIONS[functionCode] || `F${functionCode}`)} - ${pointTypeLabel(point)}${controlEnabled ? " - Control on" : ""}</span>
        </button>
        <div class="point-editor-row-tools">
          <label class="point-editor-control-toggle ${controlAvailable ? "" : "is-disabled"}" title="${escapeHtml(controlTitle)}">
            <input
              type="checkbox"
              data-action="toggle-editor-point-control"
              data-point-index="${index}"
              aria-label="${escapeHtml(controlLabel)}"
              ${controlEnabled ? "checked" : ""}
              ${controlAvailable ? "" : "disabled"}
            />
            <span>Control</span>
          </label>
          <div class="point-editor-order-actions">
            <button class="icon-btn point-order-btn" type="button" data-action="move-editor-point-up" data-point-index="${index}" ${index === 0 ? "disabled" : ""} title="Move point up" aria-label="Move ${escapeHtml(point.name)} up">^</button>
            <button class="icon-btn point-order-btn" type="button" data-action="move-editor-point-down" data-point-index="${index}" ${index === device.points.length - 1 ? "disabled" : ""} title="Move point down" aria-label="Move ${escapeHtml(point.name)} down">v</button>
          </div>
        </div>
      </div>
    `;
  }).join("");
  const copyTargets = state.devices
    .filter((item) => item.uid !== device.uid)
    .map((item) => `<option value="${escapeHtml(item.uid)}">ID ${item.id} - ${escapeHtml(item.name)}</option>`)
    .join("");
  const copyPanel = mode === "edit" && selectedPoint ? `
    <div class="point-editor-copy-panel">
      <label>
        <span>Copy selected point to</span>
        <select data-copy-target-device ${copyTargets ? "" : "disabled"}>
          ${copyTargets || '<option value="">No other device</option>'}
        </select>
      </label>
      <button class="secondary-btn" type="button" data-icon="copy" data-action="copy-editor-point" data-point-index="${selectedIndex}" ${copyTargets ? "" : "disabled"}>Copy Point</button>
    </div>
  ` : "";
  const prefix = mode === "add" ? "add" : "edit";
  const title = mode === "add" ? "Add point" : `Edit ${selectedPoint ? selectedPoint.name : "point"}`;
  const modal = document.createElement("div");
  modal.className = "point-editor-overlay";
  modal.innerHTML = `
    <div class="point-editor-dialog" role="dialog" aria-modal="true" aria-label="Edit points for ${escapeHtml(device.name)}">
      <div class="point-editor-titlebar">
        <div>
          <h3>${escapeHtml(device.name)}</h3>
          <span>ID ${device.id} - ${escapeHtml(READ_FUNCTIONS[device.functionCode] || `F${device.functionCode}`)} - ${device.points.length} point(s)</span>
        </div>
        <button class="icon-btn point-editor-close" type="button" data-action="close-point-editor" aria-label="Close point editor">x</button>
      </div>
      <div class="point-editor-body">
        <aside class="point-editor-list">
          <button class="primary-btn point-editor-add-tab ${mode === "add" ? "is-active" : ""}" type="button" data-icon="+" data-action="new-editor-point">Add Point</button>
          <div class="point-editor-list-scroll">
            ${pointList || '<div class="empty-found">No points yet.</div>'}
          </div>
        </aside>
        <section class="point-editor-detail">
          <div class="point-editor-detail-head">
            <h3>${escapeHtml(title)}</h3>
            <span>${mode === "add" ? "Create a new Modbus point" : `Point ${selectedIndex + 1} of ${device.points.length}`}</span>
          </div>
          ${copyPanel}
          ${pointEditorForm(mode === "add" ? null : selectedPoint, device, prefix)}
          <div class="point-editor-actions">
            ${mode === "edit" ? `<button class="secondary-btn" type="button" data-icon="close" data-action="remove-editor-point" data-point-index="${selectedIndex}">Remove</button>` : ""}
            <button class="secondary-btn" type="button" data-icon="close" data-action="close-point-editor">Cancel</button>
            <button class="primary-btn" type="button" data-icon="check" data-action="${mode === "add" ? "add-editor-point" : "save-editor-point"}" data-point-index="${selectedIndex}">
              ${mode === "add" ? "Add Point" : "Save Point"}
            </button>
          </div>
        </section>
      </div>
    </div>
  `;
  document.body.append(modal);

  const listScroll = modal.querySelector(".point-editor-list-scroll");
  const selectedRow = modal.querySelector(".point-editor-list-row.is-selected");
  if (listScroll) {
    if (previousListScrollTop !== null) {
      listScroll.scrollTop = previousListScrollTop;
    }
    if (selectedRow) {
      const listRect = listScroll.getBoundingClientRect();
      const rowRect = selectedRow.getBoundingClientRect();
      if (rowRect.top < listRect.top) {
        listScroll.scrollTop -= listRect.top - rowRect.top;
      } else if (rowRect.bottom > listRect.bottom) {
        listScroll.scrollTop += rowRect.bottom - listRect.bottom;
      }
    }
  }
}

function captureDeviceScrollState() {
  const tableScroll = {};
  els.deviceGrid.querySelectorAll(".device-card").forEach((card) => {
    const uid = card.dataset.uid;
    const table = card.querySelector(".compact-table");
    if (uid && table) {
      tableScroll[uid] = {
        top: table.scrollTop,
        left: table.scrollLeft
      };
    }
  });
  return {
    pageX: window.scrollX,
    pageY: window.scrollY,
    tableScroll
  };
}

function restoreDeviceScrollState(snapshot) {
  if (!snapshot) return;
  window.scrollTo(snapshot.pageX, snapshot.pageY);
  window.requestAnimationFrame(() => {
    window.scrollTo(snapshot.pageX, snapshot.pageY);
    els.deviceGrid.querySelectorAll(".device-card").forEach((card) => {
      const saved = snapshot.tableScroll[card.dataset.uid];
      const table = card.querySelector(".compact-table");
      if (saved && table) {
        table.scrollTop = saved.top;
        table.scrollLeft = saved.left;
      }
    });
  });
}

function renderDevicesPreservingScroll() {
  const snapshot = captureDeviceScrollState();
  renderDevices();
  restoreDeviceScrollState(snapshot);
}

function updateDeviceCardLiveData(device, options = {}) {
  const card = els.deviceGrid.querySelector(`[data-uid="${CSS.escape(device.uid)}"]`);
  if (!card || device.editingName) {
    renderDevicesPreservingScroll();
    return;
  }

  const status = card.querySelector(".status-pill");
  if (status) {
    const statusText = device.lastError
      ? "Error"
      : device.lastReadAt
        ? `OK ${formatDurationSec(device.lastLatencyMs)}`
        : "Waiting";
    status.textContent = statusText;
    status.title = device.lastError || statusText;
    status.className = `status-pill ${device.lastError ? "fail" : device.lastReadAt ? "ok" : ""}`;
  }

  device.points.forEach((point, pointIndex) => {
    const row = card.querySelector(`[data-point-row="${pointIndex}"]`);
    if (!row) return;
    const rawCell = row.querySelector("[data-point-raw]");
    const valueCell = row.querySelector("[data-point-value]");
    const controlCell = row.querySelector("[data-point-control]");
    if (rawCell) {
      rawCell.textContent = point.lastError ? "error" : formatDataValue(point.raw);
      rawCell.title = point.lastError || "";
    }
    if (valueCell) {
      valueCell.textContent = point.lastError ? "error" : formatPointValue(point);
      valueCell.title = point.lastError || "";
    }
    if (controlCell && (options.forceControlRender || !controlCell.querySelector(":focus"))) {
      controlCell.innerHTML = renderPointControlCell(point, device, pointIndex);
    }
  });
  updateDeviceControls();
  if (state.activeTab === "register") renderRegisterMap();
}

function renderDevices() {
  els.deviceGrid.innerHTML = "";
  if (state.devices.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-found";
    empty.textContent = "Add a device template or import IDs from Device Scan.";
    els.deviceGrid.append(empty);
    updateDeviceControls();
    if (state.activeTab === "register") renderRegisterMap();
    return;
  }

  for (const [deviceIndex, device] of state.devices.entries()) {
    const card = document.createElement("article");
    card.className = `device-card ${device.editingName ? "is-editing" : ""}`;
    card.dataset.deviceIndex = String(deviceIndex);
    card.dataset.uid = device.uid;
    const layout = resolveDeviceCardLayout(device, state.devices.length);
    device.cardSpan = layout.span;
    device.cardHeight = layout.height;
    device.layoutMode = isManualDeviceLayout(device) ? "manual" : "auto";
    const statusText = device.lastError
      ? "Error"
      : device.lastReadAt
        ? `OK ${formatDurationSec(device.lastLatencyMs)}`
        : "Waiting";
    const statusTitle = device.lastError
      ? device.lastError
      : statusText;
    const rows = device.points.map((point, pointIndex) => {
      const fnLabel = READ_FUNCTIONS[pointFunctionCode(point, device)] || "";
      const typeLabel = pointTypeLabel(point);
      const formattedVal = point.lastError ? "error" : formatPointValue(point);
      return `
      <tr data-point-row="${pointIndex}">
        <td title="${point.address}">${point.address}</td>
        <td title="${escapeHtml(point.name)}">${escapeHtml(point.name)}</td>
        <td title="${escapeHtml(fnLabel)}">${escapeHtml(fnLabel)}</td>
        <td title="${escapeHtml(typeLabel)}">${escapeHtml(typeLabel)}</td>
        <td data-point-raw title="${escapeHtml(point.lastError || "")}">${point.lastError ? "error" : formatDataValue(point.raw)}</td>
        <td data-point-value title="${escapeHtml(point.lastError || formattedVal)}">${point.lastError ? "error" : escapeHtml(formattedVal)}</td>
        <td data-point-control>${renderPointControlCell(point, device, pointIndex)}</td>
      </tr>
    `;
    }).join("");
    const usingRtu = state.mode === "rtu";
    const connectionFields = usingRtu ? `
        <label class="device-host-field device-readonly-field">
          <span>COM / Serial</span>
          <input type="text" value="${escapeHtml(rtuSerialLabel())}" readonly />
        </label>
        <label class="device-port-field device-readonly-field">
          <span>Baud</span>
          <input type="text" value="${escapeHtml(els.baudRate.value || "9600")}" readonly />
        </label>
    ` : `
        <label class="device-host-field">
          <span>Host/IP</span>
          <input data-device-host data-uid="${device.uid}" type="text" value="${escapeHtml(device.tcpHost || "")}" placeholder="${escapeHtml(els.tcpHost.value.trim() || "192.168.1.10")}" />
        </label>
        <label class="device-port-field">
          <span>Port</span>
          <input data-device-port data-uid="${device.uid}" type="number" min="1" max="65535" value="${Number.parseInt(device.tcpPort || 502, 10)}" />
        </label>
    `;
    card.innerHTML = `
      <div class="device-card-head">
        <span class="drag-handle device-drag-handle" draggable="true" aria-hidden="true">::</span>
        <div class="device-title-block">
          <div class="device-title-row">
            <strong>${escapeHtml(device.name)}</strong>
            <button class="icon-btn rename-icon-btn ${device.editingName ? "is-active" : ""}" type="button" data-action="toggle-rename-device" data-uid="${device.uid}" title="Rename device" aria-label="Rename ${escapeHtml(device.name)}">${ICON_EDIT}</button>
            <button class="icon-btn rename-icon-btn duplicate-icon-btn" type="button" data-action="duplicate-device" data-uid="${device.uid}" title="Duplicate device" aria-label="Duplicate ${escapeHtml(device.name)}">${ICON_COPY}</button>
            <button class="icon-btn rename-icon-btn remove-icon-btn" type="button" data-action="remove-device" data-uid="${device.uid}" title="Remove device" aria-label="Remove ${escapeHtml(device.name)}">${ICON_TRASH}</button>
          </div>
          <span>ID ${device.id} - ${escapeHtml(READ_FUNCTIONS[device.functionCode])}</span>
        </div>
        <span class="status-pill ${device.lastError ? "fail" : device.lastReadAt ? "ok" : ""}" title="${escapeHtml(statusTitle)}">${escapeHtml(statusText)}</span>
      </div>
      <div class="device-card-actions">
        <button class="secondary-btn compact" type="button" data-icon="refresh" data-action="refresh-device" data-uid="${device.uid}">Refresh</button>
        <button class="secondary-btn compact" type="button" data-icon="download" data-action="load-device" data-uid="${device.uid}">Load Read</button>
        <button class="secondary-btn compact" type="button" data-icon="edit" data-action="toggle-edit-points" data-uid="${device.uid}">Edit Points</button>
      </div>
      <div class="device-card-config ${usingRtu ? "is-rtu" : ""}">
        ${connectionFields}
        <label class="device-rate-field">
          <span>Rate sec</span>
          <input data-device-rate data-uid="${device.uid}" type="number" min="0.5" max="60" step="0.1" value="${msToSecondsValue(device.intervalMs || 1000)}" />
        </label>
      </div>
      ${renderDeviceNameEditor(device)}
      <div class="table-wrap device-table-wrap compact-table">
        <table>
          <thead>
            <tr><th>ADDR</th><th>POINT</th><th>FUNCTION</th><th>TYPE</th><th>RAW</th><th>VALUE</th><th>CONTROL</th></tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
      <div class="device-resize-handle" data-resize-device data-uid="${device.uid}" title="Drag to resize card. Double-click to auto-fit height." aria-label="Resize ${escapeHtml(device.name)} card"></div>
    `;
    els.deviceGrid.append(card);
  }
  updateDeviceControls();
  if (state.activeTab === "register") renderRegisterMap();
}

async function readDevice(device) {
  if (!state.connected) throw new Error("Not connected.");
  if (device.points.length === 0) throw new Error("No points configured.");
  const groups = device.points.reduce((map, point) => {
    const functionCode = pointFunctionCode(point, device);
    if (!map.has(functionCode)) map.set(functionCode, []);
    map.get(functionCode).push(point);
    return map;
  }, new Map());

  let latencyMs = 0;
  let successfulBlocks = 0;
  let lastBlockError = null;
  for (const [functionCode, points] of groups.entries()) {
    const blocks = buildPointReadBlocks(points, device, functionCode);
    for (const block of blocks) {
      const config = {
        ...getDeviceBaseConfig(device),
        unitId: device.id,
        functionCode,
        startAddress: block.start,
        quantity: block.end - block.start + 1
      };

      try {
        const result = await requestRead(config);
        latencyMs += result.latencyMs ?? 0;
        successfulBlocks += 1;
        for (const span of block.spans) {
          const readPoint = { ...span.point, address: span.start };
          const decoded = decodePointValue(readPoint, result.values, block.start, functionCode);
          span.point.raw = decoded.raw;
          span.point.value = decoded.value;
          span.point.lastError = "";
        }
      } catch (error) {
        lastBlockError = error;
        for (const span of block.spans) {
          span.point.raw = null;
          span.point.value = null;
          span.point.lastError = error.message;
        }
        if (state.mode === "rtu" && successfulBlocks === 0 && isRecoverableRtuError(error)) {
          for (const point of device.points) {
            point.raw = null;
            point.value = null;
            point.lastError = error.message;
          }
          throw error;
        }
      }
    }
  }
  if (successfulBlocks === 0 && lastBlockError) throw lastBlockError;
  device.lastLatencyMs = latencyMs;
  device.lastReadAt = new Date();
  device.lastError = "";
}

async function refreshDevice(device, options = {}) {
  const covMode = options.covMode === true;
  const silent = options.silent === true;
  const previousValues = covMode ? captureDeviceCovValues(device) : null;
  const previousError = device.lastError;
  const previousReadAt = device.lastReadAt;
  state.requests += 1;
  try {
    let lastError = null;
    const attempts = state.mode === "rtu" ? 1 : 2;
    for (let attempt = 1; attempt <= attempts; attempt += 1) {
      try {
        await readDevice(device);
        lastError = null;
        break;
      } catch (error) {
        lastError = error;
        const recoverable = /transaction mismatch|ID mismatch|unit id mismatch|timeout|timed out/i.test(error.message);
        if (!recoverable) break;
        await sleep(180 + attempt * 40);
      }
    }
    if (lastError) throw lastError;
  } catch (error) {
    state.errors += 1;
    device.lastError = error.message;
  }
  updateStats();
  const valuesChanged = covMode ? deviceCovChanged(previousValues, device) : true;
  const statusChanged = covMode
    ? previousError !== device.lastError || (!previousReadAt && !!device.lastReadAt)
    : true;
  if (silent) {
    updateDeviceCardLiveData(device);
  } else if (!covMode || valuesChanged || statusChanged) {
    renderDevicesPreservingScroll();
  }
  return valuesChanged || statusChanged;
}

async function refreshAllDevices(options = {}) {
  if (state.devices.length === 0) return;
  const monitorMode = options.monitor === true;
  if (monitorMode && state.deviceMonitorRefreshRunning) return;
  if (!monitorMode && state.deviceRefreshRunning) return;
  if (
    monitorMode
    && state.mode === "rtu"
    && state.rtuMonitorRetryAt > Date.now()
  ) return;
  if (monitorMode) {
    state.deviceMonitorRefreshRunning = true;
  } else {
    state.deviceRefreshRunning = true;
  }
  updateDeviceControls();
  try {
    for (const device of state.devices) {
      if (monitorMode && !state.deviceMonitoring) break;
      if (state.writeInProgress) break;
      if (monitorMode && hasQueuedWrite()) break;
      if (!state.connected) break;
      if (monitorMode && (device.nextMonitorAt || 0) > Date.now()) continue;
      const changed = await refreshDevice(device, {
        covMode: monitorMode && covModeEnabled(),
        silent: monitorMode
      });
      if (monitorMode) {
        device.nextMonitorAt = Date.now() + intervalMsFromValue(device.intervalMs, 1000, "ms");
      }
      if (monitorMode && covModeEnabled() && changed && !options.silentLog) {
        log(`COV changed: ${device.name}.`);
      }
      if (
        monitorMode
        && state.mode === "rtu"
        && state.rtuFailureCount >= RTU_LINE_FAILURE_THRESHOLD
      ) break;
      await sleep(monitorMode ? 180 : 80);
    }
    if (!monitorMode) {
      log(`Device monitor refreshed ${state.devices.length} profile(s).`);
    }
  } finally {
    if (monitorMode) {
      state.deviceMonitorRefreshRunning = false;
    } else {
      state.deviceRefreshRunning = false;
    }
    updateDeviceControls();
  }
}

function deviceMonitorDelay() {
  if (state.devices.length === 0) return 1000;
  const now = Date.now();
  if (state.mode === "rtu" && state.rtuMonitorRetryAt > now) {
    return Math.max(300, state.rtuMonitorRetryAt - now);
  }
  const nextDueAt = Math.min(...state.devices.map((device) => device.nextMonitorAt || 0));
  if (nextDueAt <= now) return 300;
  return Math.min(60000, Math.max(300, nextDueAt - now));
}

function scheduleDeviceMonitor(delayMs = 0) {
  if (!state.deviceMonitoring) return;
  if (state.deviceMonitorTimer) {
    window.clearTimeout(state.deviceMonitorTimer);
  }
  state.deviceMonitorTimer = window.setTimeout(async () => {
    state.deviceMonitorTimer = null;
    if (!state.deviceMonitoring) return;
    await refreshAllDevices({ monitor: true, silentLog: true });
    if (state.deviceMonitoring) {
      scheduleDeviceMonitor(deviceMonitorDelay());
    }
  }, delayMs);
}

function startDeviceMonitor() {
  if (state.deviceMonitoring || state.devices.length === 0) return;
  state.deviceMonitoring = true;
  state.devices.forEach((device) => {
    device.nextMonitorAt = 0;
  });
  updateDeviceControls();
  scheduleDeviceMonitor(0);
  log(covModeEnabled()
    ? "COV monitor started. Cards update only when point values change."
    : "Device monitor started.");
}

function stopDeviceMonitor() {
  state.deviceMonitoring = false;
  if (state.deviceMonitorTimer) {
    window.clearTimeout(state.deviceMonitorTimer);
    state.deviceMonitorTimer = null;
  }
  updateDeviceControls();
  log("Device monitor stopped.");
}

function loadDeviceIntoRead(device) {
  if (device.points.length === 0) {
    log(`${device.name} has no points to load.`);
    return;
  }
  const functionCode = pointFunctionCode(device.points[0], device);
  const points = device.points.filter((point) => pointFunctionCode(point, device) === functionCode);
  const block = buildPointReadBlocks(points, device, functionCode)[0];
  if (!block) return;
  els.unitId.value = device.id;
  els.readFunction.value = String(functionCode);
  els.readAddress.value = block.start;
  els.readQuantity.value = block.end - block.start + 1;
  const firstPoint = points[0];
  if (firstPoint) {
    if (els.readType) els.readType.value = normalizePointType(firstPoint.type);
    if (els.readWordOrder) els.readWordOrder.value = firstPoint.wordOrder === "swap" ? "swap" : "be";
  }
  updateReadDecodeControls();
  if (state.mode === "tcp" && device.tcpHost) {
    els.tcpHost.value = device.tcpHost;
    els.tcpPort.value = Number.parseInt(device.tcpPort || 502, 10);
  }
  setActiveTab("poll");
  log(`Loaded ${device.name} ${READ_FUNCTIONS[functionCode]} into Read Function.`);
}

function wordOrderLabel(order) {
  return order === "swap" ? "CDAB / GHEFCDAB" : "ABCD / ABCDEFGH";
}

function updateReadDecodeControls() {
  if (!els.readType || !els.readWordOrder || !els.readQuantity) return;
  const functionCode = Number.parseInt(els.readFunction.value || "3", 10);
  const isBit = functionCode === 1 || functionCode === 2;
  els.readType.disabled = isBit;
  els.readWordOrder.disabled = isBit;
  if (isBit) {
    els.readQuantity.min = "1";
    return;
  }
  const minQuantity = registersForType(els.readType.value);
  els.readQuantity.min = String(minQuantity);
  if (readNumber(els.readQuantity, minQuantity, 1, 125) < minQuantity) {
    els.readQuantity.value = String(minQuantity);
  }
}

function renderPollValues(result) {
  els.pollBody.innerHTML = "";
  const isBit = result.functionCode === 1 || result.functionCode === 2;
  const type = isBit ? "bit" : normalizePointType(result.type || els.readType?.value);
  const wordOrder = result.wordOrder
    ? result.wordOrder === "swap" ? "swap" : "be"
    : els.readWordOrder?.value === "swap" ? "swap" : "be";
  const registers = isBit ? 1 : registersForType(type);

  for (let index = 0; index < result.values.length; index += registers) {
    const address = result.startAddress + index;
    const words = result.values.slice(index, index + registers);
    const addressText = registers > 1 ? `${address}-${address + registers - 1}` : String(address);
    const decoded = isBit
      ? { raw: words[0], value: words[0] ? "ON" : "OFF" }
      : words.length < registers
        ? { raw: null, value: null }
        : decodePointValue({ address, type, wordOrder, scale: 1, unit: "" }, result.values, result.startAddress, result.functionCode);
    const rawText = isBit ? String(words[0]) : words.map((word) => String(word)).join(", ");
    const hexText = isBit
      ? (words[0] ? "ON" : "OFF")
      : words.map((word) => `0x${(Number(word) & 0xffff).toString(16).toUpperCase().padStart(4, "0")}`).join(" ");
    const valueText = decoded.value === null || decoded.value === undefined
      ? "-"
      : typeof decoded.value === "string"
        ? decoded.value
        : formatDataValue(decoded.value);
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${escapeHtml(addressText)}</td>
      <td>${escapeHtml(isBit ? "bit" : pointTypeLabel({ type }))}</td>
      <td>${escapeHtml(isBit ? "-" : wordOrderLabel(wordOrder))}</td>
      <td>${escapeHtml(rawText)}</td>
      <td>${escapeHtml(valueText)}</td>
      <td>${escapeHtml(hexText)}</td>
    `;
    els.pollBody.append(row);
  }
}

function crc16Modbus(bytes) {
  let crc = 0xffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit += 1) {
      const lsb = crc & 1;
      crc >>= 1;
      if (lsb) crc ^= 0xa001;
    }
  }
  return crc;
}

function appendCrc(frameWithoutCrc) {
  const frame = new Uint8Array(frameWithoutCrc.length + 2);
  frame.set(frameWithoutCrc);
  const crc = crc16Modbus(frameWithoutCrc);
  frame[frame.length - 2] = crc & 0xff;
  frame[frame.length - 1] = (crc >> 8) & 0xff;
  return frame;
}

function buildReadRequest(unitId, functionCode, startAddress, quantity) {
  return appendCrc(
    new Uint8Array([
      unitId,
      functionCode,
      (startAddress >> 8) & 0xff,
      startAddress & 0xff,
      (quantity >> 8) & 0xff,
      quantity & 0xff
    ])
  );
}

function packCoils(values) {
  const bytes = new Uint8Array(Math.ceil(values.length / 8));
  values.forEach((value, index) => {
    if (value) {
      bytes[Math.floor(index / 8)] |= 1 << (index % 8);
    }
  });
  return bytes;
}

function buildWriteRequest(unitId, functionCode, address, values) {
  if (functionCode === 5 || functionCode === 6) {
    const value = functionCode === 5 ? (values[0] ? 0xff00 : 0x0000) : values[0];
    return appendCrc(
      new Uint8Array([
        unitId,
        functionCode,
        (address >> 8) & 0xff,
        address & 0xff,
        (value >> 8) & 0xff,
        value & 0xff
      ])
    );
  }

  if (functionCode === 15) {
    const coils = values.map((value) => (value ? 1 : 0));
    const packed = packCoils(coils);
    const frame = new Uint8Array(7 + packed.length);
    frame.set([
      unitId,
      functionCode,
      (address >> 8) & 0xff,
      address & 0xff,
      (coils.length >> 8) & 0xff,
      coils.length & 0xff,
      packed.length
    ]);
    frame.set(packed, 7);
    return appendCrc(frame);
  }

  if (functionCode === 16) {
    const frame = new Uint8Array(7 + values.length * 2);
    frame.set([
      unitId,
      functionCode,
      (address >> 8) & 0xff,
      address & 0xff,
      (values.length >> 8) & 0xff,
      values.length & 0xff,
      values.length * 2
    ]);
    values.forEach((value, index) => {
      frame[7 + index * 2] = (value >> 8) & 0xff;
      frame[8 + index * 2] = value & 0xff;
    });
    return appendCrc(frame);
  }

  throw new Error("Unsupported write function.");
}

function expectedReadLength(functionCode, quantity) {
  if (functionCode === 1 || functionCode === 2) {
    return 5 + Math.ceil(quantity / 8);
  }
  return 5 + quantity * 2;
}

function verifyRtuResponse(frame, unitId, functionCode) {
  if (frame.length < 5) {
    throw new Error("short frame");
  }

  const receivedCrc = frame[frame.length - 2] | (frame[frame.length - 1] << 8);
  const actualCrc = crc16Modbus(frame.slice(0, -2));
  if (receivedCrc !== actualCrc) {
    throw new Error("CRC mismatch");
  }
  if (frame[0] !== unitId) {
    throw new Error("ID mismatch");
  }
  if (frame[1] === (functionCode | 0x80)) {
    throw new Error(`exception ${frame[2]}`);
  }
  if (frame[1] !== functionCode) {
    throw new Error("function mismatch");
  }
}

function parseReadValues(frame, functionCode, quantity) {
  const byteCount = frame[2];
  const payload = frame.slice(3, 3 + byteCount);

  if (functionCode === 1 || functionCode === 2) {
    return Array.from({ length: quantity }, (_, index) => {
      const byte = payload[Math.floor(index / 8)];
      return (byte >> (index % 8)) & 1;
    });
  }

  const values = [];
  for (let index = 0; index < payload.length; index += 2) {
    values.push((payload[index] << 8) | payload[index + 1]);
  }
  return values;
}

function sleep(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function hasQueuedWrite() {
  return state.modbusQueue.some((job) => job.type === "write");
}

function enqueueModbusJob(type, task) {
  return new Promise((resolve, reject) => {
    state.modbusQueue.push({ type, task, resolve, reject });
    processModbusQueue();
  });
}

async function processModbusQueue() {
  if (state.modbusQueueRunning) return;
  state.modbusQueueRunning = true;

  while (state.modbusQueue.length) {
    const writeIndex = state.modbusQueue.findIndex((job) => job.type === "write");
    const job = state.modbusQueue.splice(writeIndex >= 0 ? writeIndex : 0, 1)[0];
    const isWriteJob = job.type === "write";
    state.writeInProgress = isWriteJob;
    if (isWriteJob) updateDeviceControls();
    try {
      const result = await job.task();
      job.resolve(result);
    } catch (error) {
      job.reject(error);
    } finally {
      if (job.type === "write") {
        await sleep(350);
      }
      state.writeInProgress = false;
      if (isWriteJob) updateDeviceControls();
    }
  }

  state.modbusQueueRunning = false;
}

function requestRead(config) {
  return enqueueModbusJob("read", () => (
    state.mode === "tcp" ? readTcp(config) : requestRtuWithRecovery(config)
  ));
}

function requestWrite(config) {
  return enqueueModbusJob("write", () => (
    state.mode === "tcp" ? writeTcp(config) : writeRtu(config)
  ));
}

async function requestWriteWithRetry(config, attempts = 2) {
  let lastError = null;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      return await requestWrite(config);
    } catch (error) {
      lastError = error;
      const retryable = /timeout|timed out|forcibly closed|connection reset|network|failed to fetch/i.test(error.message);
      if (!retryable || attempt === attempts) break;
      await sleep(180 + attempt * 120);
    }
  }
  throw lastError;
}

async function startReadLoop(reader = state.reader) {
  state.readerActive = true;
  try {
    while (state.readerActive && state.reader === reader) {
      try {
        const { value, done } = await reader.read();
        if (done) break;
        if (value) {
          state.readBuffer.push(...value);
          if (state.readBuffer.length > RTU_MAX_BUFFER_BYTES) {
            state.readBuffer.splice(0, state.readBuffer.length - RTU_MAX_BUFFER_BYTES);
          }
        }
      } catch (error) {
        if (state.readerActive && state.reader === reader) {
          log(`Read warning: ${error.message}`);
        }
        break;
      }
    }
  } finally {
    if (state.reader === reader) {
      state.readerActive = false;
    }
  }
}

function rtuSilentIntervalMs() {
  const baudRate = Math.max(1, Number.parseInt(els.baudRate.value, 10) || 9600);
  const dataBits = Number.parseInt(els.dataBits.value, 10) || 8;
  const stopBits = Number.parseInt(els.stopBits.value, 10) || 1;
  const parityBits = els.parity.value === "none" ? 0 : 1;
  const bitsPerCharacter = 1 + dataBits + parityBits + stopBits;
  return Math.max(5, Math.ceil((bitsPerCharacter * 3.5 * 1000) / baudRate));
}

function rtuRecoveryDelayMs() {
  return Math.min(250, Math.max(80, rtuSilentIntervalMs() * 4));
}

async function settleRtuBus(delayMs) {
  state.readBuffer = [];
  await sleep(delayMs);
  state.readBuffer = [];
}

function hasValidRtuCrc(frame) {
  if (frame.length < 5) return false;
  const receivedCrc = frame[frame.length - 2] | (frame[frame.length - 1] << 8);
  return receivedCrc === crc16Modbus(frame.slice(0, -2));
}

function extractValidRtuFrame(unitId, functionCode, expectedLength) {
  const exceptionFunction = functionCode | 0x80;

  while (state.readBuffer.length >= 2) {
    let startIndex = -1;
    for (let index = 0; index < state.readBuffer.length - 1; index += 1) {
      if (
        state.readBuffer[index] === unitId
        && (state.readBuffer[index + 1] === functionCode || state.readBuffer[index + 1] === exceptionFunction)
      ) {
        startIndex = index;
        break;
      }
    }

    if (startIndex < 0) {
      state.readBuffer = state.readBuffer.at(-1) === unitId ? [unitId] : [];
      return null;
    }
    if (startIndex > 0) state.readBuffer.splice(0, startIndex);

    const exceptionResponse = state.readBuffer[1] === exceptionFunction;
    let frameLength = exceptionResponse ? 5 : expectedLength;
    if (!exceptionResponse && functionCode >= 1 && functionCode <= 4) {
      if (state.readBuffer.length < 3) return null;
      frameLength = 5 + state.readBuffer[2];
      if (frameLength !== expectedLength) {
        state.readBuffer.splice(0, 1);
        continue;
      }
    }

    if (state.readBuffer.length < frameLength) return null;
    const candidate = new Uint8Array(state.readBuffer.slice(0, frameLength));
    if (hasValidRtuCrc(candidate)) {
      state.readBuffer.splice(0, frameLength);
      return candidate;
    }
    state.readBuffer.splice(0, 1);
  }
  return null;
}

async function readRtuFrame(timeoutMs, unitId, functionCode, expectedLength) {
  const startedAt = performance.now();
  let sawSerialData = state.readBuffer.length > 0;

  while (performance.now() - startedAt < timeoutMs) {
    sawSerialData ||= state.readBuffer.length > 0;
    const frame = extractValidRtuFrame(unitId, functionCode, expectedLength);
    if (frame) return frame;
    await sleep(10);
  }

  throw new Error(sawSerialData ? "invalid or incomplete frame" : "timeout");
}

function isRecoverableRtuError(error) {
  return /timeout|incomplete frame|invalid frame|CRC mismatch|ID mismatch|function mismatch|short frame|framing|parity|overrun/i.test(
    shortError(error)
  );
}

function rtuMonitorBackoffMs() {
  const timeoutMs = readSecondsAsMs(els.timeoutMs, 1000, 100, 10000);
  return Math.min(RTU_MONITOR_BACKOFF_MAX_MS, Math.max(500, timeoutMs));
}

function markRtuWaiting(error) {
  const firstFailure = state.rtuFailureCount === 0;
  state.rtuFailureCount += 1;
  if (firstFailure) {
    setBadge(els.connectionBadge, "RS485 waiting", "error");
    setConnectionDetail(
      `USB serial remains connected, but no valid Modbus reply was received (${shortError(error)}). The next read will retry automatically.`,
      "error"
    );
    log("RS485 reply lost. Keeping the COM port open and waiting for the device to return.");
  }
  if (state.rtuFailureCount >= RTU_LINE_FAILURE_THRESHOLD) {
    state.rtuMonitorRetryAt = Date.now() + rtuMonitorBackoffMs();
  }
}

function markRtuRecovered() {
  if (state.rtuFailureCount === 0) return;
  const failedRequests = state.rtuFailureCount;
  state.rtuFailureCount = 0;
  state.rtuMonitorRetryAt = 0;
  setBadge(els.connectionBadge, "Connected", "live");
  setConnectionDetail("RS485 communication restored automatically; the USB serial port stayed open.", "ok");
  log(`RS485 communication restored after ${failedRequests} failed attempt(s).`);
}

async function requestRtuWithRecovery(config) {
  const attempts = Math.max(
    1,
    Number.parseInt(config.rtuRecoveryAttempts ?? RTU_DEFAULT_RECOVERY_ATTEMPTS, 10) || 1
  );
  let lastError = null;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      const result = await requestRtu(config);
      markRtuRecovered();
      return result;
    } catch (error) {
      lastError = error;
      const recoverable = isRecoverableRtuError(error);
      if (!recoverable || attempt === attempts) {
        if (!config.suppressRtuStatus && recoverable) markRtuWaiting(error);
        break;
      }
      await settleRtuBus(rtuRecoveryDelayMs());
    }
  }
  throw lastError;
}

async function requestRtu(config) {
  if (!state.connected || !state.writer || !state.readerActive) {
    throw new Error("Serial stream is inactive. Reconnect the USB serial port.");
  }
  const request = buildReadRequest(
    config.unitId,
    config.functionCode,
    config.startAddress,
    config.quantity
  );
  const startedAt = performance.now();
  await settleRtuBus(rtuSilentIntervalMs());
  await state.writer.write(request);
  const response = await readRtuFrame(
    config.timeoutMs,
    config.unitId,
    config.functionCode,
    expectedReadLength(config.functionCode, config.quantity)
  );
  verifyRtuResponse(response, config.unitId, config.functionCode);
  return {
    unitId: config.unitId,
    functionCode: config.functionCode,
    startAddress: config.startAddress,
    values: parseReadValues(response, config.functionCode, config.quantity),
    latencyMs: Math.round(performance.now() - startedAt)
  };
}

async function writeRtu(config) {
  if (!state.connected || !state.writer || !state.readerActive) {
    throw new Error("Serial stream is inactive. Reconnect the USB serial port.");
  }
  const request = buildWriteRequest(config.unitId, config.functionCode, config.address, config.values);
  const startedAt = performance.now();
  await settleRtuBus(rtuSilentIntervalMs());
  await state.writer.write(request);
  const response = await readRtuFrame(config.timeoutMs, config.unitId, config.functionCode, 8);
  verifyRtuResponse(response, config.unitId, config.functionCode);
  return { latencyMs: Math.round(performance.now() - startedAt) };
}

async function readApiPayload(response) {
  const text = await response.text();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}

async function readTcp(config) {
  const response = await fetch("/api/tcp/read", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      host: state.tcpTarget.host,
      port: state.tcpTarget.port,
      unitId: config.unitId,
      functionCode: config.functionCode,
      startAddress: config.startAddress,
      quantity: config.quantity,
      timeoutMs: config.timeoutMs
    })
  });
  const payload = await readApiPayload(response);
  if (!response.ok) {
    if (response.status === 404 || response.status === 501) {
      throw new Error("TCP API is not active. Restart the app with python -m project_o.cli serve.");
    }
    throw new Error(payload.error || "TCP read failed");
  }
  return payload;
}

async function checkTcpConnection(config) {
  const response = await fetch("/api/tcp/connect", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      host: config.tcpHost,
      port: config.tcpPort,
      timeoutMs: config.timeoutMs
    })
  });
  const payload = await readApiPayload(response);
  if (!response.ok) {
    if (response.status === 404 || response.status === 501) {
      throw new Error("TCP connection check is not active. Restart the app server.");
    }
    throw new Error(payload.error || "TCP connection failed");
  }
  return payload;
}

async function probeTcpModbus(config) {
  const functionCode = Number.parseInt(els.readFunction.value || "3", 10);
  const response = await fetch("/api/tcp/read", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      host: config.tcpHost,
      port: config.tcpPort,
      unitId: readNumber(els.unitId, 1, 1, 247),
      functionCode,
      startAddress: readNumber(els.readAddress, 0, 0, 65535),
      quantity: readNumber(els.readQuantity, 1, 1, functionCode === 1 || functionCode === 2 ? 2000 : 125),
      timeoutMs: config.timeoutMs
    })
  });
  const payload = await readApiPayload(response);
  if (!response.ok) {
    throw new Error(payload.error || "Modbus probe failed");
  }
  return payload;
}

async function writeTcp(config) {
  const response = await fetch("/api/tcp/write", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      host: state.tcpTarget.host,
      port: state.tcpTarget.port,
      unitId: config.unitId,
      functionCode: config.functionCode,
      address: config.address,
      values: config.values,
      timeoutMs: config.timeoutMs
    })
  });
  const payload = await readApiPayload(response);
  if (!response.ok) {
    if (response.status === 404 || response.status === 501) {
      throw new Error("TCP API is not active. Restart the app with python -m project_o.cli serve.");
    }
    throw new Error(payload.error || "TCP write failed");
  }
  return payload;
}

function serialPortIsOpen(port) {
  return Boolean(port?.readable || port?.writable);
}

async function releaseSerialResources({ port = null, reader = null, writer = null, readLoopPromise = null } = {}) {
  const warnings = [];
  state.readerActive = false;

  if (reader) {
    try {
      await reader.cancel();
    } catch (error) {
      warnings.push(`reader cancel: ${shortError(error)}`);
    }
  }

  if (readLoopPromise) {
    try {
      await Promise.race([readLoopPromise, sleep(1000)]);
    } catch (error) {
      warnings.push(`read loop: ${shortError(error)}`);
    }
  }

  if (reader) {
    try {
      reader.releaseLock();
    } catch (error) {
      warnings.push(`reader unlock: ${shortError(error)}`);
    }
  }

  if (writer) {
    try {
      writer.releaseLock();
    } catch (releaseError) {
      try {
        await writer.abort("Serial connection closed");
        writer.releaseLock();
      } catch (abortError) {
        warnings.push(`writer unlock: ${shortError(abortError || releaseError)}`);
      }
    }
  }

  if (port && serialPortIsOpen(port)) {
    try {
      await port.close();
    } catch (error) {
      warnings.push(`port close: ${shortError(error)}`);
    }
  }

  return warnings;
}

function cancelQueuedModbusJobs(message = "Serial connection closed") {
  const queuedJobs = state.modbusQueue.splice(0);
  for (const job of queuedJobs) {
    job.reject(new Error(message));
  }
}

async function connectSerial() {
  if (!("serial" in navigator)) {
    setBadge(els.supportBadge, "Web Serial unavailable", "error");
    setConnectionDetail("Web Serial is unavailable. Use Chrome or Edge on localhost.", "error");
    log("This browser does not support Web Serial. Use Chrome or Edge on localhost.");
    return;
  }

  if (state.serialConnecting || state.serialClosing) return;
  state.serialConnecting = true;
  els.connectBtn.disabled = true;
  let selectedPort = null;

  try {
    if (state.port || state.reader || state.writer) {
      await disconnectSerial({ announce: false, detail: "Preparing the serial port..." });
    }

    setConnectionDetail("Select a serial port for Modbus RTU.", "idle");
    selectedPort = await navigator.serial.requestPort();
    if (serialPortIsOpen(selectedPort)) {
      setConnectionDetail("Recovering the previously opened serial port...", "idle");
      const recoveryWarnings = await releaseSerialResources({ port: selectedPort });
      if (recoveryWarnings.length) {
        log(`Serial recovery warning: ${recoveryWarnings.join("; ")}.`);
      }
      if (serialPortIsOpen(selectedPort)) {
        throw new Error("The serial port is busy in another browser tab. Close that tab and connect again.");
      }
      await sleep(100);
    }

    state.port = selectedPort;
    await selectedPort.open({
      baudRate: Number.parseInt(els.baudRate.value, 10),
      dataBits: Number.parseInt(els.dataBits.value, 10),
      stopBits: Number.parseInt(els.stopBits.value, 10),
      parity: els.parity.value,
      bufferSize: 255,
      flowControl: "none"
    });

    if (!selectedPort.readable || !selectedPort.writable) {
      throw new Error("The serial port did not provide readable and writable streams.");
    }
    state.reader = selectedPort.readable.getReader();
    state.writer = selectedPort.writable.getWriter();
    state.readBuffer = [];
    state.rtuFailureCount = 0;
    state.rtuMonitorRetryAt = 0;
    state.readLoopPromise = startReadLoop(state.reader);
    setConnected(true);
    setConnectionDetail(`RTU serial connected at ${els.baudRate.value} baud.`, "ok");
    log(`RTU serial connected at ${els.baudRate.value} baud.`);
    renderDevicesPreservingScroll();
  } catch (error) {
    const cleanupWarnings = await releaseSerialResources({
      port: state.port || selectedPort,
      reader: state.reader,
      writer: state.writer,
      readLoopPromise: state.readLoopPromise
    });
    state.port = null;
    state.reader = null;
    state.writer = null;
    state.readLoopPromise = null;
    state.readBuffer = [];
    state.rtuFailureCount = 0;
    state.rtuMonitorRetryAt = 0;
    const message = /already open/i.test(shortError(error))
      ? "The serial port was already open. Alto Tools released it; click Connect again without unplugging USB."
      : shortError(error);
    setConnectionDetail(`RTU connection failed: ${message}`, "error");
    log(`Connection failed: ${message}`);
    if (cleanupWarnings.length) {
      log(`Serial cleanup warning: ${cleanupWarnings.join("; ")}.`);
    }
    setConnected(false);
  } finally {
    state.serialConnecting = false;
    if (!state.connected) els.connectBtn.disabled = false;
  }
}

async function disconnectSerial({ announce = true, detail = "No target selected." } = {}) {
  if (state.serialClosing) return;
  state.serialClosing = true;
  stopPolling();
  stopDeviceMonitor();
  state.scanning = false;
  els.stopBtn.disabled = true;
  cancelQueuedModbusJobs();
  setConnected(false);

  const resources = {
    port: state.port,
    reader: state.reader,
    writer: state.writer,
    readLoopPromise: state.readLoopPromise
  };

  try {
    const warnings = await releaseSerialResources(resources);
    if (warnings.length) {
      log(`Disconnect warning: ${warnings.join("; ")}.`);
    }
  } finally {
    state.port = null;
    state.reader = null;
    state.writer = null;
    state.readLoopPromise = null;
    state.readBuffer = [];
    state.rtuFailureCount = 0;
    state.rtuMonitorRetryAt = 0;
    state.serialClosing = false;
    if (detail !== null) setConnectionDetail(detail, "idle");
    if (announce) log("Disconnected.");
    renderDevicesPreservingScroll();
  }
}

async function connectTcpTarget() {
  const config = getBaseConfig();
  if (!config.tcpHost) {
    log("TCP host is required.");
    setConnectionDetail("TCP host is required.", "error");
    return;
  }
  await checkBackend();
  if (!state.backendReady) {
    log("TCP API is inactive. Run the app with run-app.bat or python -m project_o.cli serve.");
    setBadge(els.supportBadge, "TCP API inactive", "error");
    setConnectionDetail("TCP API is inactive. Restart the app server.", "error");
    return;
  }

  els.connectBtn.disabled = true;
  setBadge(els.connectionBadge, "Checking...", "neutral");
  setConnectionDetail(`Checking TCP ${config.tcpHost}:${config.tcpPort} and Modbus response...`, "idle");
  try {
    const result = await checkTcpConnection(config);
    state.tcpTarget = { host: config.tcpHost, port: config.tcpPort };
    state.selectedGateway = { host: config.tcpHost, port: config.tcpPort };
    renderGatewayResults();
    syncDevicesToTcpTarget(config.tcpHost, config.tcpPort);
    try {
      const probe = await probeTcpModbus(config);
      setConnected(true, `Modbus OK ${config.tcpHost}`);
      setConnectionDetail(
        `TCP OK ${formatDurationSec(result.latencyMs)}. Modbus ID ${probe.unitId} ${READ_FUNCTIONS[probe.functionCode]} address ${probe.startAddress} OK (${formatDurationSec(probe.latencyMs)}).`,
        "ok"
      );
      log(`TCP and Modbus probe OK: ${config.tcpHost}:${config.tcpPort}, ID ${probe.unitId} (${formatDurationSec(probe.latencyMs)}).`);
    } catch (probeError) {
      setConnected(true, `TCP OK / Modbus failed`);
      setBadge(els.connectionBadge, "TCP OK / Modbus failed", "error");
      setConnectionDetail(
        `TCP socket OK ${formatDurationSec(result.latencyMs)}, but Modbus probe failed: ${shortError(probeError)}. You can still scan IDs from Device Scan.`,
        "warn"
      );
      log(`TCP connected, but Modbus probe failed: ${shortError(probeError)}.`);
    }
  } catch (error) {
    state.tcpTarget = null;
    setConnected(false);
    setBadge(els.connectionBadge, "Connect failed", "error");
    setConnectionDetail(`TCP connection failed: ${shortError(error)}`, "error");
    log(`TCP connection failed: ${shortError(error)}`);
  }
}

function disconnectTcpTarget() {
  stopPolling();
  stopDeviceMonitor();
  state.scanning = false;
  state.tcpTarget = null;
  if (state.tcpAbortController) {
    state.tcpAbortController.abort();
  }
  setConnected(false);
  setConnectionDetail("No target selected.", "idle");
  log("TCP target cleared.");
}

async function refreshTcpTargetForScan(config) {
  if (config.mode !== "tcp") return true;
  if (!config.tcpHost) {
    setConnected(false);
    setConnectionDetail("TCP host is required.", "error");
    log("TCP scan failed: Host/IP is required.");
    return false;
  }

  await checkBackend();
  if (!state.backendReady) {
    setBadge(els.supportBadge, "TCP API inactive", "error");
    setConnectionDetail("TCP API is inactive. Restart the app server.", "error");
    log("TCP scan failed: TCP API is inactive.");
    return false;
  }

  const previous = state.tcpTarget;
  const changed = !previous
    || previous.host !== config.tcpHost
    || Number.parseInt(previous.port || 502, 10) !== config.tcpPort;
  state.tcpTarget = { host: config.tcpHost, port: config.tcpPort };
  state.selectedGateway = { host: config.tcpHost, port: config.tcpPort };
  setConnected(true, `Target ${config.tcpHost}`);
  setBadge(els.connectionBadge, "Ready", "ready");
  setConnectionDetail(`Scan target refreshed: ${config.tcpHost}:${config.tcpPort}.`, "ok");
  if (changed) {
    renderGatewayResults();
    syncDevicesToTcpTarget(config.tcpHost, config.tcpPort);
    log(`Scan target refreshed to ${config.tcpHost}:${config.tcpPort}.`);
  }
  return true;
}

async function readOnce() {
  const config = getReadConfig();
  state.requests += 1;
  updateStats();
  try {
    const result = await requestRead(config);
    renderPollValues({ ...result, type: config.type, wordOrder: config.wordOrder });
    setBadge(els.lastPollBadge, `Read ${result.values.length} value(s) in ${formatDurationSec(result.latencyMs)}`, "live");
    log(`Read ${READ_FUNCTIONS[config.functionCode]} from ID ${config.unitId}, address ${config.startAddress}.`);
  } catch (error) {
    state.errors += 1;
    updateStats();
    setBadge(els.lastPollBadge, "Read failed", "error");
    log(`Read failed: ${error.message}`);
    throw error;
  }
}

async function startPolling() {
  if (state.polling) return;
  state.polling = true;
  els.pollBtn.disabled = true;
  els.stopPollBtn.disabled = false;
  els.scanState.textContent = "Polling";
  log("Polling started.");

  while (state.polling) {
    try {
      await readOnce();
    } catch {
      // The read function already logs the error; keep polling like Modbus Poll does.
    }
    await sleep(readSecondsAsMs(els.pollRate, 1000, 200, 60000));
  }
}

function stopPolling() {
  if (!state.polling) return;
  state.polling = false;
  els.pollBtn.disabled = !state.connected;
  els.stopPollBtn.disabled = true;
  els.scanState.textContent = "Ready";
  log("Polling stopped.");
}

async function writeValue() {
  try {
    const config = getWriteConfig();
    state.requests += 1;
    updateStats();
    const result = await requestWriteWithRetry(config);
    log(`${WRITE_FUNCTIONS[config.functionCode]} at address ${config.address} completed in ${formatDurationSec(result.latencyMs)}.`);
  } catch (error) {
    state.errors += 1;
    updateStats();
    log(`Write failed: ${error.message}`);
  }
}

async function writeDevicePoint(device, pointIndex, button) {
  const point = device.points[pointIndex];
  if (!point) return;
  if (!pointControlEnabled(point, device)) {
    log(`${point.name} on ${device.name} is read-only.`);
    updateDeviceCardLiveData(device, { forceControlRender: true });
    return;
  }
  const functionCode = writableFunctionCode(point, device);
  if (!functionCode) {
    log(`${point.name} is read-only. Use 01 Coils or 03 Holding registers for controls.`);
    return;
  }
  if (!state.connected) {
    log("Connect before writing a control.");
    return;
  }
  if (button.disabled || button.dataset.busy === "1") return;
  const row = button.closest("tr");
  const forcedValue = button.dataset.controlValue ?? null;
  const controlValue = String(
    forcedValue ?? row?.querySelector("[data-control-value]")?.value ?? point.controlValue ?? ""
  ).trim();
  button.dataset.busy = "1";
  button.disabled = true;
  try {
    const values = readPointControlValue(row, point, device, forcedValue);
    const config = {
      ...getDeviceBaseConfig(device),
      unitId: device.id,
      functionCode,
      address: point.address,
      values
    };
    state.requests += 1;
    updateStats();
    const result = await requestWriteWithRetry(config);
    const writtenValue = controlValue || String(values[0] ?? "");
    point.controlValue = writtenValue;
    if (functionCode === 5) {
      point.raw = values[0] ?? null;
      point.value = point.raw;
    } else {
      const decoded = decodePointValue(point, values, point.address, 3);
      point.raw = decoded.raw;
      point.value = decoded.value;
    }
    setPointWriteStatus(device, point, "ok", "Write success");
    device.lastError = "";
    device.lastReadAt = Date.now();
    device.lastLatencyMs = result.latencyMs;
    updateDeviceCardLiveData(device, { forceControlRender: true });
    await refreshDevice(device, { silent: true });
    log(`Wrote ${point.name} on ${device.name}: ${writtenValue} (${WRITE_FUNCTIONS[functionCode]}).`);
  } catch (error) {
    state.errors += 1;
    updateStats();
    setPointWriteStatus(device, point, "error", "Write failed");
    device.lastError = error.message;
    updateDeviceCardLiveData(device, { forceControlRender: true });
    log(`Control write failed for ${device.name} ${point.name}: ${error.message}`);
  } finally {
    button.dataset.busy = "0";
  }
}

function addScanResult(result) {
  state.results.unshift(result);
  scheduleScanResultsRender();
}

async function scanRtu(config) {
  state.scanning = true;
  els.scanBtn.disabled = true;
  els.stopBtn.disabled = false;
  els.scanState.textContent = `Scanning IDs ${config.from}-${config.to}`;
  const probes = buildScanProbes(config);
  const scanLabel = config.functionCode === "all" ? "Auto 01/02/03/04" : READ_FUNCTIONS[config.functionCode];
  log(`Scan started: IDs ${config.from}-${config.to}, ${scanLabel}, address ${config.addresses.join(", ")}.`);
  const total = (config.to - config.from + 1) * probes.length;
  let done = 0;
  updateScanProgress(0, total, config.from);

  for (let unitId = config.from; unitId <= config.to; unitId += 1) {
    if (!state.scanning) break;

    for (let probeIndex = 0; probeIndex < probes.length; probeIndex += 1) {
      const { functionCode, startAddress } = probes[probeIndex];
      if (!state.scanning) break;
      state.requests += 1;
      const startedAt = performance.now();
      try {
        const reply = await requestRead({
          ...config,
          unitId,
          functionCode,
          startAddress,
          rtuRecoveryAttempts: 1,
          suppressRtuStatus: true
        });
        addScanResult({
          ok: true,
          slaveId: unitId,
          functionCode,
          startAddress,
          values: reply.values,
          latencyMs: reply.latencyMs,
          error: ""
        });
        log(`ID ${unitId} replied on ${READ_FUNCTIONS[functionCode]} address ${startAddress}.`);
        done += 1;
        updateScanProgress(done, total, unitId);
        if (config.stopOnFound) {
          done += probes.length - probeIndex - 1;
          updateScanProgress(done, total, unitId);
          break;
        }
      } catch (error) {
        state.errors += 1;
        addScanResult({
          ok: false,
          slaveId: unitId,
          functionCode,
          startAddress,
          values: [],
          latencyMs: Math.round(performance.now() - startedAt),
          error: error.message
        });
        done += 1;
        updateScanProgress(done, total, unitId);
        if (config.fastTimeoutSkip && /timed?\s*out|timeout/i.test(error.message)) {
          done += probes.length - probeIndex - 1;
          updateScanProgress(done, total, unitId);
          break;
        }
      }
    }
  }

  state.scanning = false;
  els.scanBtn.disabled = !state.connected;
  els.stopBtn.disabled = true;
  els.scanState.textContent = "Ready";
  updateScanProgress(done, total);
  flushScanResultsRender();
  log("Scan finished.");
}

async function scanTcp(config) {
  state.scanning = true;
  els.scanBtn.disabled = true;
  els.stopBtn.disabled = false;
  els.scanState.textContent = `Scanning TCP IDs ${config.from}-${config.to}`;
  const ports = tcpScanPorts(config);
  log(`TCP scan started: ${state.tcpTarget.host}:${ports.join("/")}, IDs ${config.from}-${config.to}.`);
  const probes = buildScanProbes(config);
  const total = (config.to - config.from + 1) * probes.length * ports.length;
  let done = 0;
  const foundDevices = new Set();
  updateScanProgress(0, total, config.from);

  for (const port of ports) {
    if (!state.scanning) break;

    for (let unitId = config.from; unitId <= config.to; unitId += 1) {
      if (!state.scanning) break;
      let unitHadReply = false;

      for (let probeIndex = 0; probeIndex < probes.length; probeIndex += 1) {
        const { functionCode, startAddress } = probes[probeIndex];
        if (!state.scanning) break;
        state.tcpAbortController = new AbortController();
        try {
          const response = await fetch("/api/tcp/scan", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            signal: state.tcpAbortController.signal,
            body: JSON.stringify({
              host: state.tcpTarget.host,
              port,
              from: unitId,
              to: unitId,
              functionCode,
              startAddress,
              quantity: config.quantity,
              timeoutMs: config.timeoutMs,
              retries: 1,
              stopOnFound: false
            })
          });

          const payload = await readApiPayload(response);
          if (!response.ok) {
            if (response.status === 404 || response.status === 501) {
              throw new Error("TCP API is not active. Restart the app with python -m project_o.cli serve.");
            }
            throw new Error(payload.error || "TCP scan failed");
          }

          const responseFound = payload.results.some(isFoundScanResult);
          state.requests += payload.requests;
          if (!unitHadReply) {
            state.errors += payload.errors;
          }
          for (const result of payload.results.reverse()) {
            result.port = result.port || port;
            if (isFoundScanResult(result)) foundDevices.add(`${result.port || port}-${result.slaveId}`);
            addScanResult(result);
          }
          if (responseFound) unitHadReply = true;
          const timedOut = payload.results.some((result) => !isFoundScanResult(result) && /timed?\s*out|timeout/i.test(result.error));
          done += 1;
          updateScanProgress(done, total, unitId);
          if (config.stopOnFound && responseFound) {
            done += probes.length - probeIndex - 1;
            updateScanProgress(done, total, unitId);
            break;
          }
          if ((config.fastTimeoutSkip || unitHadReply) && timedOut) {
            done += probes.length - probeIndex - 1;
            updateScanProgress(done, total, unitId);
            break;
          }
        } catch (error) {
          if (error.name === "AbortError") {
            state.scanning = false;
            log("TCP scan stopped.");
            break;
          }
          if (!unitHadReply) state.errors += 1;
          updateStats();
          log(`TCP scan failed for ID ${unitId} port ${port}: ${error.message}`);
          done += 1;
          updateScanProgress(done, total, unitId);
        }
      }
    }
  }

  state.scanning = false;
  state.tcpAbortController = null;
  els.scanBtn.disabled = !state.connected;
  els.stopBtn.disabled = true;
  els.scanState.textContent = "Ready";
  updateScanProgress(done, total);
  flushScanResultsRender();
  log(`TCP scan finished with ${foundDevices.size} device(s) found.`);
}

async function scanGateways() {
  if (state.gatewayScanning) return;
  if (state.mode !== "tcp") {
    setMode("tcp");
  }
  if (!state.backendReady && !(await checkBackend())) {
    log("Gateway scan failed: TCP API is not active.");
    setBadge(els.supportBadge, "TCP API inactive", "error");
    return;
  }

  const config = getGatewayScanConfig();
  if (config.targets.length === 0) {
    log("Gateway scan failed: no IP targets.");
    return;
  }

  state.gatewayScanning = true;
  state.gatewayScanStarted = true;
  state.activeGatewayScan = {
    rangeText: config.rangeText,
    subnetText: config.subnetText,
    interfaceText: config.interfaceText
  };
  state.gatewayResults = [];
  state.gatewayAbortController = new AbortController();
  setGatewayScanControlsBusy(true);
  els.gatewayScanState.textContent = `Scanning ${config.subnetText || config.rangeText}`;
  flushGatewayResultsRender();
  updateGatewayProgress(0, config.targets.length);
  log(`Gateway scan started: ${config.subnetText || config.rangeText}, ${config.targets.length} IP(s) on port ${config.port}.`);

  let nextIndex = 0;
  let done = 0;
  const workers = Math.min(16, config.targets.length);
  const scanOne = async (host) => {
    const response = await fetch("/api/tcp/gateway-scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: state.gatewayAbortController.signal,
      body: JSON.stringify({
        targets: [host],
        port: config.port,
        timeoutMs: config.timeoutMs,
        unitIds: config.unitIds,
        functionCode: config.functionCode,
        startAddress: config.startAddress,
        quantity: config.quantity,
        workers: 1
      })
    });
    const payload = await readApiPayload(response);
    if (!response.ok) throw new Error(payload.error || "Gateway scan failed");
    return payload.results[0];
  };

  const runWorker = async () => {
    while (state.gatewayScanning && nextIndex < config.targets.length) {
      const host = config.targets[nextIndex];
      nextIndex += 1;
      try {
        const result = await scanOne(host);
        if (result.modbusOk || result.tcpOpen) {
          state.gatewayResults.push(result);
          scheduleGatewayResultsRender();
        }
        if (result.modbusOk) {
          log(`Gateway Modbus OK: ${result.host}:${result.port}${result.unitId ? ` ID ${result.unitId}` : ""}.`);
        } else if (result.tcpOpen) {
          log(`Gateway candidate: ${result.host}:${result.port} TCP open.`);
        }
      } catch (error) {
        if (error.name === "AbortError") {
          break;
        }
      } finally {
        done += 1;
        updateGatewayProgress(done, config.targets.length);
      }
    }
  };

  await Promise.all(Array.from({ length: workers }, runWorker));

  state.gatewayScanning = false;
  state.gatewayAbortController = null;
  setGatewayScanControlsBusy(false);
  els.gatewayScanState.textContent = `Finished scan ${config.subnetText || config.rangeText}`;
  updateGatewayProgress(done, config.targets.length);
  els.gatewayProgressText.textContent = done >= config.targets.length
    ? `Scan complete ${config.subnetText || config.rangeText} ${done}/${config.targets.length}`
    : `Scan stopped ${config.subnetText || config.rangeText} ${done}/${config.targets.length}`;
  flushGatewayResultsRender();
  const modbusCount = state.gatewayResults.filter((result) => result.modbusOk).length;
  const openCount = state.gatewayResults.filter((result) => result.tcpOpen).length;
  log(`Gateway scan finished: ${modbusCount} Modbus OK, ${openCount} TCP open.`);
}

async function scan() {
  if (state.scanning) return;
  const config = getScanConfig();
  if (config.mode === "tcp" && !(await refreshTcpTargetForScan(config))) {
    return;
  }
  clearResults();
  resetScanProgress();

  if (config.mode === "tcp") {
    await scanTcp(config);
    return;
  }
  await scanRtu(config);
}

function exportCsv() {
  const header = ["id", "status", "function", "address", "values", "latency_sec", "error"];
  const rows = state.results.map((result) => [
    result.slaveId,
    result.ok ? "found" : "no_reply",
    READ_FUNCTIONS[result.functionCode],
    result.startAddress,
    result.values.join(" "),
    msToSecondsValue(result.latencyMs),
    result.error
  ]);
  const csv = [header, ...rows]
    .map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(","))
    .join("\n");

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `alto-modbus-scan-${new Date().toISOString().slice(0, 19).replaceAll(":", "-")}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

function setActiveTab(tabName) {
  if (tabName === "traffic") {
    openModbusModal("traffic");
    flushTrafficRender();
    return;
  }
  state.activeTab = tabName;
  els.tabs.forEach((tab) => {
    const active = tab.dataset.tab === tabName;
    tab.classList.toggle("is-active", active);
    tab.setAttribute("aria-selected", String(active));
  });

  els.tabPanels.forEach((panel) => {
    if (panel.dataset.modbusModal === "traffic") return;
    panel.classList.toggle("hidden", panel.dataset.panel !== tabName);
  });
  if (tabName === "scan") {
    renderScanResults();
    renderFoundDevices();
  }
  if (tabName === "register") renderRegisterMap();
  if (tabName === "traffic") flushTrafficRender();
}

function syncDeviceTemplateFields() {
  const template = DEVICE_TEMPLATES[els.deviceTemplate.value] || DEVICE_TEMPLATES.generic;
  const id = readNumber(els.deviceId, 1, 1, 247);
  const isCustom = els.deviceTemplate.value === "custom";
  els.deviceFunction.value = String(template.functionCode);
  els.customPointBuilder.classList.remove("hidden");
  els.pointBuilderTitle.textContent = isCustom ? "CUSTOM POINTS" : "GENERIC POINT";
  els.customPointSummary.textContent = isCustom
    ? state.customPoints.length ? `${state.customPoints.length} custom point(s)` : "No custom points"
    : "Press Add Device to use this point";
  document.querySelectorAll(".custom-only").forEach((element) => {
    element.classList.toggle("hidden", !isCustom);
  });
  if (!isCustom && (!els.pointName.value.trim() || /^Point \d+$/i.test(els.pointName.value.trim()))) {
    els.pointName.value = "Value";
  }
  if (isCustom && (!els.pointName.value.trim() || els.pointName.value.trim() === "Value")) {
    resetCustomPointDraftName();
  }
  if (!els.deviceName.value.trim() || /^Device \d+$|^Custom \d+$/.test(els.deviceName.value.trim())) {
    els.deviceName.value = template.name(id);
  }
}

async function setMode(mode) {
  if (state.mode === "rtu" && (state.port || state.reader || state.writer)) {
    await disconnectSerial();
  }
  if (state.connected && state.mode === "tcp") {
    disconnectTcpTarget();
  }

  state.mode = mode;
  state.tcpTarget = null;
  els.rtuFields.classList.toggle("hidden", mode !== "rtu");
  els.tcpFields.classList.toggle("hidden", mode !== "tcp");
  els.connectBtn.querySelector(".btn-icon").textContent = mode === "rtu" ? "+" : ">";
  els.connectLabel.textContent = mode === "rtu" ? "Connect" : "Use target";
  els.disconnectLabel.textContent = mode === "rtu" ? "Disconnect" : "Clear target";
  els.slaveFromLabel.textContent = "ID from";
  els.slaveToLabel.textContent = "ID to";
  setConnected(false);
  setConnectionDetail("No target selected.", "idle");
  setSupportBadge();
  renderDevicesPreservingScroll();
}

function initialize() {
  state.mode = els.mode.value;
  els.rtuFields.classList.toggle("hidden", state.mode !== "rtu");
  els.tcpFields.classList.toggle("hidden", state.mode !== "tcp");
  els.connectBtn.querySelector(".btn-icon").textContent = state.mode === "rtu" ? "+" : ">";
  els.connectLabel.textContent = state.mode === "rtu" ? "Connect" : "Use target";
  els.disconnectLabel.textContent = state.mode === "rtu" ? "Disconnect" : "Clear target";
  els.slaveFromLabel.textContent = "ID from";
  els.slaveToLabel.textContent = "ID to";
  setActiveTab("poll");
  setSupportBadge();

  if ("serial" in navigator) {
    navigator.serial.addEventListener("disconnect", (event) => {
      const disconnectedPort = event.port || event.target;
      if (disconnectedPort !== state.port) return;
      void disconnectSerial({ announce: false, detail: "USB serial adapter disconnected." }).then(() => {
        log("USB serial adapter disconnected.");
      });
    });
  }
  window.addEventListener("pagehide", () => {
    if (!state.port) return;
    void disconnectSerial({ announce: false, detail: null });
  });

  els.tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      setActiveTab(tab.dataset.tab);
    });
  });
  els.refreshRegisterMapBtn?.addEventListener("click", () => {
    renderRegisterMap();
    log("Register map refreshed.");
  });
  els.clearTrafficBtn?.addEventListener("click", () => {
    state.traffic = [];
    updateTrafficCountBadge();
    flushTrafficRender();
    const item = document.createElement("li");
    item.textContent = `${new Date().toLocaleTimeString()} Traffic cleared.`;
    els.logList.prepend(item);
    while (els.logList.children.length > 100) {
      els.logList.lastElementChild.remove();
    }
    updateActivityCountBadge();
  });

  els.openModalBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const modalName = btn.dataset.openModbusModal;
      if (state.openModal === modalName) {
        closeModbusModal();
      } else {
        openModbusModal(modalName);
      }
    });
  });
  els.closeModalBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      closeModbusModal();
    });
  });
  els.modalBackdrop?.addEventListener("click", () => {
    closeModbusModal();
  });
  els.scanSearchInput?.addEventListener("input", () => {
    state.scanSearchQuery = els.scanSearchInput.value || "";
    renderScanResults();
  });
  window.addEventListener("resize", updateViewportGuard);

  els.deviceTemplate.addEventListener("change", () => {
    syncDeviceTemplateFields();
    renderCustomPoints();
  });
  els.deviceId.addEventListener("change", syncDeviceTemplateFields);
  els.deviceFunction.addEventListener("change", renderCustomPoints);
  els.addPointBtn.addEventListener("click", () => {
    if (els.deviceTemplate.value !== "custom") {
      addDeviceFromControls();
      return;
    }
    addCustomPoint();
  });
  els.clearPointDraftBtn.addEventListener("click", () => {
    state.customPoints = [];
    resetCustomPointDraftName();
    renderCustomPoints();
    log("Custom point draft cleared.");
  });
  els.customPointList.addEventListener("click", (event) => {
    const button = event.target.closest("button[data-remove-point]");
    if (!button) return;
    const index = Number.parseInt(button.dataset.removePoint, 10);
    state.customPoints.splice(index, 1);
    renumberDefaultCustomPoints();
    renderCustomPoints();
  });
  els.customPointList.addEventListener("change", (event) => {
    const input = event.target.closest("input[data-custom-control]");
    if (!input) return;
    const index = Number.parseInt(input.dataset.customControl, 10);
    const point = state.customPoints[index];
    if (!point) return;
    point.controlEnabled = input.checked && pointControlAvailable(point, {
      functionCode: Number.parseInt(els.deviceFunction.value, 10)
    });
    renderCustomPoints();
  });
  els.customPointList.addEventListener("dragstart", (event) => {
    const item = event.target.closest(".point-draft-item");
    if (!item) return;
    state.draggedPointIndex = Number.parseInt(item.dataset.pointIndex, 10);
    item.classList.add("is-dragging");
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/plain", item.dataset.pointIndex);
  });
  els.customPointList.addEventListener("dragover", (event) => {
    const item = event.target.closest(".point-draft-item");
    if (!item || state.draggedPointIndex === null) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
    els.customPointList.querySelectorAll(".point-draft-item").forEach((row) => {
      row.classList.toggle("is-drop-target", row === item);
    });
  });
  els.customPointList.addEventListener("dragleave", (event) => {
    const item = event.target.closest(".point-draft-item");
    if (item) item.classList.remove("is-drop-target");
  });
  els.customPointList.addEventListener("drop", (event) => {
    const item = event.target.closest(".point-draft-item");
    if (!item || state.draggedPointIndex === null) return;
    event.preventDefault();
    const toIndex = Number.parseInt(item.dataset.pointIndex, 10);
    moveCustomPoint(state.draggedPointIndex, toIndex);
  });
  els.customPointList.addEventListener("dragend", () => {
    state.draggedPointIndex = null;
    els.customPointList.querySelectorAll(".point-draft-item").forEach((item) => {
      item.classList.remove("is-dragging", "is-drop-target");
    });
  });
  els.addDeviceBtn.addEventListener("click", addDeviceFromControls);
  els.importFoundBtn.addEventListener("click", importFoundDevices);
  els.importScanBtn.addEventListener("click", importFoundDevices);
  els.exportDeviceConfigBtn.addEventListener("click", exportDeviceConfig);
  els.importDeviceConfigBtn.addEventListener("click", () => {
    els.deviceConfigInput.click();
  });
  els.deviceConfigInput.addEventListener("change", () => {
    const file = els.deviceConfigInput.files?.[0];
    if (file) importDeviceConfigFile(file);
    els.deviceConfigInput.value = "";
  });
  els.covMode.addEventListener("change", updateDeviceControls);
  els.covDeadband.addEventListener("change", updateDeviceControls);
  els.refreshDevicesBtn.addEventListener("click", () => {
    refreshAllDevices();
  });
  els.startDeviceMonitorBtn.addEventListener("click", startDeviceMonitor);
  els.stopDeviceMonitorBtn.addEventListener("click", stopDeviceMonitor);
  els.clearDevicesBtn.addEventListener("click", () => {
    stopDeviceMonitor();
    state.devices = [];
    renderDevices();
    log("Device profiles cleared.");
  });
  els.deviceGrid.addEventListener("click", (event) => {
    const button = event.target.closest("button[data-action]");
    if (!button) return;
    const device = state.devices.find((item) => item.uid === button.dataset.uid);
    if (!device) return;
    if (button.dataset.action === "refresh-device") {
      refreshDevice(device);
    } else if (button.dataset.action === "load-device") {
      loadDeviceIntoRead(device);
    } else if (button.dataset.action === "duplicate-device") {
      duplicateDevice(device);
    } else if (button.dataset.action === "toggle-rename-device") {
      device.editingName = !device.editingName;
      renderDevices();
    } else if (button.dataset.action === "save-device-name") {
      const editor = button.closest(".device-name-editor");
      const idInput = editor?.querySelector('[data-field="device-id"]');
      const nameInput = editor?.querySelector('[data-field="device-name"]');
      const id = readNumber(idInput, device.id, 1, 247);
      const name = nameInput?.value.trim();
      if (!name) {
        log("Device name is required.");
        return;
      }
      const duplicate = state.devices.some((item) =>
        item.uid !== device.uid && item.id === id && item.functionCode === device.functionCode && item.name === name
      );
      if (duplicate) {
        log("Device with same ID, function, and name already exists.");
        return;
      }
      const oldId = device.id;
      const oldName = device.name;
      device.id = id;
      device.name = name;
      device.editingName = false;
      renderDevices();
      log(`Updated ${oldName} ID ${oldId} to ${device.name} ID ${device.id}.`);
    } else if (button.dataset.action === "toggle-edit-points") {
      openDevicePointEditor(device, 0);
    } else if (button.dataset.action === "write-device-point") {
      const pointIndex = Number.parseInt(button.dataset.pointIndex, 10);
      if (Number.isNaN(pointIndex)) return;
      writeDevicePoint(device, pointIndex, button);
    } else if (button.dataset.action === "remove-device") {
      state.devices = state.devices.filter((item) => item.uid !== device.uid);
      renderDevices();
      log(`Removed ${device.name}.`);
    }
  });
  document.addEventListener("click", (event) => {
    const overlay = event.target.closest(".point-editor-overlay");
    if (!overlay) return;
    if (event.target === overlay) {
      closeDevicePointEditor();
      return;
    }
    const button = event.target.closest("button[data-action]");
    if (!button) return;
    const device = pointEditorDevice();
    if (!device && button.dataset.action !== "close-point-editor") {
      closeDevicePointEditor();
      return;
    }

    if (button.dataset.action === "close-point-editor") {
      closeDevicePointEditor();
    } else if (button.dataset.action === "new-editor-point") {
      setPointEditorMode("add");
    } else if (button.dataset.action === "select-editor-point") {
      const index = Number.parseInt(button.dataset.pointIndex, 10);
      if (!Number.isNaN(index)) setPointEditorMode("edit", index);
    } else if (button.dataset.action === "move-editor-point-up" || button.dataset.action === "move-editor-point-down") {
      const index = Number.parseInt(button.dataset.pointIndex, 10);
      if (!device || Number.isNaN(index) || !device.points[index]) return;
      const nextIndex = button.dataset.action === "move-editor-point-up" ? index - 1 : index + 1;
      if (nextIndex < 0 || nextIndex >= device.points.length) return;
      const [point] = device.points.splice(index, 1);
      device.points.splice(nextIndex, 0, point);
      state.pointEditor = { deviceUid: device.uid, mode: "edit", selectedIndex: nextIndex };
      renderDevicesPreservingScroll();
      renderPointEditorModal();
      log(`Moved point ${point.name} in ${device.name}.`);
    } else if (button.dataset.action === "copy-editor-point") {
      const index = Number.parseInt(button.dataset.pointIndex, 10);
      const targetUid = overlay.querySelector("[data-copy-target-device]")?.value || "";
      const targetDevice = state.devices.find((item) => item.uid === targetUid);
      if (!device || !targetDevice || Number.isNaN(index) || !device.points[index]) return;
      const point = clonePoints([device.points[index]])[0];
      const duplicate = targetDevice.points.some((item) =>
        pointFunctionCode(item, targetDevice) === pointFunctionCode(point, targetDevice)
        && item.address === point.address
        && item.name === point.name
      );
      if (duplicate) {
        log(`Point ${point.name} already exists in ${targetDevice.name}.`);
        return;
      }
      targetDevice.points.push(point);
      targetDevice.nextMonitorAt = 0;
      renderDevicesPreservingScroll();
      renderPointEditorModal();
      log(`Copied point ${point.name} to ${targetDevice.name}.`);
    } else if (button.dataset.action === "add-editor-point") {
      const form = overlay.querySelector("[data-point-editor-form]");
      if (!form || !device) return;
      const point = readDevicePointForm(form, "add");
      const duplicate = device.points.some((item) =>
        pointFunctionCode(item, device) === point.functionCode && item.address === point.address && item.name === point.name
      );
      if (duplicate) {
        log(`Point already exists in ${device.name}.`);
        return;
      }
      device.points.push(point);
      state.pointEditor = { deviceUid: device.uid, mode: "edit", selectedIndex: device.points.length - 1 };
      renderDevicesPreservingScroll();
      renderPointEditorModal();
      log(`Added point ${point.name} to ${device.name}.`);
    } else if (button.dataset.action === "save-editor-point") {
      const index = Number.parseInt(button.dataset.pointIndex, 10);
      const form = overlay.querySelector("[data-point-editor-form]");
      if (!form || !device || Number.isNaN(index) || !device.points[index]) return;
      const point = readDevicePointForm(form, "edit");
      const duplicate = device.points.some((item, itemIndex) =>
        itemIndex !== index && pointFunctionCode(item, device) === point.functionCode && item.address === point.address && item.name === point.name
      );
      if (duplicate) {
        log(`Point already exists in ${device.name}.`);
        return;
      }
      device.points[index] = point;
      state.pointEditor.selectedIndex = index;
      renderDevicesPreservingScroll();
      renderPointEditorModal();
      log(`Updated point ${point.name} in ${device.name}.`);
    } else if (button.dataset.action === "remove-editor-point") {
      const index = Number.parseInt(button.dataset.pointIndex, 10);
      if (!device || Number.isNaN(index) || !device.points[index]) return;
      const [point] = device.points.splice(index, 1);
      const nextIndex = clampNumber(index, 0, Math.max(0, device.points.length - 1));
      state.pointEditor = {
        deviceUid: device.uid,
        mode: device.points.length ? "edit" : "add",
        selectedIndex: nextIndex
      };
      renderDevicesPreservingScroll();
      renderPointEditorModal();
      log(`Removed point ${point.name} from ${device.name}.`);
    }
  });
  document.addEventListener("change", (event) => {
    const input = event.target.closest('input[data-action="toggle-editor-point-control"]');
    if (!input) return;
    const overlay = input.closest(".point-editor-overlay");
    const device = pointEditorDevice();
    const index = Number.parseInt(input.dataset.pointIndex, 10);
    const point = device?.points[index];
    if (!overlay || !device || !point || Number.isNaN(index)) return;
    if (!pointControlAvailable(point, device)) {
      input.checked = false;
      return;
    }

    point.controlEnabled = input.checked;
    if (state.pointEditor?.selectedIndex === index && pointEditorMode() === "edit") {
      const formControl = overlay.querySelector('[data-field="edit-control-enabled"]');
      if (formControl) formControl.checked = input.checked;
    }
    const itemMeta = input
      .closest(".point-editor-list-row")
      ?.querySelector(".point-editor-list-item span");
    if (itemMeta) {
      itemMeta.textContent = itemMeta.textContent
        .replace(/\s+-\s+Control on$/, "")
        .concat(input.checked ? " - Control on" : "");
    }
    input.closest("label")?.setAttribute(
      "title",
      `${input.checked ? "Disable" : "Enable"} control for ${point.name}`
    );
    updateDeviceCardLiveData(device, { forceControlRender: true });
    log(`${input.checked ? "Enabled" : "Disabled"} control for ${point.name} in ${device.name}.`);
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      if (state.pointEditor) {
        closeDevicePointEditor();
      } else if (state.openModal) {
        closeModbusModal();
      }
    }
  });
  els.deviceGrid.addEventListener("change", (event) => {
    const input = event.target.closest("[data-device-rate], [data-device-host], [data-device-port]");
    if (!input) return;
    const device = state.devices.find((item) => item.uid === input.dataset.uid);
    if (!device) return;
    if (input.matches("[data-device-rate]")) {
      device.intervalMs = readSecondsAsMs(input, device.intervalMs || 1000, 500, 60000);
      input.value = msToSecondsValue(device.intervalMs);
      log(`Updated ${device.name} monitor rate to ${msToSecondsValue(device.intervalMs)} sec.`);
    } else if (input.matches("[data-device-host]")) {
      device.tcpHost = input.value.trim();
      input.value = device.tcpHost;
      log(`Updated ${device.name} Host/IP to ${device.tcpHost || "global target"}.`);
    } else if (input.matches("[data-device-port]")) {
      const value = readNumber(input, device.tcpPort || 502, 1, 65535);
      device.tcpPort = value;
      input.value = String(value);
      log(`Updated ${device.name} TCP port to ${value}.`);
    }
    device.lastError = "";
    device.nextMonitorAt = 0;
    if (state.deviceMonitoring) {
      scheduleDeviceMonitor(0);
    }
    updateDeviceControls();
  });
  els.deviceGrid.addEventListener("pointerdown", (event) => {
    startDeviceCardResize(event);
  });
  els.deviceGrid.addEventListener("dblclick", (event) => {
    autoFitDeviceCardHeight(event);
  });
  window.addEventListener("pointermove", (event) => {
    updateDeviceCardResize(event);
  });
  window.addEventListener("pointerup", (event) => {
    finishDeviceCardResize(event);
  });
  window.addEventListener("pointercancel", (event) => {
    finishDeviceCardResize(event);
  });
  els.deviceGrid.addEventListener("dragstart", (event) => {
    const card = event.target.closest(".device-card");
    const handle = event.target.closest(".device-drag-handle");
    if (!card || !handle) {
      event.preventDefault();
      return;
    }
    state.draggedDeviceIndex = Number.parseInt(card.dataset.deviceIndex, 10);
    card.classList.add("is-dragging");
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/plain", card.dataset.deviceIndex);
  });
  els.deviceGrid.addEventListener("dragover", (event) => {
    const card = event.target.closest(".device-card");
    if (!card || state.draggedDeviceIndex === null) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
    els.deviceGrid.querySelectorAll(".device-card").forEach((item) => {
      item.classList.toggle("is-drop-target", item === card);
    });
  });
  els.deviceGrid.addEventListener("dragleave", (event) => {
    const card = event.target.closest(".device-card");
    if (card) card.classList.remove("is-drop-target");
  });
  els.deviceGrid.addEventListener("drop", (event) => {
    const card = event.target.closest(".device-card");
    if (!card || state.draggedDeviceIndex === null) return;
    event.preventDefault();
    const toIndex = Number.parseInt(card.dataset.deviceIndex, 10);
    moveDevice(state.draggedDeviceIndex, toIndex);
  });
  els.deviceGrid.addEventListener("dragend", () => {
    state.draggedDeviceIndex = null;
    els.deviceGrid.querySelectorAll(".device-card").forEach((card) => {
      card.classList.remove("is-dragging", "is-drop-target");
    });
  });

  els.mode.addEventListener("change", () => {
    setMode(els.mode.value);
  });
  [els.baudRate, els.dataBits, els.stopBits, els.parity].forEach((input) => {
    input.addEventListener("change", () => {
      if (state.mode === "rtu") renderDevicesPreservingScroll();
    });
  });
  els.connectBtn.addEventListener("click", () => {
    if (state.mode === "rtu") {
      void connectSerial();
    } else {
      connectTcpTarget();
    }
  });
  els.disconnectBtn.addEventListener("click", () => {
    if (state.mode === "rtu") {
      void disconnectSerial();
    } else {
      disconnectTcpTarget();
    }
  });
  els.readOnceBtn.addEventListener("click", () => {
    readOnce().catch(() => {});
  });
  els.readFunction?.addEventListener("change", updateReadDecodeControls);
  els.readType?.addEventListener("change", updateReadDecodeControls);
  els.pollBtn.addEventListener("click", startPolling);
  els.stopPollBtn.addEventListener("click", stopPolling);
  els.writeBtn.addEventListener("click", writeValue);
  els.gatewayScanBtn.addEventListener("click", () => {
    scanGateways().catch((error) => {
      state.gatewayScanning = false;
      setGatewayScanControlsBusy(false);
      els.gatewayScanState.textContent = "Ready";
      log(`Gateway scan failed: ${shortError(error)}.`);
    });
  });
  els.gatewaySubnetBtn.addEventListener("click", () => {
    if (state.gatewayScanning) return;
    els.gatewayRange.value = deriveSubnetRange(els.tcpHost.value);
    els.gatewayPort.value = readNumber(els.tcpPort, 502, 1, 65535);
    clearGatewayScanResultsForSubnetChange();
    log(`Gateway range set to ${els.gatewayRange.value}.`);
  });
  els.gatewayAutoNetworkBtn.addEventListener("click", applySelectedNetworkSubnet);
  els.networkRefreshBtn.addEventListener("click", () => {
    loadNetworkInterfaces(true).catch((error) => {
      log(`Network refresh failed: ${shortError(error)}.`);
    });
  });
  els.networkInterface.addEventListener("change", applySelectedNetworkInterface);
  els.networkSubnet.addEventListener("change", applySelectedNetworkSubnet);
  [els.gatewayRange, els.gatewayPort, els.gatewayProbeIds].forEach((input) => {
    input.addEventListener("change", clearGatewayScanResultsForSubnetChange);
  });
  els.gatewayStopBtn.addEventListener("click", () => {
    state.gatewayScanning = false;
    if (state.gatewayAbortController) {
      state.gatewayAbortController.abort();
    }
    setGatewayScanControlsBusy(false);
    log("Gateway scan stop requested.");
  });
  els.gatewayResults.addEventListener("click", (event) => {
    const card = event.target.closest("[data-gateway-host]");
    if (!card) return;
    els.tcpHost.value = card.dataset.gatewayHost;
    els.tcpPort.value = card.dataset.gatewayPort || "502";
    state.selectedGateway = {
      host: els.tcpHost.value,
      port: readNumber(els.tcpPort, 502, 1, 65535)
    };
    setMode("tcp");
    renderGatewayResults();
    syncDevicesToTcpTarget(state.selectedGateway.host, state.selectedGateway.port);
    closeModbusModal();
    log(`Gateway target selected: ${els.tcpHost.value}:${els.tcpPort.value}.`);
  });
  els.scanBtn.addEventListener("click", scan);
  els.quickScanBtn.addEventListener("click", () => {
    els.slaveFrom.value = 1;
    els.slaveTo.value = 20;
    els.scanFunction.value = "all";
    els.scanAddress.value = "";
    els.scanQuantity.value = 1;
    els.stopOnFound.checked = true;
    els.fastTimeoutSkip.checked = false;
    scan();
  });
  els.stopBtn.addEventListener("click", () => {
    state.scanning = false;
    if (state.tcpAbortController) {
      state.tcpAbortController.abort();
    }
    els.stopBtn.disabled = true;
    log("Stop requested.");
  });
  els.clearBtn.addEventListener("click", () => {
    clearResults();
    log("Scan results cleared.");
  });
  els.exportBtn.addEventListener("click", exportCsv);
  renderScanResults();
  updateReadDecodeControls();
  syncDeviceTemplateFields();
  renderCustomPoints();
  renderDevices();
  updateStats();
  resetScanProgress();
  resetGatewayProgress();
  renderGatewayResults();
  updateActivityCountBadge();
  updateTrafficCountBadge();
  updateViewportGuard();
  checkBackend().then(() => loadNetworkInterfaces(true)).catch(() => {});
}

initialize();
